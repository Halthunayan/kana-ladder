/* Every option list, stressed hard: no repeats, exactly one right answer. */
const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const today=new Date(Date.now()-14400000).toISOString().slice(0,10);  // the app's day starts at 04:00 UTC
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(t=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  const now=Date.now(), items={};
  for(let i=0;i<600;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,6,2.6,50,now+50*86400000,0,0,12,12,3.4,50,now-2*86400000]; }
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:99,
    settings:{sched:"fsrs",retention:0.9,newPerDay:0,revCap:150,reverse:"grad",separate:true,
      sentences:true,conj:true,listen:true,tts:true,autoPlay:false,typing:false,kanji:true,theme:"dark"},
    daily:{key:t,newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,consDone:0,
      noNew:false,buried:{},done:{},missed:{}},
    hist:{}, streak:{cur:3,best:3,last:""}, life:{ans:400,ok:340,practice:0},
    backup:{last:""}, notes:{}, susp:{}, pfail:{}, log:[], items}));
}, today);
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });

console.log('\nevery conjugating word, every form, every question type');
const res=await p.evaluate(()=>{
  const bad=[], kinds={};
  const ids=Object.keys(__kl.FORMS);
  let built=0;
  for(const id of ids){
    for(const kind of ['mcJE','mcEJ','mcAudio','conj','cloze']){
      for(let rep=0; rep<(kind==='conj'?8:2); rep++){
        const q=__kl.makeQuestion(kind,id);
        if(!q) continue;
        built++; kinds[kind]=(kinds[kind]||0)+1;
        const texts=q.opts.map(o=>o.text);
        if(new Set(texts).size!==texts.length) bad.push(kind+' '+id+': repeated option ['+texts.join(', ')+']');
        if(q.opts.filter(o=>o.ok).length!==1) bad.push(kind+' '+id+': not exactly one correct option');
        const subs=q.opts.filter(o=>o.sub).map(o=>o.sub);
        if(subs.length && new Set(subs).size!==subs.length) bad.push(kind+' '+id+': repeated romaji');
      }
    }
  }
  return {bad:bad.slice(0,8), n:bad.length, built, kinds};
});
console.log('   built '+res.built+' questions: '+JSON.stringify(res.kinds));
ok(res.n===0, res.n? res.n+' malformed: '+res.bad.join(' ; ') : 'not one repeated option across every conjugating word');

console.log('\nthe same, over every word in the deck');
const res2=await p.evaluate(()=>{
  const bad=[]; let built=0;
  for(const c of __kl.DECK){
    for(const kind of ['mcJE','mcEJ']){
      const q=__kl.makeQuestion(kind,c.id);
      if(!q) continue;
      built++;
      const texts=q.opts.map(o=>o.text);
      if(new Set(texts).size!==texts.length) bad.push(kind+' '+c.id+': repeated option');
      if(q.opts.filter(o=>o.ok).length!==1) bad.push(kind+' '+c.id+': not one correct option');
    }
  }
  return {bad:bad.slice(0,8), n:bad.length, built};
});
console.log('   built '+res2.built+' recognition and recall questions');
ok(res2.n===0, res2.n? res2.n+' malformed: '+res2.bad.join(' ; ') : 'every word in the deck produces a clean four-option question');
ok(errs.length===0, errs.length? errs.join(' | ') : 'no page errors');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'EVERY OPTION LIST IS CLEAN'));
process.exit(fails.length?1:0);})();
