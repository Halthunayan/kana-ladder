const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
// Seed a state where reverse cards are already due and typing is on.
await ctx.addInitScript(()=>{
  if(localStorage.getItem('kanaladder.v1')) return;
  const items={}; const now=Date.now();
  for(let i=0;i<6;i++){ items['c'+String(i).padStart(4,'0')+'|e']=[1,0,3,2.5,5,now-86400000,0,0,3,3]; }
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:5,
    settings:{newPerDay:0,revCap:150,reverse:"grad",softCap:true,separate:true,listen:false,
              sentences:false,sentPerDay:0,badge:false,typing:true,kanji:true,tts:false,theme:"auto"},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,consDone:0,buried:{},done:{}},
    hist:{}, streak:{cur:0,best:0,last:""}, life:{ans:0,ok:0}, backup:{last:""}, notes:{}, susp:{}, items}));
});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);
await p.click('#startBtn'); await p.waitForTimeout(500);
console.log('card direction:', await p.$eval('#dirChip',e=>e.textContent));
console.log('  typing field present:', await p.$('#typeIn')?'PASS':'FAIL');
await p.click('#typeIn');
await p.type('#typeIn','zenzen z ok',{delay:20}); await p.waitForTimeout(300);
const v=await p.$eval('#typeIn',e=>e.value);
console.log('  typed:', JSON.stringify(v));
console.log('  the letter z reached the field:', v.indexOf('z')>=0 ? 'PASS':'FAIL');
console.log('  spaces reached the field:', v.split(' ').length===3 ? 'PASS':'FAIL');
console.log('  answer still hidden while typing:', await p.evaluate(()=>document.getElementById('fold').hidden)?'PASS':'FAIL');
await p.press('#typeIn','Enter'); await p.waitForTimeout(400);
console.log('  Enter reveals:', await p.evaluate(()=>!document.getElementById('fold').hidden)?'PASS':'FAIL');
console.log('  verdict:', await p.$eval('#verdict',e=>e.textContent).catch(()=>'(none)'));
await p.click('.card'); await p.press('body','3'); await p.waitForTimeout(500);
const after=await p.evaluate(()=>JSON.parse(localStorage.getItem('kanaladder.v1')).daily.ans);
console.log('  number keys grade when not typing:', after===1?'PASS':'FAIL (ans='+after+')');
console.log('errors:', errs.length?errs.join(' | '):'none');
await b.close();})();
