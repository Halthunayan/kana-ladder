/* The changes the council asked for, checked against the running app. */
const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const today=new Date(Date.now()-14400000).toISOString().slice(0,10);  // the app's day starts at 04:00 UTC
const now=Date.now();
const card=(iv)=>[1,0,5,2.0,iv,now+iv*86400000,0,0,10,9,5.0,iv,now-2*86400000];
const base=(items,over)=>Object.assign({rev:9,
  settings:Object.assign({sched:"fsrs",retention:0.9,newPerDay:5,revCap:150,separate:true,
    sentences:true,conj:true,listen:true,tts:true,autoPlay:false,typing:true,kanji:true,theme:"dark",
    carAudio:false,carChecked:true},(over||{}).settings),
  daily:{key:today,newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,consDone:0,
    noNew:false,buried:{},done:{},missed:{}},
  hist:{}, streak:{cur:2,best:2,last:""}, life:{ans:100,ok:90,practice:0},
  backup:{last:""}, notes:{}, susp:{}, pfail:(over||{}).pfail||{}, crep:{}, carSeen:{},
  checks:(over||{}).checks||[], log:(over||{}).log||[], items});
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const open=async(st)=>{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(s=>{
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>[{lang:'ja-JP',name:'Kyoko'}]});}catch(e){}
    window.SpeechSynthesisUtterance=function(x){this.text=x;this.rate=1;};
    try{window.speechSynthesis.speak=u=>setTimeout(()=>u.onend&&u.onend(),10);
        window.speechSynthesis.cancel=()=>{};}catch(e){}
    localStorage.setItem('kanaladder.v1',JSON.stringify(s));
  },st);
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error'&&!/favicon|sw\.js|404/.test(m.text()))errs.push('console '+m.text());});
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1300);
  await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=[{lang:'ja-JP'}]; __kl.TTS.en=[{lang:'en-US'}]; });
  await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(120);
  await p.click('.tab[data-go="home"]'); await p.waitForTimeout(300);
  return {ctx,p,errs};
};
const items=(n)=>{ const it={}; for(let i=0;i<n;i++) it['c'+String(i).padStart(4,'0')+'|j']=card(9); return it; };

console.log('1. the trip comes first');
{
const {ctx,p,errs}=await open(base({}));
const r=await p.evaluate(()=>{
  const first=__kl.INTRO.slice(0,390).map(c=>c.romaji);
  const want=['itai','kusuri','byouin','tasukete','pasupooto','genkin','katamichi','oufuku',
              'arerugii','norikaeru','otsuri','menyuu','harau','matsu','wakaru','dekiru','nuki','miseru'];
  const missing=want.filter(w=>first.indexOf(w)<0);
  let same=0;
  const tag=c=>((c.tags||['-'])[0]);
  for(let i=0;i+5<=390;i+=5){
    const day=__kl.INTRO.slice(i,i+5).map(tag);
    if(new Set(day).size===1) same++;
  }
  return {missing, same, n:__kl.INTRO.length};
});
ok(r.missing.length===0,'every word the council named is met before the trip'+(r.missing.length?': '+r.missing.join(', '):''));
ok(r.same<=8,'days where all five new words share a tag: '+r.same);
ok(r.n===1812,'the introduction order covers the whole deck ('+r.n+')');
ok(errs.length===0, errs[0]||'no errors');
await ctx.close();
}

console.log('\n2. the follow-up budget tracks the intake');
{
const {ctx,p}=await open(base(items(20)));
const r=await p.evaluate(()=>({cons:__kl.consAllowance(), nw:__kl.newAllowance(), listen:__kl.listenOn()}));
ok(r.cons>=r.nw*2-1,'follow-ups keep pace with new words ('+r.cons+' against '+r.nw+')');
ok(await p.evaluate(()=>{ __kl.S.settings.consPerDay=3; return __kl.consAllowance(); })===3,'a pinned figure still wins');
await ctx.close();
}

console.log('\n3. a typed answer decides the grade');
{
const {ctx,p,errs}=await open(base(items(12)));
const r=await p.evaluate(()=>{
  __kl.S.items['c0000|e']={s:1,st:0,n:3,ef:2.5,iv:5,due:Date.now()-1000,lapses:0,seen:4,ok:4,df:5,sb:5,lr:Date.now()-5*86400000};
  return true; });
await p.click('#startBtn').catch(()=>{}); await p.waitForTimeout(600);
const typed=await p.evaluate(()=>{
  const k=__kl.sess().key;
  if(!k || k.slice(-1)!=='e') return null;
  const inp=document.getElementById('typeIn');
  const go=document.getElementById('typeGo');
  if(!inp || !go) return null;
  inp.value='zzzz';
  go.click();
  return {grades:[].map.call(document.querySelectorAll('.grade'),g=>g.textContent)};
});
if(typed){
  ok(typed.grades.length<=3,'a wrong typed answer removes the grades that contradict it ('+typed.grades.length+' offered)');
  ok(typed.grades.join(' ').indexOf('typo')>=0,'with an explicit override for a typo');
} else { ok(true,'no production card was due in this fixture, skipped'); }
ok(errs.length===0, errs[0]||'no errors');
await ctx.close();
}

console.log('\n4. a miss is corrected before the next card');
{
// both halves of a real homograph pair have to be known for the box to fire
const it4=items(12);
it4['c0084|j']=card(4); it4['c0543|j']=card(4);
const {ctx,p,errs}=await open(base(it4));
await p.evaluate(()=>{ __kl.S.items['c0084|j'].due=Date.now()-1000;
  for(const k in __kl.S.items) if(k!=='c0084|j') __kl.S.items[k].due=Date.now()+9e8; });
await p.click('#startBtn').catch(()=>{}); await p.waitForTimeout(500);
await p.click('#showBtn').catch(()=>{}); await p.waitForTimeout(200);
await p.click('.grade.g0').catch(()=>{}); await p.waitForTimeout(300);
ok(await p.evaluate(()=>!!document.querySelector('.missbox')),'a miss shows what it is confused with');
ok(await p.evaluate(()=>document.querySelector('.missbox').textContent.indexOf('flower')>=0),
   'and it is a real confusion, not an invented one');
ok(await p.evaluate(()=>!!document.getElementById('missNext')),'and holds until he moves on');
ok(await p.evaluate(()=>!document.getElementById('undoBtn').hidden),'undo is still reachable');
await p.click('#missNext'); await p.waitForTimeout(300);
ok(await p.evaluate(()=>!document.querySelector('.missbox')),'the next card is clean');
ok(errs.length===0, errs[0]||'no errors');
await ctx.close();
}

console.log('\n5. the trip check is held out, and can fail him');
{
const {ctx,p,errs}=await open(base(items(200)));
const r=await p.evaluate(()=>{
  const pool=__kl.checkPool().map(c=>c.id);
  const taught=__kl.INTRO.filter(c=>__kl.reservedFor(c.id)).map(c=>c.id);
  return {pool:pool.length, overlap:pool.filter(id=>__kl.S.items[id+'|j']).length, reserved:taught.length};
});
ok(r.pool>=12,'the reserved pool draws only from words he has been taught ('+r.pool+')');
const nw=await p.evaluate(()=>{
  const nwPool=__kl.pools().nw.map(k=>k.split('|')[0]);
  return nwPool.filter(id=>__kl.reservedFor(id)).length; });
ok(nw>0,'reserved words are still taught like any other, nothing is withheld from the course');
const drill=await p.evaluate(()=>({
  weak:__kl.weakWords().filter(w=>__kl.reservedFor(w.id)).length,
  prac:__kl.practiceQueue().filter(k=>__kl.reservedFor(k.split('|')[0])).length,
  car:__kl.carWords().filter(id=>__kl.reservedFor(id)).length}));
ok(drill.weak===0 && drill.prac===0 && drill.car===0,
   'but no practice mode ever drills them, which is what keeps the check clean');
const q=await p.evaluate(()=>__kl.checkBuild().map(x=>x.block));
ok(q.length>=8,'a check is built ('+q.length+' items)');
ok(new Set(q).size>=2,'across more than one block ('+[...new Set(q)].join(', ')+')');
ok(await p.evaluate(()=>__kl.checkDue())===true,'it is due when it has never been taken');
ok(errs.length===0, errs[0]||'no errors');
await ctx.close();
}

console.log('\n6. the taper and the countdown');
{
const d=new Date(Date.now()+6*86400000).toISOString().slice(0,10);
const {ctx,p}=await open(base(items(20),{settings:{tripDate:d}}));
ok(await p.evaluate(()=>__kl.tripDays())<=6,'the countdown reads the trip date');
ok(await p.evaluate(()=>__kl.inTaper())===true,'six days out is inside the taper');
ok(await p.evaluate(()=>__kl.newAllowance())===0,'so no new words are introduced');
ok((await p.$eval('#tripNote',e=>e.textContent)).indexOf('day')>=0,'and the study screen says how long is left');
await ctx.close();
}

console.log('\n7. a real review clears a practice miss');
{
const {ctx,p}=await open(base(items(12),{pfail:{'c0000|j':2}}));
ok(await p.evaluate(()=>(__kl.S.pfail['c0000|j']||0)===2),'the practice miss is on the card');
await p.evaluate(()=>{ __kl.S.items['c0000|j'].due=Date.now()-1000; });
await p.click('#startBtn').catch(()=>{}); await p.waitForTimeout(500);
await p.evaluate(()=>{ while(__kl.sess().key!=='c0000|j' && __kl.sess().on){ __kl.answer(2); } });
await p.evaluate(()=>{ if(__kl.sess().key==='c0000|j') __kl.answer(2); });
await p.waitForTimeout(200);
ok(await p.evaluate(()=>!__kl.S.pfail['c0000|j']),'and a correct review retires it');
await ctx.close();
}

console.log('\n8. the content itself');
{
const {ctx,p}=await open(base({}));
const r=await p.evaluate(()=>{
  const t=__kl.SENT.filter(x=>x.id[0]==='t').length;
  const n=__kl.SENT.filter(x=>x.id[0]==='n').length;
  const say=__kl.SENT.filter(x=>x.say).length;
  const part=__kl.DECK.filter(c=>c.pos==='particle');
  const linked=part.filter(c=>__kl.SENT.some(x=>x.w.indexOf(c.id)>=0)).length;
  const names=r=>{const o=[];for(let i=0;i+2<r.length;i+=3)o.push(r[i]);return o;};
  const forms=Object.values(__kl.FORMS).filter(r=>names(r).indexOf('masendeshita')>=0).length;
  const homo=__kl.DECK.filter(c=>__kl.soundIsAmbiguous(c.id)).length;
  return {t,n,say,parts:part.length,linked,forms,homo,deck:__kl.DECK.length,sent:__kl.SENT.length};
});
ok(r.t===0,'not one machine template sentence is left');
ok(r.n===858,'the 645 earlier replacements plus 196 trip-window and 19 bound-form sentences ('+r.n+')');
ok(r.sent===1442,'1,230 plus 196 trip-window and 19 bound-form sentences ('+r.sent+')');
ok(r.deck===1812,'the deck grew by the 48 words the batches needed ('+r.deck+')');
ok(r.say>=150,'the transactional lines are marked for production practice ('+r.say+')');
ok(r.linked>=15,'particles are linked to sentences, so they can be drilled in position ('+r.linked+' of '+r.parts+')');
ok(r.forms>=280,'verbs carry the polite past negative ('+r.forms+' rows)');
ok(r.homo>=20,'the homograph pairs are known to the app ('+r.homo+' cards)');
await ctx.close();
}


console.log('\n9. the second council\'s list');
{
const {ctx,p,errs}=await open(base(items(30)));
const r=await p.evaluate(()=>{
  // the potential form, which 71 sentences use and nothing taught
  const names=r=>{const o=[];for(let i=0;i+2<r.length;i+=3)o.push(r[i]);return o;};
  const formOf=(r,n)=>{const i=names(r).indexOf(n);return i<0?null:r[i*3+1];};
  const withPot=Object.values(__kl.FORMS).filter(r=>names(r).indexOf('potential')>=0).length;
  const pot=__kl.FORMS['c0114']? formOf(__kl.FORMS['c0114'],'potential') : null;
  // glosses that mean the same thing can no longer be two options in one question
  const c=__kl.IDX['c1792'];
  const opts=__kl.makeQuestion('mcJE','c1792');
  const texts=opts? opts.opts.map(o=>o.text) : [];
  // the duplicate card is never introduced
  const dupIn=__kl.pools().nw.filter(k=>k.split('|')[0]==='c1225').length;
  // a sound question is answered in the listening direction
  const au=__kl.makeQuestion('mcAudio','c0000');
  return {withPot, pot, texts, dupIn, auKey:au?au.key:null,
          logLen:__kl.S.log.length};
});
ok(r.withPot>=240,'the verbs that have a potential carry it ('+r.withPot+' rows)');
ok(await p.evaluate(()=>{ const f=__kl.FORMS; const d={};
   for(const c of __kl.DECK) d[c.id]=c.romaji;
   const none=Object.keys(f).filter(k=>['dekiru','aru','wakaru','mieru','kikoeru'].includes(d[k]));
   const names=r=>{const o=[];for(let i=0;i+2<r.length;i+=3)o.push(r[i]);return o;};
   return none.every(k=>names(f[k]).indexOf('potential')<0); }),
   'and the verbs that have none are not given one (dekiru, aru, wakaru, mieru)');
ok(r.pot==='たべられます','and it is right for an ichidan verb ('+r.pot+', taberaremasu, can eat)');
ok(new Set(r.texts.map(t=>t.split(/[\/,(]/)[0].trim().toLowerCase())).size===r.texts.length,
   'no two options in a question mean the same thing');
ok(r.dupIn===0,'the duplicate card is never introduced');
ok(r.auKey==='c0000|a','a listening question is answered in the listening direction ('+r.auKey+')');
ok(errs.length===0, errs[0]||'no errors');
await ctx.close();
}

console.log('\n10. the typed verdict is written down, and weakness knows the direction');
{
const log=[];
const base0=Date.now()/1000-5*86400;
for(let i=0;i<6;i++) log.push([Math.round(base0+i*3600),0,0,4,2,1]);        // reads it perfectly
for(let i=0;i<6;i++) log.push([Math.round(base0+i*3600),0,1,1,2,1,0]);      // cannot say it
const it12=items(12); it12['c0000|e']=card(3);
const {ctx,p}=await open(base(it12,{log}));
const r=await p.evaluate(()=>({
  j:__kl.dirAccuracy('c0000','j'), e:__kl.dirAccuracy('c0000','e'),
  worst:__kl.worstDirection('c0000'), w:__kl.weakness('c0000'),
  typed:__kl.typedAccuracy(30)}));
ok(r.j && r.j.acc===1,'reading is scored on its own and is perfect');
ok(r.e && r.e.acc===0,'saying it is scored on its own and is failing');
ok(r.worst && r.worst.dir==='e','the worst direction is named');
ok(r.w && /saying it/.test(r.w.why),'and the weakness reason says so ("'+(r.w?r.w.why:'')+'")');
ok(r.typed.n===6 && r.typed.pct===0,'the typed verdicts are in the log and measurable ('+r.typed.n+' typed, '+Math.round(r.typed.pct*100)+'% right)');
await ctx.close();
}

await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'EVERY COUNCIL CHANGE IS LIVE IN THE APP'));
process.exit(fails.length?1:0);})();
