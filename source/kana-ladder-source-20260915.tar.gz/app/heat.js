const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const today=new Date(Date.now()-14400000).toISOString().slice(0,10);  // the app's day starts at 04:00 UTC
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(t=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  const now=Date.now(), items={};
  // 31 words started, 14 of them past the recognised threshold, all in the first area
  for(let i=0;i<31;i++){ const id='c'+String(i).padStart(4,'0');
    const iv = i<14 ? 12 : 2;
    items[id+'|j']=[1,0,4,2.5,iv,now+iv*86400000,0,0,6,6,4,iv,now-86400000]; }
  for(let i=0;i<21;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|e']=[1,0,2,2.5,2,now+2*86400000,0,0,3,3,5,2,now-86400000]; }
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:99,
    settings:{sched:"fsrs",retention:0.9,newPerDay:0,revCap:150,reverse:"grad",separate:true,
      sentences:true,conj:true,listen:true,tts:true,autoPlay:false,typing:false,kanji:true,theme:"dark"},
    daily:{key:t,newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,consDone:0,
      noNew:false,buried:{},done:{},missed:{}},
    hist:{}, streak:{cur:3,best:3,last:""}, life:{ans:200,ok:180,practice:0},
    backup:{last:""}, notes:{}, susp:{}, pfail:{}, log:[], items}));
}, today);
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(700);

console.log('\nthe area tiles say what each number means');
const cells=await p.evaluate(()=>[...document.querySelectorAll('#heat .cell')].map(e=>({
  name:e.querySelector('.nm').textContent,
  pc:e.querySelector('.pc').textContent,
  ct:e.querySelector('.ct').textContent})));
console.log('   '+cells[0].name+': '+cells[0].pc+'  "'+cells[0].ct+'"');
ok(/of \d+ recognised$/.test(cells[0].ct),'the count line reads "N of M recognised", not "N/M words"');
ok(cells.length===15,'all 15 areas are drawn');
const note=await p.$eval('#heatNote',e=>e.textContent);
ok(/different measures/.test(note),'a note explains why the percentage and the count differ');

// the percentage really is the average strength, and the count really is the >=0.5 tally
const truth=await p.evaluate(()=>{
  const S=__kl.S, DECK=__kl.DECK, sp=__kl.scoreParts();
  const g=sp.sec[0];
  return {pc:Math.round(g.sum/g.n*100), known:g.known, n:g.n};
});
ok(cells[0].pc===truth.pc+'%','the percentage matches an independent recomputation ('+cells[0].pc+')');
ok(cells[0].ct===truth.known+' of '+truth.n+' recognised','and so does the count ("'+cells[0].ct+'")');
ok(truth.pc!==Math.round(truth.known/truth.n*100),
   'the two genuinely differ ('+truth.pc+'% strength vs '+Math.round(truth.known/truth.n*100)+'% by count), which is why the note is needed');
const aux=await p.$eval('#lvlAux',e=>e.textContent);
ok(aux===truth.known+' words recognised','"words recognised" on the level card uses the same tally ("'+aux+'")');
ok(errs.length===0, errs.length? errs.join(' | ') : 'no page errors');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'THE AREA TILES ARE UNAMBIGUOUS'));
process.exit(fails.length?1:0);})();
