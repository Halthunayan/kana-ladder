/* Ryan's own backup, restored into the built app, to see exactly which words
   the focus queue picks and why. */
const {chromium}=require('playwright');
const fs=require('fs');
let fails=0,n=0;
const ok=(c,m)=>{n++; if(!c){fails++;console.log("  FAIL  "+m);} else console.log("  ok    "+m);};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await (await b.newContext({viewport:{width:393,height:852}})).newPage();
p.setDefaultTimeout(5000);
const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
/* seed the saved state before the app boots, so it loads through its own path */
const blob=fs.readFileSync('/tmp/bk.json','utf8');
await p.addInitScript(function(raw){
  try{ localStorage.setItem('kanaladder.v1', raw); }catch(e){}
}, blob);
await p.goto('http://127.0.0.1:8100/index.html',{timeout:15000});
await p.waitForFunction(()=>window.__kl&&window.__kl.DECK.length>0,null,{timeout:15000});
await p.waitForTimeout(1500);

const out=await p.evaluate(()=>{
  const k=window.__kl;
  const weak=k.weakWords();
  return {
    items:Object.keys(k.S.items).length,
    logRows:k.S.log.length,
    weak:weak.map(w=>{
      const c=k.IDX[w.id], cr=k.cleanRun(k.answerLog(w.id));
      const it=k.S.items[w.id+'|j'];
      return {romaji:c.romaji, en:c.en.slice(0,24), score:+w.score.toFixed(2),
              why:w.why, run:cr.run, days:cr.days, iv:it?+it.iv.toFixed(1):0};
    }),
    denwa:(function(){
      const cr=k.cleanRun(k.answerLog('c0022'));
      return {inQueue: !!k.weakness('c0022'), run:cr.run, days:cr.days};
    })(),
    queueLen:k.focusQueue().length
  };
});

console.log("  restored items: "+out.items+"   log rows: "+out.logRows);
ok(out.items>0,'the backup restored');
/* His save file moves under this test, so pinning the exact figures made it
   fail the first time he sent a newer backup. The property is what matters:
   a clean run long enough and spread over enough days clears a word. */
ok(out.denwa.run>=6 && out.denwa.days>=5,
   'denwa (telephone) has a clean run worth believing: '+out.denwa.run+' correct over '+out.denwa.days+' days');
ok(out.denwa.inQueue===false,'denwa is no longer treated as weak');
console.log("\n  focus pool now: "+out.weak.length+" words");
out.weak.forEach(w=>console.log("    "+w.score.toFixed(2)+"  "+w.romaji.padEnd(20)+" run="+w.run+"/"+w.days+"d  "+w.why));
/* The pool is the words that are failing plus the ones not yet settled. A word
   the scheduler still wants back within the week has not survived a real gap,
   so a three day clean run does not clear it; six in a row does, and on a
   settled card three is enough. Before this, freshly taught words cleared
   themselves and Focus never saw the numbers at all. */
/* A count cannot be pinned either: the pool grows with the deck. What must
   hold is that it is a selection and not simply everything he has met. */
ok(out.weak.length < out.items*0.4,
   'the pool is a selection, the failing and the unsettled, not everything ('
   +out.weak.length+' of '+out.items+' cards)');
ok(out.weak.every(w=>w.why && w.why.length>0),
   'and every word in it says why it is there');
ok(out.weak.every(w=>w.iv<7 || !(w.run>=3 && w.days>=2)),
   'no settled word with a clean multi-day run remains in the pool');
ok(!out.weak.some(w=>w.run>=6 && w.days>=2),
   'and no word with six correct in a row remains, however short its interval');
ok(out.weak.every(w=>/lapse|correct|relearning|missed|replayed|still new/.test(w.why)),
   'every word in the pool has a stated reason');
/* the queue must still react instantly when a known word is missed */
const back=await p.evaluate(()=>{
  const k=window.__kl, out={};
  out.clear = !k.weakness('c0022');
  k.S.daily.missed = k.S.daily.missed || {};
  k.S.daily.missed['c0022|j']=1;
  const w=k.weakness('c0022');
  out.afterMiss = w ? {score:+w.score.toFixed(2), why:w.why} : null;
  delete k.S.daily.missed['c0022|j'];
  k.S.pfail['c0022|j']=1;
  const w2=k.weakness('c0022');
  out.afterPracticeMiss = w2 ? {score:+w2.score.toFixed(2), why:w2.why} : null;
  delete k.S.pfail['c0022|j'];
  // a wrong answer in the log must break the run
  k.S.log.push([Math.round(Date.now()/1000), k.IDX['c0022']._i, 0, 1, 1, 1]);
  const w3=k.weakness('c0022');
  out.afterWrongAnswer = w3 ? {score:+w3.score.toFixed(2), why:w3.why} : null;
  out.runAfterWrong = k.cleanRun(k.answerLog('c0022')).run;
  k.S.log.pop();
  return out;
});
console.log("");
ok(back.clear===true,'denwa starts clear');
ok(!!back.afterMiss,'missing it today puts it straight back -> '+(back.afterMiss?back.afterMiss.score+' ('+back.afterMiss.why+')':'nothing'));
ok(!!back.afterPracticeMiss,'missing it in practice puts it back -> '+(back.afterPracticeMiss?back.afterPracticeMiss.score+' ('+back.afterPracticeMiss.why+')':'nothing'));
ok(back.runAfterWrong===0,'one wrong answer resets the run to 0 (got '+back.runAfterWrong+')');
ok(!!back.afterWrongAnswer,'and the word returns to the pool -> '+(back.afterWrongAnswer?back.afterWrongAnswer.score+' ('+back.afterWrongAnswer.why+')':'nothing'));

ok(errs.length===0,'no uncaught page errors'+(errs.length?': '+errs[0]:''));
await b.close();
console.log(fails? "\n"+fails+" FAILURES of "+n : "\nFOCUS NOW FOLLOWS RECENT RESULTS ("+n+" checks)");
process.exit(fails?1:0);
})();
