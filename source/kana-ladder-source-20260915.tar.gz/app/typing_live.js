/* The shipped bundle through the real session flow: reach a typing question,
   type a spelling that used to be marked wrong, read the verdict the app paints. */
const {chromium}=require('playwright');
let fails=0,n=0;
const ok=(c,m)=>{n++; if(!c){fails++;console.log("  FAIL  "+m);} else console.log("  ok    "+m);};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://127.0.0.1:8100/index.html'); await p.waitForTimeout(1600);
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(350);
await p.selectOption('#setRev2','now'); await p.waitForTimeout(200);
await p.click('#setType'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(300);
await p.click('#startBtn'); await p.waitForTimeout(500);

async function grade(){
  await p.waitForSelector('#showBtn',{state:'visible',timeout:3000}).catch(()=>{});
  await p.click('#showBtn').catch(()=>{});
  await p.waitForSelector('.grade.g2',{state:'visible',timeout:3000}).catch(()=>{});
  await p.click('.grade.g2').catch(()=>{}); await p.waitForTimeout(50);
}
async function reachTyping(limit){
  for(let i=0;i<limit;i++){
    if(await p.$('#typeIn')){
      const w=await p.evaluate(()=>{ const k=window.__kl; const s=k.sess();
        const c=k.IDX[s.key.split('|')[0]]; return c?c.romaji:null; });
      if(w) return w;
    }
    await grade();
  }
  return null;
}

/* 1. a kunrei / devoiced spelling of the same word is accepted */
const want=await reachTyping(70);
ok(!!want,'reached a typing question ("'+want+'")');
if(want){
  let alt=want.replace(/desu\b/,'des').replace(/masu\b/,'mas')
              .replace(/shi/g,'si').replace(/tsu/g,'tu').replace(/fu/g,'hu');
  if(alt===want) alt=want;            // nothing to vary, still must be accepted
  await p.fill('#typeIn',alt); await p.waitForTimeout(120);
  await p.click('#typeGo'); await p.waitForTimeout(450);
  const v=await p.$eval('#verdict',e=>e.textContent).catch(()=>'(none)');
  ok(v.trim()==='correct','variant spelling accepted: "'+alt+'" for "'+want+'" -> "'+v.trim()+'"');
  await p.click('#nextBtn').catch(()=>{}); await p.waitForTimeout(350);
}

/* 2. a genuinely wrong answer is still wrong */
const want2=await reachTyping(40);
ok(!!want2,'reached a second typing question');
if(want2){
  await p.fill('#typeIn','zzzz'); await p.waitForTimeout(120);
  await p.click('#typeGo'); await p.waitForTimeout(450);
  const v2=await p.$eval('#verdict',e=>e.textContent).catch(()=>'(none)');
  ok(v2.trim().indexOf('it is')===0,'a wrong answer is still wrong -> "'+v2.trim().slice(0,34)+'"');
}

ok(errs.length===0,'no uncaught page errors'+(errs.length?': '+errs[0]:''));
const sc=await p.evaluate(()=>({sent:window.__kl.SENT.length, deck:window.__kl.DECK.length}));
ok(sc.deck===1812,'deck still 1,812 ('+sc.deck+')');
ok(sc.sent===1442,'1,230 plus 196 trip-window and 19 bound-form sentences ('+sc.sent+')');
await b.close();
console.log(fails? "\n"+fails+" FAILURES of "+n : "\nSHIPPED BUNDLE BEHAVES CORRECTLY ("+n+" checks)");
process.exit(fails?1:0);
})();
