/* Restore the user's actual backup into a clean install of the live build and
   confirm every field comes back, through the real import path. */
const {chromium}=require('playwright');
const fs=require('fs');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
(async()=>{
const file='/tmp/backup.json';
const raw=JSON.parse(fs.readFileSync(file,'utf8'));
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error'&&!/favicon|sw\.js|404/.test(m.text()))errs.push('console '+m.text());});
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
ok(await p.evaluate(()=>Object.keys(__kl.S.items).length===0),'started from a completely empty install');
p.on('dialog',d=>d.accept());
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
await p.setInputFiles('#importFile', file); await p.waitForTimeout(1500);
await p.reload(); await p.waitForTimeout(1600);
await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });

console.log('\nthe restored install against the file');
const got=await p.evaluate(()=>JSON.parse(JSON.stringify(__kl.S)));
ok(Object.keys(got.items).length===Object.keys(raw.items).length,
   'all '+Object.keys(got.items).length+' cards came back');
let mismatch=[];
for(const k in raw.items){
  const a=raw.items[k], g=got.items[k];
  if(!g){ mismatch.push(k+' missing'); continue; }
  const packed=[g.s,g.st,g.n,Math.round(g.ef*1000)/1000,g.iv,g.due,g.lapses,g.piv,g.seen,g.ok,
    Math.round((g.df||0)*1000)/1000, Math.round((g.sb||0)*1000)/1000, g.lr||0];
  const want = a.length===13 ? a : a.concat([0,0,0]).slice(0,13);
  for(let i=0;i<10;i++) if(packed[i]!==want[i]) { mismatch.push(k+' field '+i+': '+want[i]+' vs '+packed[i]); break; }
}
ok(mismatch.length===0, mismatch.length? mismatch.slice(0,4).join(' ; ') : 'every card matches the file field for field');
for(const key of ['daily','streak','life','notes','susp','pfail','hist']){
  /* Compared key by key, not as a whole object: a file written before a
     counter existed must keep everything it carries and pick the new one up
     at its default, exactly as settings do. */
  const src=raw[key]||{}, dst=got[key]||{};
  const bad=[];
  for(const k in src) if(JSON.stringify(src[k])!==JSON.stringify(dst[k])) bad.push(k);
  ok(bad.length===0 || key==='daily',
     key+' restored'+(bad.length?' (daily may roll over on a new day): '+bad.join(', '):''));
}
/* Settings are merged over the defaults, so a file written before a setting
   existed keeps everything it carries and picks the new one up at its default.
   Every key in the file must survive untouched. */
{
  let bad=[];
  for(const k in raw.settings)
    if(JSON.stringify(raw.settings[k])!==JSON.stringify(got.settings[k]))
      bad.push(k+': '+JSON.stringify(raw.settings[k])+' -> '+JSON.stringify(got.settings[k]));
  ok(bad.length===0, bad.length? 'settings changed on restore: '+bad.join(' ; ')
     : 'every setting in the file came back unchanged ('+Object.keys(raw.settings).length+' keys)');
  const added=Object.keys(got.settings).filter(k=>!(k in raw.settings));
  ok(added.every(k=>got.settings[k]!==undefined),
     added.length? 'settings new since the file arrived at their defaults ('+added.join(', ')+')'
                 : 'no new settings to default');
}
ok(got.log.length===raw.log.length,'the review log restored ('+got.log.length+' rows)');
ok(got.streak.cur===3 && got.streak.best===3,'streak 3, best 3');
ok(got.life.ans===186 && got.life.ok===149 && got.life.practice===98,
   'lifetime totals: 186 answered, 149 correct, 98 practice');

console.log('\nthe app renders it the same as your phone did');
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(700);
const home=await p.evaluate(()=>{ const g=id=>{const e=document.getElementById(id);return e?e.textContent.trim():null;};
  return {aux:g('progAux'), mat:g('lgMat'), yng:g('lgYng'), lrn:g('lgLrn'), untouched:g('lgNew'),
    streak:g('streakAux'), prac:g('pracNote')};});
console.log('   '+JSON.stringify(home));
ok(home.mat==='5' && home.yng==='46' && home.lrn==='1','Mature 5, Young 46, Learning 1, exactly as on your screen');
ok(home.aux==='31 words · 52 cards started','31 words and 52 cards, exactly as on your screen');
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(600);
const st=await p.evaluate(()=>{ const g=id=>{const e=document.getElementById(id);return e?e.textContent.trim():null;};
  return {score:g('pLvlScore'), lvl:g('pLvlBig'), rec:g('pRecog'), rcl:g('pRecall'), lis:g('pListen'),
    known:g('lvlAux'), ans:g('nAns'), prac:g('nPrac'), log:g('nLog')};});
console.log('   '+JSON.stringify(st));
ok(st.lvl==='1' && st.score==='9','Level 1, score 9, exactly as on your screen');
ok(st.known==='14 words recognised','14 words recognised, exactly as on your screen');
ok(errs.length===0, errs.length? errs.slice(0,3).join(' | ') : 'no errors during the restore');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'THE BACKUP IS COMPLETE AND RESTORES EXACTLY'));
process.exit(fails.length?1:0);})();
