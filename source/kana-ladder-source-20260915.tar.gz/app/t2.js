const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);
async function run(n,easy){for(let i=0;i<n;i++){ if(await p.$('#s-review.on')===null) break;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
  const g=await p.$(easy?'.grade.g3':'.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} }}
await p.click('#startBtn'); await run(300,true);
let r=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));return{
  screen:document.querySelector('.screen.on').id, newDone:d.daily.newDone, credit:d.daily.credit,
  note:document.getElementById('startNote').textContent, btn:document.getElementById('startBtn').textContent,
  mode:document.getElementById('startBtn').dataset.mode, lvl:document.getElementById('lvlN').textContent,
  score:document.getElementById('lvlScore').textContent};});
console.log('SOFT CAP all-easy:',JSON.stringify(r));
await p.click('#startBtn'); await p.waitForTimeout(300);
console.log('AHEAD session:',JSON.stringify(await p.evaluate(()=>({screen:document.querySelector('.screen.on').id,cnt:document.getElementById('revCount').textContent}))));
await run(60,false);
console.log('after ahead:',JSON.stringify(await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
 return {items:Object.keys(d.items).length,newDone:d.daily.newDone,screen:document.querySelector('.screen.on').id};})));
await p.click('#quitBtn'); await p.waitForTimeout(300);
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(500);
console.log('HEATMAP:',JSON.stringify(await p.evaluate(()=>({cells:document.querySelectorAll('#heat .cell').length,
  lvl:document.getElementById('pLvlBig').textContent, ja:document.getElementById('pLvlJa').textContent,
  desc:document.getElementById('pLvlDesc').textContent.slice(0,46),
  recog:document.getElementById('pRecog').textContent, recall:document.getElementById('pRecall').textContent,
  first:document.querySelector('#heat .cell').innerText.replace(/\n/g,' | ')}))));
await p.screenshot({path:'v2-stats.png',fullPage:true});
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400); await p.screenshot({path:'v2-home.png'});
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(300); await p.screenshot({path:'v2-set.png',fullPage:true});
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
