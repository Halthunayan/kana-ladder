const {chromium}=require('playwright');
(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const errs=[];
  for(const [theme,name] of [['light','light'],['dark','dark']]){
    const p=await b.newPage({viewport:{width:393,height:852},deviceScaleFactor:2,colorScheme:theme});
    p.on('console',m=>{if(m.type()==='error')errs.push(name+': '+m.text());});
    p.on('pageerror',e=>errs.push(name+' PAGEERROR: '+e.message));
    await p.goto('file://' + require('path').resolve(__dirname, 'preview.html'));
    await p.waitForTimeout(1200);
    await p.screenshot({path:`shot-home-${name}.png`});
    if(theme==='light'){
      await p.click('#startBtn'); await p.waitForTimeout(400);
      await p.screenshot({path:'shot-front.png'});
      await p.click('#showBtn'); await p.waitForTimeout(400);
      await p.screenshot({path:'shot-back.png'});
      // answer a few to exercise the engine
      for(let i=0;i<6;i++){ await p.click('.grade.g2'); await p.waitForTimeout(120);
        const vis=await p.$('#showBtn'); if(vis){await p.click('#showBtn'); await p.waitForTimeout(120);} }
      await p.screenshot({path:'shot-mid.png'});
      await p.click('#quitBtn'); await p.waitForTimeout(300);
      await p.screenshot({path:'shot-home2.png'});
      await p.click('.tab[data-go="browse"]'); await p.waitForTimeout(300);
      await p.screenshot({path:'shot-browse.png'});
      await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(300);
      await p.screenshot({path:'shot-stats.png',fullPage:true});
      await p.click('.tab[data-go="set"]'); await p.waitForTimeout(300);
      await p.screenshot({path:'shot-set.png',fullPage:true});
    }
    await p.close();
  }
  await b.close();
  console.log(errs.length?'CONSOLE ERRORS:\n'+errs.join('\n'):'no console errors');
})();
