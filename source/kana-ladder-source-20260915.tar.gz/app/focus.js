const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const today=new Date(Date.now()-14400000).toISOString().slice(0,10);  // the app's day starts at 04:00 UTC
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(t=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  window.__spoken=[];
  window.SpeechSynthesisUtterance=function(x){this.text=x;this.rate=1;this.voice=null;this.lang='';};
  try{ window.speechSynthesis.speak=u=>window.__spoken.push(u.text);
       window.speechSynthesis.cancel=()=>{}; }catch(e){}
  const now=Date.now(), items={}, pfail={};
  // 60 solid words, then a handful that are plainly going badly
  for(let i=0;i<60;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,6,2.6,45,now+45*86400000,0,0,12,12,3.5,45,now-2*86400000]; }
  // weak in different ways, so every signal is exercised
  items['c0114|j']=[1,0,4,1.4,2,now+86400000,6,0,20,9,8.6,2,now-86400000];   // lapses + low accuracy
  items['c0115|j']=[2,0,3,1.5,1,now+600000,3,9,14,7,8.0,1,now-86400000];     // relearning
  items['c0116|j']=[1,0,5,1.9,2,now+86400000,2,0,16,10,7.2,2,now-86400000];  // short interval
  items['c0180|j']=[1,0,5,2.0,4,now+4*86400000,1,0,12,8,6.4,4,now-86400000]; // some lapses
  items['c0182|j']=[1,0,5,2.1,5,now+5*86400000,0,0,10,6,6.9,5,now-86400000]; // poor accuracy only
  items['c0145|j']=[1,0,5,2.0,3,now+3*86400000,2,0,11,7,7.1,3,now-86400000]; // an adjective
  pfail['c0116|j']=2;
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:99,
    settings:{sched:"fsrs",retention:0.9,newPerDay:0,revCap:150,reverse:"grad",separate:true,
      sentences:true,sentPerDay:4,conj:true,conjPerDay:2,listen:true,tts:true,autoPlay:true,
      typing:false,kanji:true,theme:"dark"},
    daily:{key:t,newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,consDone:0,
      noNew:false,buried:{},done:{},missed:{'c0182|j':1}},
    hist:{}, streak:{cur:3,best:3,last:""}, life:{ans:400,ok:340,practice:0},
    backup:{last:""}, notes:{}, susp:{}, pfail, log:[], items}));
}, today);
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error'&&!/favicon|sw\.js|404/.test(m.text()))errs.push('console '+m.text());});
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(500);

console.log('\n1. two buttons, and focus picks only the weak words');
ok(await p.evaluate(()=>!!document.getElementById('focusBtn')),
   'Regular and Focus are both on the study screen');
const w=await p.evaluate(()=>__kl.weakWords());
console.log('   weak list: '+w.map(x=>x.id+' ('+x.score.toFixed(1)+': '+x.why+')').join('  |  '));
ok(w.length>=5 && w.length<=10,'only the genuinely weak words qualify ('+w.length+' of 66 met)');
const strong=w.filter(x=>['c0000','c0001','c0002','c0030'].indexOf(x.id)>=0);
ok(strong.length===0,'none of the 45-day-interval words were called weak');
ok(w[0].id==='c0114'||w[0].id==='c0115','the worst word ranks first ('+w[0].id+')');
const sub=await p.$eval('#focusBtnSub',e=>e.textContent);
ok(/word/.test(sub)&&/three angles/.test(sub),'the button says what it will do ("'+sub+'")');

console.log('\n2. the queue mixes question types over those words only');
const q=await p.evaluate(()=>__kl.focusQueue());
const kinds={}; q.forEach(x=>kinds[x.kind]=(kinds[x.kind]||0)+1);
const ids=[...new Set(q.map(x=>x.id))];
console.log('   '+q.length+' questions over '+ids.length+' words: '+JSON.stringify(kinds));
ok(Object.keys(kinds).length>=4,'at least four different question types were built');
ok(ids.every(id=>w.some(x=>x.id===id)),'every question is about a word on the weak list');
ok(q.every(x=>x.kind==='flip'||x.kind==='type'||(x.opts&&x.opts.length===4)),
   'every multiple choice question offers exactly four options');
ok(q.every(x=>x.kind==='flip'||x.kind==='type'||x.opts.filter(o=>o.ok).length===1),
   'exactly one option is correct in each');
const dup=q.filter(x=>x.opts && new Set(x.opts.map(o=>o.text)).size!==4);
ok(dup.length===0,'no question repeats an option');

console.log('\n3. answering is self-grading and nothing is scheduled');
const before=await p.evaluate(()=>JSON.stringify(__kl.S.items));
await p.click('#focusBtn'); await p.waitForTimeout(600);
ok(await p.evaluate(()=>!!document.querySelector('#s-review.on')),'the focus session started');
ok((await p.$eval('#revCount',e=>e.textContent)).indexOf('focus')===0,'the counter says focus');
const why=await p.$eval('#pracLabel',e=>e.textContent);
ok(/Focus/.test(why)&&/nothing here changes your schedule/.test(why),
   'the banner names the reason this word is here ("'+why.slice(0,70)+'...")');
const plan=await p.evaluate(()=>__kl.sess().plan);
let right=0, wrong=0, typed=0, flips=0, seenKinds={};
for(let i=0;i<45;i++){
  const on=await p.evaluate(()=>!!document.querySelector('#s-review.on')); if(!on) break;
  const cur=await p.evaluate(()=>({kind:__kl.sess().q.kind, id:__kl.sess().q.id,
    qi:__kl.sess().qi, answered:__kl.sess().answered,
    dis:document.querySelectorAll('.opt-btn[disabled]').length,
    opts:document.querySelectorAll('.opt-btn').length}));
  console.log('   step '+i+' '+JSON.stringify(cur));
  seenKinds[cur.kind]=1;
  if(cur.kind==='type'){
    const good=await p.evaluate(()=>__kl.IDX[__kl.sess().q.id].romaji);
    await p.fill('#typeIn', i%2 ? good : 'zzz');
    await p.click('#typeGo'); typed++;
  } else if(cur.kind==='flip'){
    await p.click('#showBtn'); await p.waitForTimeout(60);
    await p.click('.grade.g3'); flips++;
    await p.waitForTimeout(80); continue;
  } else {
    const pick=await p.evaluate(n=>{ const o=__kl.sess().q.opts;
      const c=o.findIndex(x=>x.ok); return n%3===0 ? (c+1)%4 : c; }, i);
    await p.click('.opt-btn[data-opt="'+pick+'"]');
  }
  await p.waitForTimeout(150);
  const res=await p.evaluate(()=>({
    wrong:document.querySelectorAll('.opt-btn.wrong').length ||
          (document.querySelector('#verdict.no')?1:0)}));
  if(res.wrong) wrong++; else right++;
  // a correct answer advances on its own after a moment; a wrong one waits to be read
  const qiBefore=await p.evaluate(()=>__kl.sess().qi);
  await p.waitForTimeout(1200);
  const moved=await p.evaluate(q0=>!__kl.sess().on || __kl.sess().qi!==q0, qiBefore);
  if(!moved){ const nb=await p.$('#nextBtn'); if(nb && await nb.isVisible()) await nb.click(); }
  await p.waitForTimeout(150);
}
console.log('   answered: '+(right+wrong)+' ('+wrong+' deliberately wrong), types seen: '+Object.keys(seenKinds).join(', '));
ok(right+wrong+flips===plan,'the whole session ran through ('+(right+wrong+flips)+' of '+plan+')');
ok(await p.evaluate(()=>!document.querySelector('#s-review.on')),'and the review screen closed at the end');
ok(Object.keys(seenKinds).length>=3,'several question types actually appeared');
const after=await p.evaluate(()=>JSON.stringify(__kl.S.items));
ok(after===before,'not one scheduled card changed');
ok(await p.evaluate(()=>__kl.S.life.practice>0),'the answers counted as practice, separately');
ok(errs.length===0, errs.length? errs.slice(0,3).join(' | ') : 'no page errors');

console.log('\n4. the mixed draw still exists as the fallback');
await p.evaluate(()=>{ const c=document.getElementById('sheetClose'); if(c) c.click(); });
await p.waitForTimeout(200);
await p.click('#quitBtn').catch(()=>{}); await p.waitForTimeout(500);
await p.evaluate(()=>__kl.startPractice()); await p.waitForTimeout(600);
ok(await p.evaluate(()=>__kl.sess().focus===false),'the mixed draw does not run in focus mode');
ok(await p.evaluate(()=>typeof __kl.sess().queue[0]==='string'),'and still uses plain card keys');
ok((await p.$eval('#revCount',e=>e.textContent)).indexOf('practice')===0,'its counter still says practice');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'FOCUS MODE WORKS'));
process.exit(fails.length?1:0);})();
