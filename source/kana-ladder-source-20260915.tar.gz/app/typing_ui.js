/* The wiring from the typing field to the verdict, in the shipped bundle.
   Focus mode is where a TYPE IT question appears, so the session is started
   for real and then advanced to the first typing question in its own queue. */
const {chromium}=require('playwright');
let fails=0,n=0;
const ok=(c,m)=>{n++; if(!c){fails++;console.log("  FAIL  "+m);} else console.log("  ok    "+m);};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const p=await (await b.newContext({viewport:{width:393,height:852}})).newPage();
p.setDefaultTimeout(4000);
const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
await p.goto('http://127.0.0.1:8100/index.html',{timeout:15000});
await p.waitForFunction(()=>window.__kl&&window.__kl.DECK.length>0,null,{timeout:15000});

async function typingQuestion(){
  return await p.evaluate(()=>{
    const k=window.__kl, now=Date.now();
    k.S.settings.typing=true; k.S.settings.reverse='now';
    for(let i=1;i<=40;i++){ const id='c'+String(i).padStart(4,'0');
      if(!k.IDX[id])continue;
      ['j','e'].forEach(d=>{ k.S.items[id+'|'+d]={s:1,st:0,n:6,iv:2,due:now-1000,
        lr:now-4e8, ok:4,seen:10,lapses:3,df:7.6,sb:1,piv:2}; }); }
    k.startFocus();
    const s=k.sess();
    const vary=r=>r.replace(/desu\b/,'des').replace(/masu\b/,'mas')
                   .replace(/shi/g,'si').replace(/tsu/g,'tu')
                   .replace(/ou/g,'\u014d').replace(/uu/g,'\u016b')
                   .replace(/chi/g,'ti').replace(/ji/g,'zi');
    // a question whose answer actually has an alternative spelling, so the
    // check cannot silently pass on a word that has nothing to vary
    for(let i=0;i<s.queue.length;i++){
      const q=s.queue[i]; if(q.kind!=='type') continue;
      const c=k.IDX[q.id]; if(!c || vary(c.romaji)===c.romaji) continue;
      s.qi=i; s.q=q; s.key=q.key; s.shown=false; s.answered=false;
      k.renderCard();
      return c.romaji;
    }
    return null;
  });
}

const want=await typingQuestion();
ok(!!want,'a TYPE IT question is on screen ("'+want+'")');
ok(!!(await p.$('#typeIn')),'the typing field rendered');

if(want){
  /* a different spelling of the same Japanese: devoiced ending, kunrei, or a
     macron for the long vowel. At least one of these always applies. */
  const alt=want.replace(/desu\b/,'des').replace(/masu\b/,'mas')
                .replace(/shi/g,'si').replace(/tsu/g,'tu')
                .replace(/ou/g,'\u014d').replace(/uu/g,'\u016b')
                .replace(/chi/g,'ti').replace(/ji/g,'zi');
  ok(alt!==want,'the spelling under test differs from the stored answer ("'+alt+'" vs "'+want+'")');
  await p.fill('#typeIn',alt);
  await p.click('#typeGo');
  await p.waitForTimeout(400);
  const v=(await p.$eval('#verdict',e=>e.textContent).catch(()=>'(none)')).trim();
  ok(v==='correct','the app marks the variant spelling correct -> "'+v+'"');

  // and a genuinely wrong answer is still wrong
  const again=await typingQuestion();
  if(again){
    await p.fill('#typeIn','zzzz');
    await p.click('#typeGo');
    await p.waitForTimeout(400);
    const v2=(await p.$eval('#verdict',e=>e.textContent).catch(()=>'(none)')).trim();
    ok(v2.indexOf('it is')===0,'a wrong answer is still wrong -> "'+v2.slice(0,34)+'"');
  }
}
ok(errs.length===0,'no uncaught page errors'+(errs.length?': '+errs[0]:''));
const sc=await p.evaluate(()=>({sent:window.__kl.SENT.length,deck:window.__kl.DECK.length}));
ok(sc.deck===1812,'deck still 1,812');
ok(sc.sent===1442,'1,230 plus 196 trip-window and 19 bound-form sentences');
await b.close();
console.log(fails? "\n"+fails+" FAILURES of "+n : "\nUI WIRING CONFIRMED ("+n+" checks)");
process.exit(fails?1:0);
})();
