const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
const p=await ctx.newPage();
p.on('pageerror',e=>console.log('PAGEERROR',e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1200);
await p.click('#startBtn');
for(let i=0;i<40;i++){ if(await p.$('#s-review.on')===null) break;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(15);}
  const g=await p.$('.grade.g3'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(15);} }
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(300);
await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  for(const k in d.items) d.items[k][5]-=2*86400000;
  d.daily={key:'',newDone:0,revDone:0,ans:0,ok:0,credit:0,buried:{}};
  d.rev=(d.rev||0)+500;
  localStorage.setItem('kanaladder.v1',JSON.stringify(d));});
await p.reload(); await p.waitForTimeout(1500);
console.log(JSON.stringify(await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {tileNew:document.querySelector('#tileNew .n').textContent,
          tileDue:document.querySelector('#tileDue .n').textContent,
          items:Object.keys(d.items).length,
          dailyKey:d.daily.key, newDone:d.daily.newDone, revDone:d.daily.revDone,
          buried:Object.keys(d.daily.buried||{}).length,
          sampleDue:Object.values(d.items).slice(0,3).map(a=>[a[0],a[4],new Date(a[5]).toISOString().slice(0,16)]),
          now:new Date().toISOString().slice(0,16)};}),null,1));
await b.close();})();
