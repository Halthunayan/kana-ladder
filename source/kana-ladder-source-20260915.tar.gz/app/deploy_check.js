/* A deployment rehearsal: the exact bundle served from a sub path, the way a
   GitHub Pages project repo serves it, loaded with his real save file. Boot,
   the audio manifest, a clip from the library, the service worker, an offline
   reload and a drive. Point DEPLOY_BASE at the live URL to run it against a
   real deployment. */
const {chromium}=require('playwright');const fs=require('fs');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const BASE=process.env.DEPLOY_BASE||'http://localhost:8111/kana-ladder/';
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(raw=>{
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>[{lang:'ja-JP',name:'Kyoko'},{lang:'en-US',name:'Sam'}]});}catch(e){}
  window.__spoke=[];
  window.SpeechSynthesisUtterance=function(t){this.text=t;this.rate=1;this.voice=null;this.lang='';};
  try{window.speechSynthesis.speak=u=>{window.__spoke.push(u.text);setTimeout(()=>u.onend&&u.onend(),120);};
      window.speechSynthesis.cancel=()=>{};}catch(e){}
  try{Object.defineProperty(navigator,'wakeLock',{value:{request:()=>Promise.resolve({release(){},addEventListener(){}})}});}catch(e){}
  try{ localStorage.setItem('kanaladder.v1', raw); }catch(e){}
}, fs.readFileSync('/home/claude/state/backup-0915.json','utf8'));
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error'){const l=m.location()||{};errs.push(m.text()+' @ '+(l.url||'?'));}});
const bad=[]; p.on('response',r=>{ if(!r.ok() && r.url().indexOf(BASE)===0) bad.push(r.status()+' '+r.url()); });

console.log('\n1. it loads from a sub path, the way GitHub Pages serves a project repo');
await p.goto(BASE+'index.html');
await p.waitForFunction(()=>window.__kl&&__kl.DECK.length>0,null,{timeout:25000});
await p.waitForTimeout(2500);
const boot=await p.evaluate(()=>({words:__kl.DECK.length, sents:__kl.SENT.length,
  items:Object.keys(__kl.S.items).length, rev:__kl.S.rev, man:!!__kl.AUD.man,
  sw:!!navigator.serviceWorker.controller, lvl:document.getElementById('lvlN').textContent}));
ok(boot.words>1700 && boot.sents>1400,'the deck loads whole ('+boot.words+' words, '+boot.sents+' sentences)');
ok(boot.items===120 && boot.rev===1052,'his 15 September save restores exactly ('+boot.items+' cards, rev '+boot.rev+')');
ok(boot.man===true,'the audio manifest is fetched at boot from the sub path');
ok(bad.length===0, bad.length? 'failed requests: '+bad.slice(0,3).join(' ; ') : 'every asset resolved');

console.log('\n2. a clip really plays from the library at this path');
const clip=await p.evaluate(async()=>{
  __kl.AUD.log.length=0; window.__spoke=[];
  const okc=await __kl.audPlay('wj:c0000',1);
  return {okc, log:__kl.AUD.log.map(x=>x.k)};
});
ok(clip.log.length===1,'a word plays from the sprite ('+JSON.stringify(clip.log)+')');

console.log('\n3. the service worker installs and the app works offline');
await p.waitForFunction(()=>!!navigator.serviceWorker.controller,null,{timeout:20000}).catch(()=>{});
const swOn=await p.evaluate(()=>!!navigator.serviceWorker.controller);
ok(swOn,'the service worker took control');
await ctx.setOffline(true);
await p.reload(); await p.waitForTimeout(2500);
const off=await p.evaluate(()=>({t:document.title,
  words:(document.getElementById('deck-data')?JSON.parse(document.getElementById('deck-data').textContent).length:0),
  items:Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length}));
ok(/Kana/.test(off.t) && off.words>1700,'it reopens offline with the whole deck');
ok(off.items===120,'and his progress is intact offline');
await ctx.setOffline(false);

console.log('\n4. a drive runs on his real deck');
await p.reload(); await p.waitForFunction(()=>window.__kl&&__kl.DECK.length>0,null,{timeout:25000});
await p.waitForTimeout(1500);
await p.evaluate(()=>__kl.carClock(100));
await p.click('#carBtn').catch(()=>{});
await p.waitForTimeout(400);
const drive=await p.evaluate(async()=>{
  for(let i=0;i<400;i++){ if(!__kl.CAR.running) break; await new Promise(r=>setTimeout(r,100)); }
  const started=__kl.CAR.started;
  const passes=[];
  for(const e of (__kl.AUD.log||[])){
    const id=(e.k||'').split(':')[1];
    if(!id) continue;
    if(!passes.length || passes[passes.length-1].id!==id) passes.push({id, el:Math.round((e.t-started)*100)});
  }
  const heard=__kl.CAR.heard; __kl.carFinish(); __kl.carClock(1);
  return {passes, heard};
});
const seq=drive.passes.map(x=>x.id);
const b2b=seq.filter((x,i)=>i>0&&x===seq[i-1]).length;
const seen={}; let tooSoon=0;
for(const r of drive.passes){ if(seen[r.id]!==undefined && r.el-seen[r.id]<38000) tooSoon++; seen[r.id]=r.el; }
ok(drive.heard>4,'the drive plays on his real deck ('+drive.heard+' passes counted)');
ok(b2b===0,'no word twice in a row'+(b2b?' ('+b2b+')':''));
ok(tooSoon===0,'every repeat waited its gap'+(tooSoon?' ('+tooSoon+' did not)':''));

console.log('\n5. no errors anywhere in the rehearsal');
ok(errs.length===0, errs.length? errs.slice(0,2).join(' | ') : 'clean');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'DEPLOYMENT REHEARSAL PASSED'));
process.exit(fails.length?1:0);})();
