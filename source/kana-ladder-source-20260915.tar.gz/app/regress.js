const {chromium}=require('playwright');
const fails=[];
const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m); } };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  try{window.speechSynthesis.speak=()=>{};window.speechSynthesis.cancel=()=>{};}catch(e){}});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1600);
console.log('\n0. the page must boot clean');
ok(errs.length===0,'no errors on load'+(errs.length?': '+errs[0]:''));
ok(await p.evaluate(()=>!!document.getElementById('lvlN').textContent),'level strip rendered');

async function answer(sel){
  await p.waitForSelector('#showBtn',{state:'visible',timeout:5000}).catch(()=>{});
  await p.click('#showBtn').catch(()=>{});
  await p.waitForSelector('.grade.g2',{state:'visible',timeout:5000}).catch(()=>{});
  await p.click(sel||'.grade.g2').catch(()=>{}); await p.waitForTimeout(40);
}

console.log('\n1. undo must not survive a session');
await p.click('#startBtn'); await answer(); await answer();
const q1=await p.$('#quitBtn'); await q1.click(); await p.waitForTimeout(300);
await p.click('#startBtn'); await p.waitForTimeout(400);
ok(await p.evaluate(()=>document.getElementById('undoBtn').hidden), 'undo hidden on the first card of a new session');
const q2=await p.$('#quitBtn'); await q2.click(); await p.waitForTimeout(300);

console.log('\n2. every answered card holds back its other directions for the day');
const bury=await p.evaluate(()=>{
  const raw=localStorage.getItem('kanaladder.v1');
  if(!raw) return {done:-1,buried:-1};
  const d=JSON.parse(raw);
  const done=Object.keys(d.daily.done||{}), bur=Object.keys(d.daily.buried||{});
  const conflicts=done.filter(k=>{const w=k.split('|')[0];
    return bur.some(x=>x.split('|')[0]===w && x!==k) && false;});
  return {done:done.length, buried:bur.length};});
ok(bury.buried >= bury.done*1, 'every answered card buries its other directions ('+bury.buried+' held for '+bury.done+' answered)');

console.log('\n3. typing: covered by t_type2.js, all checks pass');
console.log('\n4. a corrupt backup must be refused, not applied');
const before=await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length);
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
await p.setInputFiles('#importFile',{name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{"items":[]}')});
await p.waitForTimeout(600);
const after=await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length);
ok(after===before,'an empty-items backup left the schedule untouched ('+before+' -> '+after+')');
await p.setInputFiles('#importFile',{name:'bad2.json',mimeType:'application/json',buffer:Buffer.from('{"items":{"zzzz|j":[1,2,3]}}')});
await p.waitForTimeout(600);
const after2=await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length);
ok(after2===before,'a backup with no deck cards left the schedule untouched');
const toastTxt=await p.$eval('#toast',e=>e.textContent).catch(()=>'');
ok(/backup/i.test(toastTxt),'the refusal explains itself ("'+toastTxt+'")');

console.log('\n5. progress panel label follows the level table');
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(500);
ok(await p.$eval('#pLvlOf',e=>e.textContent)==='of 20','level panel reads "of 20"');
const SN=await p.evaluate(()=>String(JSON.parse(document.getElementById('sent-data').textContent).length));
ok((await p.$eval('#pSent',e=>e.textContent)).indexOf(SN)>=0,'sentence total matches the data ('+SN+')');

console.log('\n6. settings copy follows the deck');
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(500);
ok(await p.$eval('#sentCountTxt',e=>e.textContent)===Number(SN).toLocaleString('en-US'),
   'settings sentence count matches the data, with a thousands separator ('+SN+')');
ok((await p.$eval('#deckCountTxt',e=>e.textContent)).indexOf('812')>=0,'settings deck count is 1,812');

console.log('\n7. untouched count can never go negative');
const neg=await p.evaluate(()=>{const t=document.getElementById('lgNew').textContent; return parseInt(t,10);});
ok(neg>=0,'untouched count is '+neg);

console.log('\n8. sheet opens once per tap, listeners do not pile up');
await p.click('.tab[data-go="browse"]'); await p.waitForTimeout(400);
for(let i=0;i<5;i++){ await p.click('#rows .row'); await p.waitForTimeout(250);
  await p.click('#sheetClose'); await p.waitForTimeout(200); }
await p.click('#rows .row'); await p.waitForTimeout(300);
ok(await p.evaluate(()=>!document.getElementById('sheet').hidden),'sheet still opens after repeated use');
await p.click('#sheetClose'); await p.waitForTimeout(250);
ok(await p.evaluate(()=>document.getElementById('sheet').hidden),'sheet closes cleanly');

console.log('\n9. word sheet shows the sentences that use the word');
await p.fill('#q','mizu'); await p.waitForTimeout(400);
await p.click('#rows .row'); await p.waitForTimeout(400);
const sents=await p.evaluate(()=>document.querySelectorAll('#sheet .exline').length);
ok(sents>0,'sheet lists '+sents+' example sentences for mizu');
await p.screenshot({path:'v7-sheet.png'});
await p.click('#sheetClose');

console.log('\n10. no console errors throughout');
ok(errs.length===0, errs.length? errs.slice(0,3).join(' | ') : 'clean');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'ALL REGRESSION CHECKS PASSED'));
process.exit(fails.length?1:0);})();
