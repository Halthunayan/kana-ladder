const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1800);
console.log('boot:',JSON.stringify(await p.evaluate(()=>({
  words:JSON.parse(document.getElementById('deck-data').textContent).length,
  sents:JSON.parse(document.getElementById('sent-data').textContent).length,
  lvl:document.getElementById('lvlN').textContent, btn:document.getElementById('startBtn').textContent}))));

async function run(n,sel){const seen=[];
  for(let i=0;i<n;i++){ if(await p.$('#s-review.on')===null) break;
    await p.waitForSelector('#showBtn',{state:'visible',timeout:4000}).catch(()=>{});
    seen.push(await p.$eval('#dirChip',e=>e.textContent));
    await p.click('#showBtn'); await p.waitForSelector('.grade.g2',{state:'visible',timeout:4000});
    await p.click(sel||'.grade.g2'); await p.waitForTimeout(45); }
  return seen;}

await p.click('#startBtn');
await p.waitForSelector('#showBtn',{state:'visible'}); await p.click('#showBtn');
await p.click('.grade.g2'); await p.waitForTimeout(300);
console.log('undo visible after 1 answer:',await p.evaluate(()=>!document.getElementById('undoBtn').hidden));
const before=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));return {items:Object.keys(d.items).length,ans:d.daily.ans};});
await p.click('#undoBtn'); await p.waitForTimeout(400);
const after=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));return {items:Object.keys(d.items).length,ans:d.daily.ans};});
console.log('undo:',JSON.stringify(before),'->',JSON.stringify(after));

const dirs=await run(400);
console.log('directions served:',JSON.stringify(dirs.reduce((a,d)=>{a[d]=(a[d]||0)+1;return a;},{})));
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(400);
console.log('state:',JSON.stringify(await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const k=Object.keys(d.items);
  return {items:k.length, listening:k.filter(x=>x.endsWith('|a')).length, sentences:k.filter(x=>x[0]==='s').length,
          newDone:d.daily.newDone, sentDone:d.daily.sentDone};})));

await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(600);
console.log('progress:',JSON.stringify(await p.evaluate(()=>({recog:document.getElementById('pRecog').textContent,
  recall:document.getElementById('pRecall').textContent, listen:document.getElementById('pListen').textContent,
  sent:document.getElementById('pSent').textContent, cells:document.querySelectorAll('#heat .cell').length}))));

await p.click('.tab[data-go="browse"]'); await p.waitForTimeout(500);
await p.selectOption('#filt','sent'); await p.waitForTimeout(400);
console.log('browse sentences:',await p.evaluate(()=>document.querySelectorAll('#rows .row').length+' rows | '+document.getElementById('browseCount').textContent));
await p.click('#rows .row'); await p.waitForTimeout(500);
console.log('sheet open:',await p.evaluate(()=>!document.getElementById('sheet').hidden),'| actions:',await p.evaluate(()=>!!document.getElementById('sheetSusp')));
await p.screenshot({path:'v5-sheet.png'});
await p.click('#sheetSusp'); await p.waitForTimeout(400);
console.log('after set aside:',await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));return Object.keys(d.susp||{}).length+' suspended';}));
await p.click('#sheetClose'); await p.waitForTimeout(300);
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(700); await p.screenshot({path:'v5-set.png',fullPage:true});
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
