const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  const now=Date.now(), items={}, done={}, buried={};
  // 29 words: all |j in review, 17 of them also |e in review. 5 mature (>=21d), 41 young.
  let mat=0;
  for(let i=0;i<29;i++){ const id='c'+String(i).padStart(4,'0');
    const iv = i<5 ? 30 : 5;
    items[id+'|j']=[1,0,4,2.5,iv,now+iv*86400000,0,0,6,6,5,iv,now-86400000];
    done[id+'|j']=1;
    if(i<17){ items[id+'|e']=[1,0,3,2.5,3,now+3*86400000,0,0,4,4,5,3,now-86400000]; done[id+'|e']=1; }
    buried[id+'|a']=1; if(i>=17) buried[id+'|e']=1;
  }
  items['s001|j']=[1,0,2,2.5,4,now+4*86400000,0,0,3,3,5,4,now-86400000];   // a sentence card
  items['g001|j']=[1,0,2,2.5,4,now+4*86400000,0,0,3,3,5,4,now-86400000];   // a conjugation anchor
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:99,
    settings:{sched:"fsrs",retention:0.9,newPerDay:2,revCap:150,reverse:"grad",separate:true,
      sentences:true,sentPerDay:4,conj:true,conjPerDay:2,listen:true,tts:true,theme:"dark",kanji:true},
    daily:{key:new Date(Date.now()-14400000).toISOString().slice(0,10),newDone:2,revDone:60,ans:84,ok:78,credit:0,
      sentDone:0,conjDone:0,consDone:2,noNew:false,buried,done,missed:{}},
    hist:{}, streak:{cur:2,best:2,last:""}, life:{ans:159,ok:150,practice:0}, log:[], items}));
});
const p=await ctx.newPage();
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1500);
await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(600);
const r=await p.evaluate(()=>{
  const g=id=>document.getElementById(id)?document.getElementById(id).textContent:null;
  const S=__kl.S, DECK=__kl.DECK, SENT=__kl.SENT, CONJ=__kl.CONJ;
  let cards=0, deckWords=new Set(), allIds=new Set();
  for(const k in S.items){ cards++; const id=k.split('|')[0]; allIds.add(id);
    if(/^c/.test(id)) deckWords.add(id); }
  const perWord=3;
  return {
    screen:{ mat:g('lgMat'), yng:g('lgYng'), lrn:g('lgLrn'), untouched:g('lgNew'),
             aux:g('progAux'), note:g('startNote')||g('aheadNote'), prac:g('pracNote'),
             pracSub:g('focusBtnSub'), start:g('startBtn') },
    truth:{ cardsInState:cards, distinctDeckWords:deckWords.size, distinctAnyIds:allIds.size,
            deckSlots:DECK.length*perWord, sentSlots:SENT.length*2, conjSlots:CONJ.length,
            grandTotal:DECK.length*perWord+SENT.length*2+CONJ.length }
  };
});
console.log(JSON.stringify(r.screen,null,1));
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const m=+r.screen.mat, y=+r.screen.yng, l=+r.screen.lrn, u=+r.screen.untouched.replace(/[^0-9]/g,'');
console.log('\ndeck progress adds up');
ok(m+y+l+u===r.truth.grandTotal,
  'mature + young + learning + untouched = every schedulable card ('+(m+y+l+u)+' vs '+r.truth.grandTotal+')');
ok(m+y+l===r.truth.cardsInState,'the three touched buckets equal the cards actually in rotation ('+(m+y+l)+')');
ok(/^29 words · 48 cards started$/.test(r.screen.aux),
  'the header counts 29 words and 48 cards, so the two units cannot be confused ("'+r.screen.aux+'")');
ok(r.truth.distinctAnyIds>r.truth.distinctDeckWords,
  'the state really did contain non-word cards ('+r.truth.distinctAnyIds+' ids over '+r.truth.distinctDeckWords+' words), so that check meant something');
ok(r.screen.prac==='48 in rotation' && /48 you have met/.test(r.screen.pracSub),
  'practice reports the same rotation size as the rail');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'ALL NUMBER CHECKS PASSED'));
process.exit(fails.length?1:0);})();
