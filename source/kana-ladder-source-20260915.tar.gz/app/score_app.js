const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const mk=(dirs)=>{ const now=Date.now(), items={};
  for(let i=0;i<200;i++){ const id='c'+String(i).padStart(4,'0');
    dirs.forEach(d=>{ items[id+'|'+d]=[1,0,4,2.5,40,now+40*86400000,0,0,8,7,5,40,now-2*86400000]; }); }
  return {rev:99, settings:{sched:"fsrs",retention:0.9,newPerDay:12,revCap:150,reverse:"grad",
    listen:true,sentences:true,conj:true,theme:"dark",tts:true,kanji:true},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0}, hist:{}, streak:{cur:1,best:1,last:""},
    life:{ans:10,ok:9,practice:0}, log:[], items}; };
const probe=async(dirs,label)=>{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(st=>localStorage.setItem('kanaladder.v1',JSON.stringify(st)), mk(dirs));
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1500);
  await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.checked=true; });
  await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(200);
  await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400);
  const r=await p.evaluate(()=>{
    const sp=__kl.pools && window.__kl ? null : null;
    const parts=window.__kl ? null : null;
    return {
      strip:[...document.querySelectorAll('#skillStrip .sk')].map(e=>e.textContent.replace(/\s+/g,' ').trim()),
      weakHidden:document.getElementById('skillWeak').hidden,
      weak:document.getElementById('skillWeak').textContent,
      score:document.getElementById('lvlScore').textContent,
      lvl:document.getElementById('lvlN').textContent
    };
  });
  await ctx.close();
  console.log('  '+label+' -> '+r.lvl+', '+r.score+' | '+r.strip.join('  |  '));
  return {...r, errs};
};
console.log('\n1. the strip shows all three skills');
const a=await probe(['j'],'200 words, recognition only');
ok(a.strip.length===3,'three skill bars are drawn');
ok(/Recognition/.test(a.strip[0]) && /Listening/.test(a.strip[2]),'they are recognition, recall and listening');
ok(!a.weakHidden && /(listening|recall)/i.test(a.weak) && /0 percent/.test(a.weak),
   'the weak-skill note names an untouched skill: "'+a.weak+'"');

console.log('\n2. a balanced learner gets no weak-skill warning');
const c=await probe(['j','e','a'],'200 words in all three directions');
ok(c.weakHidden,'no warning when the three are level');

console.log('\n3. listening genuinely moves the score');
const sa=parseInt(a.score), sc=parseInt(c.score);
ok(sc>sa, 'all three directions scores higher than recognition alone ('+sc+' vs '+sa+')');

console.log('\n4. turning a direction off renormalises instead of capping');
{
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(st=>localStorage.setItem('kanaladder.v1',JSON.stringify(st)), mk(['j']));
const p=await ctx.newPage();
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
await p.evaluate(()=>{ __kl.TTS.ja=true; });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400);
const before=await p.evaluate(()=>document.getElementById('lvlScore').textContent);
await p.evaluate(()=>{ __kl.S.settings.listen=false; __kl.S.settings.reverse="off"; });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(300);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(500);
const after=await p.evaluate(()=>document.getElementById('lvlScore').textContent);
const nBars=await p.evaluate(()=>document.querySelectorAll('#skillStrip .sk').length);
console.log('  score with both off: '+before+' -> '+after+', bars: '+nBars);
ok(parseInt(after)>parseInt(before),'the score rises rather than being capped when directions are switched off');
ok(nBars===1,'only the live skill is shown');
await ctx.close();
}
console.log('\n5. the progress screen states the live weights');
{
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(st=>localStorage.setItem('kanaladder.v1',JSON.stringify(st)), mk(['j','e']));
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
await p.evaluate(()=>{ __kl.TTS.ja=true; });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(600);
const note=await p.$eval('#scoreNote',e=>e.textContent);
ok(/recognition \d+ percent/.test(note) && /listening \d+ percent/.test(note),'the note reports the weights: "'+note.slice(0,90)+'..."');
ok((await p.$eval('#pConj',e=>e.textContent)).indexOf('/ 40')>0,'conjugation rules are counted separately');
ok((await p.$$eval('#skillStrip2 .sk',e=>e.length))===3,'the progress screen repeats the strip');
ok(errs.length===0, errs.length? errs.join(' | ') : 'no page errors');
await ctx.close();
}
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'ALL SCORE CHECKS PASSED'));
process.exit(fails.length?1:0);})();
