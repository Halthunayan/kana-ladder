/* Focus mode, every scenario: boundary states, each question type on its own
   both right and wrong, interruptions, and what the session leaves behind. */
const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const today=new Date(Date.now()-14400000).toISOString().slice(0,10);  // the app's day starts at 04:00 UTC
const now=Date.now();
const strongCard=iv=>[1,0,6,2.6,iv,now+iv*86400000,0,0,12,12,3.4,iv,now-2*86400000];
const weakCard =(lapses,seen,okN,df)=>[1,0,4,1.5,2,now+86400000,lapses,0,seen,okN,df,2,now-86400000];
const base=(items,over)=>Object.assign({rev:99,
  settings:Object.assign({sched:"fsrs",retention:0.9,newPerDay:0,revCap:150,reverse:"grad",separate:true,
    sentences:true,sentPerDay:4,conj:true,conjPerDay:2,listen:true,tts:true,autoPlay:false,
    typing:false,kanji:true,theme:"dark"},(over||{}).settings),
  daily:Object.assign({key:today,newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,
    consDone:0,noNew:false,buried:{},done:{},missed:{}},(over||{}).daily),
  hist:{}, streak:{cur:3,best:3,last:""}, life:{ans:400,ok:340,practice:0},
  backup:{last:""}, notes:{}, susp:(over||{}).susp||{}, pfail:(over||{}).pfail||{}, log:[], items},
  {});
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const open=async(st,noTts)=>{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(([s,silent])=>{
    const v=silent?[]:[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    window.__spoken=[];
    window.SpeechSynthesisUtterance=function(x){this.text=x;this.rate=1;this.voice=null;this.lang='';};
    try{ window.speechSynthesis.speak=u=>window.__spoken.push(u.text);
         window.speechSynthesis.cancel=()=>{}; }catch(e){}
    localStorage.setItem('kanaladder.v1',JSON.stringify(s));
  }, [st, !!noTts]);
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error'&&!/favicon|sw\.js|404/.test(m.text()))errs.push('console '+m.text());});
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1300);
  if(!noTts) await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });
  await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(150);
  await p.click('.tab[data-go="home"]'); await p.waitForTimeout(350);
  return {ctx,p,errs};
};
// answer the current question; how==='right'|'wrong'
const answerOne=async(p,how)=>{
  const q=await p.evaluate(()=>({kind:__kl.sess().q.kind, id:__kl.sess().q.id}));
  if(q.kind==='flip'){
    await p.click('#showBtn'); await p.waitForTimeout(80);
    await p.click(how==='right'?'.grade.g3':'.grade.g0'); await p.waitForTimeout(150);
    return {kind:q.kind, advanced:true};
  }
  if(q.kind==='type'){
    const good=await p.evaluate(()=>__kl.IDX[__kl.sess().q.id].romaji);
    await p.fill('#typeIn', how==='right'?good:'zzzz');
    await p.click('#typeGo');
  } else {
    const i=await p.evaluate(h=>{ const o=__kl.sess().q.opts, c=o.findIndex(x=>x.ok);
      return h==='right'?c:(c+1)%4; }, how);
    await p.click('.opt-btn[data-opt="'+i+'"]');
  }
  await p.waitForTimeout(160);
  return {kind:q.kind, advanced:false};
};
const settle=async(p)=>{
  const qi=await p.evaluate(()=>__kl.sess().on?__kl.sess().qi:-1);
  await p.waitForTimeout(1200);
  const moved=await p.evaluate(q0=>!__kl.sess().on||__kl.sess().qi!==q0, qi);
  if(!moved){ const nb=await p.$('#nextBtn'); if(nb&&await nb.isVisible()) await nb.click(); }
  await p.waitForTimeout(180);
};

console.log('\n1. boundary states');
{
const {ctx,p,errs}=await open(base({}));
ok(!await p.evaluate(()=>document.getElementById('focusBtn').disabled),'Practice is never disabled now, it falls back to a mixed draw');
ok((await p.$eval('#focusBtnSub',e=>e.textContent)).indexOf('nothing met yet')>=0,'and says there is nothing to draw from yet');
await p.evaluate(()=>document.getElementById('focusBtn').click());
await p.waitForTimeout(300);
ok(!(await p.evaluate(()=>!!document.querySelector('#s-review.on'))),'clicking it on an empty deck starts nothing');
ok(errs.length===0,'no errors from the empty case');
await ctx.close();
}
{
const items={}; for(let i=0;i<80;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
const {ctx,p}=await open(base(items));
ok(await p.evaluate(()=>__kl.weakWords().length===0),'80 strong words produce no weak list');
ok(!await p.evaluate(()=>document.getElementById('focusBtn').disabled),'Practice stays live with nothing weak');
ok((await p.$eval('#focusBtnSub',e=>e.textContent)).indexOf('mixed draw')>=0,'and offers the mixed draw instead');
await ctx.close();
}
{
const items={}; for(let i=0;i<40;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
items['c0114|j']=weakCard(5,20,9,8.5);
const {ctx,p,errs}=await open(base(items));
const w=await p.evaluate(()=>__kl.weakWords());
ok(w.length===1,'exactly one weak word is found');
await p.click('#focusBtn'); await p.waitForTimeout(600);
const n=await p.evaluate(()=>__kl.sess().queue.length);
ok(n>=1 && n<=3,'it builds a short session of '+n+' questions, not an empty one');
for(let i=0;i<n+2;i++){ if(!(await p.evaluate(()=>!!document.querySelector('#s-review.on')))) break;
  await answerOne(p,'right'); await settle(p); }
ok(!(await p.evaluate(()=>!!document.querySelector('#s-review.on'))),'the short session finishes cleanly');
ok(errs.length===0, errs.length?errs.join(' | '):'no errors on the one-word session');
await ctx.close();
}
{
// a word only just met is new, not weak, however badly the first answer went
const items={'c0114|j':[1,0,1,2.5,1,now+86400000,0,0,2,1,5.0,1,now-86400000]};
const {ctx,p}=await open(base(items));
ok(await p.evaluate(()=>__kl.weakWords().length===0),'a word seen twice with no lapse is not called weak');
await ctx.close();
}
{
// a set-aside word must never be dragged into focus
const items={}; for(let i=0;i<40;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
items['c0114|j']=weakCard(6,20,8,8.8);
const {ctx,p}=await open(base(items,{susp:{'c0114|j':1}}));
ok(await p.evaluate(()=>__kl.weakWords().every(x=>x.id!=='c0114')),'a word you have set aside is excluded');
await ctx.close();
}

console.log('\n2. the question mix adapts to what a word supports');
{
const items={}; for(let i=0;i<60;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
items['c0114|j']=weakCard(6,20,9,8.6);            // taberu: a verb, has forms
items['c0074|j']=weakCard(5,18,8,8.2);            // hito: a noun, no forms
const {ctx,p}=await open(base(items));
const kinds=await p.evaluate(()=>{
  const out={}; for(const id of ['c0114','c0074']){ out[id]=[];
    for(let i=0;i<40;i++){ const q=__kl.focusQueue().filter(x=>x.id===id);
      q.forEach(x=>{ if(out[id].indexOf(x.kind)<0) out[id].push(x.kind); }); } }
  return out; });
console.log('   verb  c0114 -> '+kinds.c0114.sort().join(', '));
console.log('   noun  c0074 -> '+kinds.c0074.sort().join(', '));
ok(kinds.c0114.indexOf('conj')>=0,'a verb gets conjugation questions');
ok(kinds.c0074.indexOf('conj')<0,'a noun never gets a conjugation question');
await ctx.close();
}
{
/* Nothing able to speak Japanese: no device voice and no pre-rendered library.
   Only then must listening questions stay out. With the library reachable a
   phone with no Japanese voice can still hear the word, which is the whole
   reason the library exists, so both halves are asserted here. */
const items={}; for(let i=0;i<60;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
items['c0114|j']=weakCard(6,20,9,8.6);
const {ctx,p}=await open(base(items), true);
const kinds=await p.evaluate(()=>{ const out=[]; const m=__kl.AUD.man; __kl.AUD.man=null;
  for(let i=0;i<40;i++) __kl.focusQueue().forEach(x=>{ if(out.indexOf(x.kind)<0) out.push(x.kind); });
  __kl.AUD.man=m; return out; });
ok(kinds.indexOf('mcAudio')<0,'with nothing able to speak Japanese, no listening question is built ('+kinds.sort().join(', ')+')');
const withLib=await p.evaluate(()=>{ const out=[];
  for(let i=0;i<40;i++) __kl.focusQueue().forEach(x=>{ if(out.indexOf(x.kind)<0) out.push(x.kind); });
  return out; });
ok(withLib.indexOf('mcAudio')>=0,
   'but with the pre-rendered library they are offered again ('+withLib.sort().join(', ')+')');
await ctx.close();
}

console.log('\n3. every question type, answered right and answered wrong');
{
const items={}; for(let i=0;i<220;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
['c0114','c0115','c0116','c0145','c0180','c0182','c0186','c0187'].forEach((id,n)=>{
  items[id+'|j']=weakCard(6-(n%3),20,9,8.6-(n*0.2)); });
const seenRight={}, seenWrong={};
for(const how of ['right','wrong']){
  const {ctx,p,errs}=await open(base(items));
  await p.click('#focusBtn'); await p.waitForTimeout(600);
  let guard=0;
  while(await p.evaluate(()=>!!document.querySelector('#s-review.on')) && guard++<60){
    const before=await p.evaluate(()=>({qi:__kl.sess().qi, kind:__kl.sess().q.kind}));
    await answerOne(p,how);
    if(before.kind!=='flip'){
      const st=await p.evaluate(()=>({
        right:document.querySelectorAll('.opt-btn.right').length,
        wrong:document.querySelectorAll('.opt-btn.wrong').length,
        verdict:document.querySelector('#verdict')?document.querySelector('#verdict').className:'',
        next:!!document.getElementById('nextBtn'),
        answered:__kl.sess().answered}));
      const bag = how==='right'?seenRight:seenWrong;
      bag[before.kind]=bag[before.kind]||{n:0,marked:0,next:0};
      bag[before.kind].n++;
      if(before.kind==='type'){ if(/\b(ok|no)\b/.test(st.verdict)) bag[before.kind].marked++; }
      else if(how==='right'? st.right>0 : st.wrong>0) bag[before.kind].marked++;
      if(st.next) bag[before.kind].next++;
    }
    await settle(p);
  }
  const bag=how==='right'?seenRight:seenWrong;
  const types=Object.keys(bag);
  console.log('   '+how+': '+types.map(t=>t+' x'+bag[t].n).join(', '));
  ok(types.length>=4,how+' answers exercised '+types.length+' question types');
  ok(types.every(t=>bag[t].marked===bag[t].n),how+' answers were all marked on screen');
  ok(types.every(t=>bag[t].next===bag[t].n),'a Next button was always offered after a '+how+' answer');
  ok(errs.length===0, errs.length?errs.slice(0,2).join(' | '):'no errors during the '+how+' pass');
  await ctx.close();
}
}

console.log('\n4. interruptions cannot break a session');
{
const items={}; for(let i=0;i<120;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
['c0114','c0115','c0116'].forEach(id=>{ items[id+'|j']=weakCard(6,20,9,8.6); });
const {ctx,p,errs}=await open(base(items));
await p.click('#focusBtn'); await p.waitForTimeout(600);
// hammer one option twice: the second tap must do nothing
let guard=0;
while(await p.evaluate(()=>__kl.sess().q.kind==='flip') && guard++<10){ await answerOne(p,'right'); await settle(p); }
const qi0=await p.evaluate(()=>__kl.sess().qi);
const kind0=await p.evaluate(()=>__kl.sess().q.kind);
if(kind0!=='type'){
  const i0=await p.evaluate(()=>__kl.sess().q.opts.findIndex(x=>x.ok));
  await p.click('.opt-btn[data-opt="'+i0+'"]', {force:true});
  await p.click('.opt-btn[data-opt="'+((i0+1)%4)+'"]', {force:true});
  await p.waitForTimeout(120);
  ok(await p.evaluate(q=>__kl.sess().qi===q, qi0),'a second tap on another option is ignored');
  ok((await p.evaluate(()=>document.querySelectorAll('.opt-btn.wrong').length))===0,
     'the ignored tap did not mark a wrong answer');
  await settle(p);
}
// tapping the card body must not repaint the grade row over the feedback.
// Only an option question shows feedback, so skip past any free-recall ones.
let tapGuard=0;
while(await p.evaluate(()=>__kl.sess().on && __kl.sess().q.kind==='flip') && tapGuard++<10){
  await answerOne(p,'right'); await settle(p); }
if(await p.evaluate(()=>__kl.sess().on && __kl.sess().q.kind!=='flip')){
  await answerOne(p,'wrong');
  await p.click('#faceFront',{position:{x:20,y:20}}).catch(()=>{});
  await p.waitForTimeout(200);
  ok(await p.evaluate(()=>!!document.getElementById('nextBtn')),'tapping the card leaves the answer feedback in place');
  ok((await p.evaluate(()=>document.querySelectorAll('.grade.prac').length))===0,
     'and does not bring up Missed it / Got it');
  await settle(p);
} else { console.log('  SKIP  no option question left for the tap check'); }
// on an option question the keyboard must not answer it; on a free-recall
// question the usual practice shortcuts are correct and stay available
let kbGuard=0;
while(await p.evaluate(()=>__kl.sess().on && __kl.sess().q.kind==='flip') && kbGuard++<10){
  await answerOne(p,'right'); await settle(p); }
if(await p.evaluate(()=>__kl.sess().on && __kl.sess().q.kind!=='flip')){
  const qi1=await p.evaluate(()=>__kl.sess().qi);
  await p.keyboard.press('Space'); await p.keyboard.press('1'); await p.keyboard.press('2');
  await p.waitForTimeout(250);
  ok(await p.evaluate(q=>__kl.sess().qi===q, qi1),'keyboard shortcuts cannot answer an option question');
  ok((await p.evaluate(()=>document.querySelectorAll('.grade.prac').length))===0,
     'and cannot summon the grade buttons over it');
} else { console.log('  SKIP  no option question left for the keyboard check'); }
// quitting mid-session
await p.click('#quitBtn'); await p.waitForTimeout(500);
ok(!(await p.evaluate(()=>!!document.querySelector('#s-review.on'))),'the X button ends the session');
ok(await p.evaluate(()=>__kl.sess().focus===false && __kl.sess().q===null),'focus state is cleared on quit');
ok(await p.evaluate(()=>!document.getElementById('tabs').classList.contains('hide')),'the tab bar comes back');
ok(await p.evaluate(()=>!!document.querySelector('#s-home.on')),'and it lands on the study screen');
ok(errs.length===0, errs.length?errs.slice(0,2).join(' | '):'no errors from any interruption');
await ctx.close();
}
{
// a reload mid-session must come back to a clean study screen, with progress intact
const items={}; for(let i=0;i<120;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
['c0114','c0115'].forEach(id=>{ items[id+'|j']=weakCard(6,20,9,8.6); });
const {ctx,p,errs}=await open(base(items));
const before=await p.evaluate(()=>JSON.stringify(__kl.S.items));
await p.click('#focusBtn'); await p.waitForTimeout(600);
await answerOne(p,'right'); await settle(p);
await p.reload(); await p.waitForTimeout(1400);
ok(!(await p.evaluate(()=>!!document.querySelector('#s-review.on'))),'a reload does not leave you stranded in a session');
ok(await p.evaluate(b2=>JSON.stringify(__kl.S.items)===b2, before),'and no card was changed by the abandoned session');
ok(errs.length===0,'no errors after the reload');
await ctx.close();
}

console.log('\n5. what a completed session leaves behind');
{
const items={}; for(let i=0;i<120;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
['c0114','c0115','c0116'].forEach(id=>{ items[id+'|j']=weakCard(6,20,9,8.6); });
const {ctx,p,errs}=await open(base(items));
const before=await p.evaluate(()=>JSON.stringify(__kl.S.items));
const lifeBefore=await p.evaluate(()=>__kl.S.life.practice);
const dailyBefore=await p.evaluate(()=>JSON.stringify(__kl.S.daily));
await p.click('#focusBtn'); await p.waitForTimeout(600);
let n=0, guard=0;
while(await p.evaluate(()=>!!document.querySelector('#s-review.on')) && guard++<60){
  await answerOne(p, n%2 ? 'right':'wrong'); await settle(p); n++; }
ok(n>0,'the session ran '+n+' questions to the end');
ok(await p.evaluate(b2=>JSON.stringify(__kl.S.items)===b2, before),'not one scheduled card changed');
ok(await p.evaluate(b2=>JSON.stringify(__kl.S.daily)===b2, dailyBefore),'the daily counters did not move');
const lifeAfter=await p.evaluate(()=>__kl.S.life.practice);
ok(lifeAfter===lifeBefore+n,'practice answers counted separately ('+lifeBefore+' -> '+lifeAfter+')');
const pf=await p.evaluate(()=>Object.keys(__kl.S.pfail||{}));
ok(pf.every(k=>/^c\d+\|/.test(k)),'only real cards were recorded as practice failures ('+pf.length+')');
// the session ends either with a score toast or, when a card was missed twice,
// with the offer to send it back through learning: both are correct endings
const ending=await p.evaluate(()=>{
  const t=document.getElementById('toast'), sh=document.getElementById('sheet');
  return {toast:t?t.textContent:'', sheetUp:sh?!sh.hidden:false,
    sheetTxt:sh&&!sh.hidden?sh.textContent.replace(/\s+/g,' ').slice(0,80):''};});
ok(/recalled/.test(ending.toast) || (ending.sheetUp && /recalled/.test(ending.sheetTxt)),
   'the session reported a score at the end ("'+(ending.toast||ending.sheetTxt)+'")');
ok(!ending.sheetUp || /Reset/.test(ending.sheetTxt) || ending.sheetTxt.length>0,
   'a twice-missed card is offered as a reset rather than reset silently');
ok(errs.length===0, errs.length?errs.slice(0,2).join(' | '):'no errors across a full session');
await ctx.close();
}

console.log('\n6. content of the questions is sound');
{
const items={}; for(let i=0;i<400;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
['c0114','c0115','c0116','c0145','c0180','c0182'].forEach(id=>{ items[id+'|j']=weakCard(6,20,9,8.6); });
const {ctx,p}=await open(base(items));
const bad=await p.evaluate(()=>{
  const out=[];
  for(let round=0;round<60;round++){
    for(const q of __kl.focusQueue()){
      const c=__kl.IDX[q.id];
      if(q.opts){
        const rights=q.opts.filter(o=>o.ok);
        if(rights.length!==1) out.push(q.kind+' '+q.id+': '+rights.length+' correct options');
        if(new Set(q.opts.map(o=>o.text)).size!==q.opts.length) out.push(q.kind+' '+q.id+': repeated option');
        if(q.kind==='mcJE'||q.kind==='mcAudio'){ if(rights[0].text!==c.en) out.push(q.kind+' '+q.id+': wrong answer text'); }
        if(q.kind==='mcEJ'){ if(rights[0].text!==c.kana) out.push(q.kind+' '+q.id+': wrong kana'); }
        if(q.kind==='cloze'){
          if(q.blank.indexOf(c.kana)>=0) out.push('cloze '+q.id+': the word is still visible in the sentence');
          if(q.blank.indexOf('____')<0) out.push('cloze '+q.id+': no gap was made');
          if(rights[0].text!==c.kana) out.push('cloze '+q.id+': wrong answer');
        }
        if(q.kind==='conj'){
          const row=__kl.FORMS[q.id]||[];
          if(row.indexOf(rights[0].text)<0) out.push('conj '+q.id+': answer is not a real form of the word');
          for(const o of q.opts) if(!o.sub) out.push('conj '+q.id+': an option has no romaji');
        }
      }
    }
  }
  return out.slice(0,10); });
ok(bad.length===0, bad.length? bad.join(' ; ') : 'over 60 rebuilds of the queue, no malformed question');
await ctx.close();
}
console.log('\n7. a card missed twice in focus is offered as a reset, never reset silently');
{
const items={}; for(let i=0;i<120;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
items['c0114|j']=weakCard(6,20,9,8.6);
// it already carries one practice failure, so one more miss should trigger the offer
const {ctx,p,errs}=await open(base(items,{pfail:{'c0114|j':1}}));
const before=await p.evaluate(()=>JSON.stringify(__kl.S.items['c0114|j']));
await p.click('#focusBtn'); await p.waitForTimeout(600);
/* This loop used to give up after twenty answers, which did not always reach
   the question about c0114 that the offer depends on, so the check passed and
   failed on the same build. A test that reports noise teaches you to ignore
   the suite. It now runs the whole queue, and stops as soon as the offer is
   up rather than counting answers. */
/* This used to give up after twenty answers, which did not always reach the
   question about c0114 that the offer depends on, so the check passed and
   failed on the same build. The queue is shuffled, so c0114 may not come up
   in one session at all: it now keeps going across sessions until the offer
   is up or the work runs out, which is what "missed twice" actually means. */
let guard=0, sessions=0;
while(guard<200 && sessions<4){
  if(await p.evaluate(()=>!document.getElementById('sheet').hidden)) break;
  if(!await p.evaluate(()=>!!document.querySelector('#s-review.on'))){
    sessions++;
    const fb=await p.$('#focusBtn');
    if(!fb) break;
    await fb.click().catch(()=>{}); await p.waitForTimeout(500);
    if(!await p.evaluate(()=>!!document.querySelector('#s-review.on'))) break;
  }
  await answerOne(p,'wrong'); await settle(p); guard++;
}
await p.waitForFunction(()=>!document.getElementById('sheet').hidden,null,{timeout:4000}).catch(()=>{});
const sheetUp=await p.evaluate(()=>!document.getElementById('sheet').hidden);
ok(sheetUp,'the reset offer appeared after a second miss (after '+guard+' answers, '+sessions+' extra sessions)');
if(sheetUp){
  ok(await p.evaluate(()=>!!document.getElementById('resetSkip')),'declining is possible');
  ok(await p.evaluate(b2=>JSON.stringify(__kl.S.items['c0114|j'])===b2, before),
     'the card was not touched while the offer was still open');
  await p.click('#resetSkip'); await p.waitForTimeout(400);
  ok(await p.evaluate(b2=>JSON.stringify(__kl.S.items['c0114|j'])===b2, before),
     'declining leaves the card exactly as it was');
}
ok(errs.length===0, errs.length?errs.slice(0,2).join(' | '):'no errors on the reset path');
await ctx.close();
}

console.log('\n8. a long session, and two sessions back to back');
{
const items={}; for(let i=0;i<400;i++) items['c'+String(i).padStart(4,'0')+'|j']=strongCard(60);
for(let i=0;i<20;i++){ const id='c'+String(100+i).padStart(4,'0');
  items[id+'|j']=weakCard(2+(i%5),18,8,7.0+(i%3)*0.5); }
const {ctx,p,errs}=await open(base(items));
const w=await p.evaluate(()=>__kl.weakWords().length);
ok(w>=15,w+' weak words are available, more than the 12 a session takes');
await p.click('#focusBtn'); await p.waitForTimeout(600);
const q1=await p.evaluate(()=>({n:__kl.sess().queue.length,
  words:new Set(__kl.sess().queue.map(x=>x.id)).size}));
ok(q1.n<=40,'the session is capped at 40 questions (got '+q1.n+')');
ok(q1.words<=12,'and covers at most 12 words (got '+q1.words+')');
let n=0, guard=0;
while(await p.evaluate(()=>!!document.querySelector('#s-review.on')) && guard++<80){
  await answerOne(p, n%3?'right':'wrong'); await settle(p); n++; }
ok(n===q1.n,'all '+n+' questions were served, none skipped or repeated');
ok(!(await p.evaluate(()=>!!document.querySelector('#s-review.on'))),'the long session ended cleanly');
// straight into a second session
await p.click('#sheetSkip').catch(()=>{});
await p.click('#resetSkip').catch(()=>{});
await p.waitForTimeout(400);
await p.click('#focusBtn'); await p.waitForTimeout(600);
const q2=await p.evaluate(()=>({on:!!document.querySelector('#s-review.on'),
  n:__kl.sess().queue?__kl.sess().queue.length:0, focus:__kl.sess().focus}));
ok(q2.on && q2.focus && q2.n>0,'a second focus session starts straight away ('+q2.n+' questions)');
await p.click('#quitBtn'); await p.waitForTimeout(300);
ok(errs.length===0, errs.length?errs.slice(0,2).join(' | '):'no errors across the long run');
await ctx.close();
}

await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'FOCUS MODE IS SMOOTH IN EVERY SCENARIO'));
process.exit(fails.length?1:0);})();
