const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2,acceptDownloads:true});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1800);
async function run(n){for(let i=0;i<n;i++){ if(await p.$('#s-review.on')===null) break;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(20);}
  const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(20);} }}
await p.click('#startBtn'); await run(30);
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(300);
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(1200);
console.log('storage panel:',JSON.stringify(await p.evaluate(()=>({
  mode:document.getElementById('stMode').textContent,
  persist:document.getElementById('stPersist').textContent,
  usage:document.getElementById('stUsage').textContent,
  backup:document.getElementById('stBackup').textContent,
  note:document.getElementById('stNote').textContent.slice(0,72)}))));
const dl=p.waitForEvent('download',{timeout:8000}).catch(()=>null);
await p.click('#exportBtn'); const d=await dl; await p.waitForTimeout(700);
console.log('download:', d? d.suggestedFilename() : 'none');
console.log('after backup:',JSON.stringify(await p.evaluate(()=>({
  st:document.getElementById('stBackup').textContent,
  saved:JSON.parse(localStorage.getItem('kanaladder.v1')).backup}))));
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400);
console.log('home backup row:',await p.evaluate(()=>document.getElementById('kvBackup').textContent));
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(600); await p.screenshot({path:'v4-set.png',fullPage:true});
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
