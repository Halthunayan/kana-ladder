/* What the current settings actually deliver by the trip date.
   Drives the real scheduler through __kl, one simulated day at a time, and
   reports the load and the coverage. No UI, so 68 days runs in seconds. */
const {chromium}=require('playwright');

const DAYS=parseInt(process.env.DAYS||'68',10);
const ACC=parseFloat(process.env.ACC||'0.84');     // share of answers graded Good or better

const CONFIGS=[
  {name:'as set now (5/4/4/2)',   newPerDay:5, consPerDay:4, sentPerDay:4,  conjPerDay:2},
  {name:'sentences 6 only',       newPerDay:5, consPerDay:4, sentPerDay:6,  conjPerDay:2},
  {name:'sentences 8 only',       newPerDay:5, consPerDay:4, sentPerDay:8,  conjPerDay:2},
  {name:'follow-up 8 only',       newPerDay:5, consPerDay:8, sentPerDay:4,  conjPerDay:2},
];

(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const rows=[];
for(const cfg of CONFIGS){
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(()=>{
    const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    try{window.speechSynthesis.speak=u=>setTimeout(()=>u.onend&&u.onend(),0);
        window.speechSynthesis.cancel=()=>{};}catch(e){}
    // read live, so advancing a day does not need a page reload
    const off=()=>{ try{ return parseInt(localStorage.getItem('__tOffset')||'0',10)||0; }catch(e){ return 0; } };
    const RD=Date, rn=Date.now;
    window.Date=new Proxy(RD,{construct(t,a){return a.length?new t(...a):new t(rn()+off());},
      get(t,k){return k==='now'?(()=>rn()+off()):t[k];}});
  });
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push(e.message));
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1200);
  await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=[{lang:'ja-JP'}]; __kl.TTS.en=[{lang:'en-US'}]; });

  const out=await p.evaluate(async ([cfg,DAYS,ACC])=>{
    const S=__kl.S;
    Object.assign(S.settings,{newPerDay:cfg.newPerDay, consPerDay:cfg.consPerDay,
      sentPerDay:cfg.sentPerDay, conjPerDay:cfg.conjPerDay, sched:'fsrs', retention:0.90,
      revCap:150, listen:true, sentences:true, conj:true, separate:true, softCap:true,
      reverse:'grad', tripDate:''});
    const perDay=[];
    let peak=0, total=0;
    // a deterministic grade stream, so two configs are compared on the same luck
    let seed=12345;
    const rnd=()=>{ seed=(seed*1103515245+12345)&0x7fffffff; return seed/0x7fffffff; };
    for(let day=0; day<DAYS; day++){
      __kl.rollDay();
      let n=0;
      for(let i=0;i<900;i++){
        const k=__kl.pickNext();
        if(!k) break;
        __kl.sess().key=k;
        const r=rnd();
        // Again / Hard / Good / Easy, tuned so the pass rate is ACC
        const g = r > ACC ? 0 : (r > ACC-0.12 ? 1 : (r > 0.10 ? 2 : 3));
        __kl.answer(g);
        n++;
      }
      perDay.push(n); total+=n; if(n>peak) peak=n;
      if(S.log.length>4000) S.log=S.log.slice(-2000);
      const o=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;
      localStorage.setItem('__tOffset',String(o+86400000));
      // the Date proxy reads the offset live, so no reload is needed
    }
    const keys=Object.keys(S.items);
    const wordIds=new Set(keys.filter(k=>k[0]==='c').map(k=>k.split('|')[0]));
    const sentIds=new Set(keys.filter(k=>k[0]==='s'||k[0]==='n').map(k=>k.split('|')[0]));
    const conjIds=new Set(keys.filter(k=>k[0]==='g').map(k=>k.split('|')[0]));
    const known=[...wordIds].filter(id=>{const it=S.items[id+'|j']; return it && it.s===1;});
    const newSent=[...sentIds].filter(id=>/^n[HJ]/.test(id));
    const tail=perDay.slice(-14);
    return {
      days:DAYS, total,
      avg:Math.round(total/DAYS),
      last14:Math.round(tail.reduce((a,c)=>a+c,0)/tail.length),
      peak,
      words:wordIds.size, wordsKnown:known.length,
      sentences:sentIds.size, newSentences:newSent.length,
      conj:conjIds.size,
      lapses:Object.values(S.items).reduce((a,v)=>a+v[6],0),
      due:Object.values(S.items).filter(v=>v[5]<=Date.now()).length,
      errs:0
    };
  },[cfg,DAYS,ACC]);
  out.name=cfg.name; out.cfg=cfg; out.errs=errs.length;
  rows.push(out);
  await ctx.close();
}
await b.close();

const pad=(s,n)=>String(s).padEnd(n);
const rpad=(s,n)=>String(s).padStart(n);
console.log('');
console.log(pad('configuration',30)+rpad('cards/day',10)+rpad('last 2wk',10)+rpad('peak',7)
  +rpad('words',8)+rpad('known',8)+rpad('sents',7)+rpad('new sents',11)+rpad('conj',6));
console.log('-'.repeat(97));
for(const r of rows){
  console.log(pad(r.name,30)+rpad(r.avg,10)+rpad(r.last14,10)+rpad(r.peak,7)
    +rpad(r.words,8)+rpad(r.wordsKnown,8)+rpad(r.sentences,7)+rpad(r.newSentences,11)+rpad(r.conj,6));
}
console.log('');
for(const r of rows) if(r.errs) console.log('ERRORS in '+r.name+': '+r.errs);
console.log(DAYS+' days simulated, pass rate '+Math.round(ACC*100)+'%');
})();
