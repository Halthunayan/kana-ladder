/* The typed-answer matcher, exercised inside the running app rather than in
   isolation, so the deck it is judged against is the one that ships. */
const {chromium}=require('playwright');
let fails=0, n=0;
function ok(c,m){ n++; if(!c){fails++; console.log("  FAIL  "+m);} }

(async()=>{
  const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
  const p=await b.newPage();
  await p.goto('http://127.0.0.1:8100/index.html');
  await p.waitForFunction(()=>window.__kl && window.__kl.DECK && window.__kl.DECK.length>0,null,{timeout:20000});

  const r=await p.evaluate(()=>{
    const M=window.__kl.romajiMatches, K=window.__kl.moraKey, A=window.__kl.answerKeys;
    const DECK=window.__kl.DECK, SENT=window.__kl.SENT, CONJ=window.__kl.CONJ;
    const items=DECK.concat(SENT).concat(CONJ);
    const norm=k=>k.replace(/[。、\s]/g,'');

    // accepted spellings of the same Japanese
    const accept=[
      ["kore wa nan des ka","kore wa nan desu ka"],
      ["korewanandeska","kore wa nan desu ka"],
      ["kore ha nan desu ka","kore wa nan desu ka"],
      ["arigatou gozaimas","arigatou gozaimasu"],
      ["wakarimashta","wakarimashita"],
      ["susi","sushi"], ["tukue","tsukue"], ["huton","futon"],
      ["shimbun","shinbun"], ["ohayou","ohayō"],
      ["  KORE  WA  NAN  DESU  KA  ","kore wa nan desu ka"]
    ];
    // spellings that describe different Japanese and must stay wrong
    const reject=[
      ["biru","biiru"],["koko","koukou"],["kare","karee"],["kite","kitte"],
      ["ojisan","ojiisan"],["akeru","ageru"],["amai","akai"],["yuki","yuuki"],
      ["karui","akarui"],["ha","wa"],["he","e"],["desho","deshou"],
      ["","kore"],["   ","kore"],["zzz","kore"],["123","kore"]
    ];

    // exhaustive corpus safety: no answer may be accepted for a different kana
    const own={};
    items.forEach(c=>{ const k=K(c.romaji); if(k){ (own[k]=own[k]||{})[norm(c.kana)]=1; } });
    let cross=0, self=0, firstCross=null;
    items.forEach(a=>{
      if(!M(a.romaji,a.romaji)) self++;
      const keys=A(a.romaji);
      for(const k in keys){
        const hits=own[k]; if(!hits) continue;
        for(const kn in hits) if(kn!==norm(a.kana)){ cross++; if(!firstCross) firstCross=a.romaji+" -> "+kn; }
      }
    });

    return {
      accept: accept.map(c=>[c[0],c[1],M(c[0],c[1])]),
      reject: reject.map(c=>[c[0],c[1],M(c[0],c[1])]),
      self, cross, firstCross, items: items.length,
      sent: SENT.length, deck: DECK.length
    };
  });

  r.accept.forEach(c=> ok(c[2]===true, 'accepted: "'+c[0]+'" for "'+c[1]+'"'));
  r.reject.forEach(c=> ok(c[2]===false,'rejected: "'+c[0]+'" for "'+c[1]+'"'));
  ok(r.self===0, 'every item matches its own answer ('+r.self+' failed)');
  ok(r.cross===2, 'the only cross-acceptance is the pre-existing e homograph (got '+r.cross+(r.firstCross?', e.g. '+r.firstCross:'')+')');
  ok(r.deck===1812,'deck size unchanged ('+r.deck+')');
  ok(r.sent===1442,'1,230 plus 196 trip-window and 19 bound-form sentences ('+r.sent+')');

  // the live question path, not just the helper
  const live=await p.evaluate(()=>{
    const S=window.__kl.S;
    S.settings.typing=true;
    const c=window.__kl.IDX['c0764'];   // futari desu
    return c ? {romaji:c.romaji, kana:c.kana} : null;
  });
  ok(!!live,'a known phrase card is still present after the dedupe');
  if(live) ok(await p.evaluate(r=>window.__kl.romajiMatches('futari des',r),live.romaji),
              'the live card accepts the devoiced spelling ("futari des" for "'+ (live?live.romaji:'') +'")');

  await b.close();
  console.log(fails? fails+" FAILURES of "+n : "TYPED ANSWERS ARE JUDGED BY THE JAPANESE, NOT THE SPELLING ("+n+" checks)");
  process.exit(fails?1:0);
})();
