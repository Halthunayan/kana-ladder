const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{
  const now=Date.now(), items={};
  // 20 words already learned, none due for weeks, so only "study ahead" is available
  for(let i=0;i<20;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,5,2.5,40,now+(20+i)*86400000,0,0,8,8,5,40,now-3*86400000]; }
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:99,
    settings:{sched:"fsrs",retention:0.9,newPerDay:2,revCap:150,reverse:"grad",softCap:false,
      sentences:true,sentPerDay:4,conj:true,conjPerDay:2,listen:false,tts:false,
      theme:"dark",kanji:true},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,consDone:0,
      noNew:false,buried:{},done:{},missed:{}},
    hist:{}, streak:{cur:2,best:2,last:""}, life:{ans:100,ok:90,practice:0}, log:[], items}));
});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);

console.log('\nnew words per day is set to 2');
const label=await p.$eval('#startBtn',e=>e.textContent);
console.log('  primary button reads: "'+label+'"');
const aheadBtn=await p.$('#aheadBtn');
if(aheadBtn && await aheadBtn.isVisible()){ await aheadBtn.click(); }
else { await p.click('#startBtn'); }
await p.waitForTimeout(500);
ok(await p.evaluate(()=>__kl.sess().mode==='ahead'),'the session started in study-ahead mode');

// answer 60 cards and count how many were brand new
const kinds={newWord:0, rev:0, sent:0, conj:0, cons:0};
const seenNew=new Set();
for(let i=0;i<60;i++){
  const on=await p.evaluate(()=>!!document.querySelector('#s-review.on')); if(!on) break;
  const k=await p.evaluate(()=>{
    const key=__kl.sess().key, c=__kl.cardOf(key), it=__kl.S.items[key];
    return {key, fresh:!it, sent:__kl.isSent(c), conj:__kl.isConj(c), dir:key.split('|')[1]};
  });
  if(k.fresh){
    if(k.sent) kinds.sent++;
    else if(k.conj) kinds.conj++;
    else if(k.dir==='j'){ kinds.newWord++; seenNew.add(k.key); }
    else kinds.cons++;
  } else kinds.rev++;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
  const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} else break;
}
console.log('  over one long study-ahead session: '+JSON.stringify(kinds));
ok(kinds.newWord<=2,'at most 2 brand new words were introduced (got '+kinds.newWord+')');
ok(kinds.sent<=4,'sentences stayed inside their budget of 4 (got '+kinds.sent+')');
ok(kinds.conj<=2,'conjugation stayed inside its budget of 2 (got '+kinds.conj+')');
ok(kinds.rev>0,'future reviews were still pulled forward without limit ('+kinds.rev+' of them)');
const daily=await p.evaluate(()=>({n:__kl.S.daily.newDone, s:__kl.S.daily.sentDone, c:__kl.S.daily.conjDone}));
ok(daily.n<=2,'the saved daily counter agrees (newDone '+daily.n+')');

console.log('\nno new words today still wins');
await p.click('#quitBtn').catch(()=>{}); await p.waitForTimeout(400);
await p.evaluate(()=>{ __kl.S.daily.newDone=0; __kl.S.daily.sentDone=0; __kl.S.daily.conjDone=0; __kl.S.daily.noNew=true; });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400);
const ab2=await p.$('#aheadBtn');
if(ab2 && await ab2.isVisible()) await ab2.click(); else await p.click('#startBtn').catch(()=>{});
await p.waitForTimeout(500);
let fresh=0;
for(let i=0;i<12;i++){
  const on=await p.evaluate(()=>!!document.querySelector('#s-review.on')); if(!on) break;
  if(await p.evaluate(()=>!__kl.S.items[__kl.sess().key])) fresh++;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
  const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} else break;
}
ok(fresh===0,'with "no new words today" on, study ahead introduced nothing new');
ok(errs.length===0, errs.length? errs.join(' | ') : 'no page errors');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'STUDY AHEAD RESPECTS THE DAILY BUDGETS'));
process.exit(fails.length?1:0);})();
