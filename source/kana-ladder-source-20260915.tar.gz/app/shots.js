const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
await ctx.addInitScript(()=>{
  const v=[{lang:'ja-JP',name:'Kyoko',default:true,localService:true,voiceURI:'Kyoko'}];
  try{ Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v}); }catch(e){}
  try{ window.speechSynthesis.speak=()=>{}; window.speechSynthesis.cancel=()=>{}; }catch(e){}
});
const p=await ctx.newPage();
p.on('pageerror',e=>console.log('PAGEERROR',e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1600);
await p.click('#startBtn');
const want={'Listening':0,'Japanese → English':0};
let shots=0;
for(let i=0;i<80 && shots<4;i++){
  if(await p.$('#s-review.on')===null) break;
  await p.waitForSelector('#showBtn',{state:'visible',timeout:4000}).catch(()=>{});
  const chip=await p.$eval('#dirChip',e=>e.textContent);
  const isSent=(await p.$eval('#posChip',e=>e.textContent))==='文';
  if(chip==='Listening' && !isSent && want['Listening']===0){ want['Listening']=1;
    await p.screenshot({path:'s-listen-front.png'});
    await p.click('#showBtn'); await p.waitForTimeout(350);
    await p.screenshot({path:'s-listen-back.png'}); shots+=2;
  } else if(isSent && chip==='Japanese → English' && !want.sent){ want.sent=1;
    await p.screenshot({path:'s-sent-front.png'});
    await p.click('#showBtn'); await p.waitForTimeout(350);
    await p.screenshot({path:'s-sent-back.png'}); shots+=2;
  } else {
    await p.click('#showBtn').catch(()=>{});
  }
  await p.waitForSelector('.grade.g2',{state:'visible',timeout:4000}).catch(()=>{});
  await p.click('.grade.g2').catch(()=>{}); await p.waitForTimeout(40);
}
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(300);
await p.click('.tab[data-go="browse"]'); await p.waitForTimeout(400);
await p.click('#rows .row'); await p.waitForTimeout(500);
await p.screenshot({path:'s-sheet.png'});
await b.close(); console.log('done');})();
