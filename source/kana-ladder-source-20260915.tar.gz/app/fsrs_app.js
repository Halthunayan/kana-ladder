const {chromium}=require('playwright');
const fails=[];
const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m); } };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});

// ---------- a fresh install must schedule with FSRS ----------
{
const ctx=await b.newContext({viewport:{width:393,height:852}});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1400);

console.log('\n1. a fresh install runs FSRS');
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
ok(await p.$eval('#setSched',e=>e.value)==='fsrs','the scheduler setting reads FSRS');
ok(await p.$eval('#setRet',e=>e.value)==='90','target retention defaults to 90 percent');
const note=await p.$eval('#schedNote',e=>e.textContent);
ok(/FSRS-6/.test(note) && /727 million/.test(note),'the settings note explains the defaults');
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(300);

console.log('\n2. intervals come from stability, not from an ease factor');
await p.click('#startBtn'); await p.waitForTimeout(400);
await p.click('#showBtn'); await p.waitForTimeout(300);
const previews=await p.evaluate(()=>[...document.querySelectorAll('.grade .iv')].map(e=>e.textContent));
ok(previews.length===4,'four grade previews shown: '+previews.join(' / '));
// Easy on a brand new card should jump to about the FSRS initial stability for Easy (8.3 days)
ok(/^[6-9]d$|^1[01]d$/.test(previews[3]),'Easy on a new card offers roughly 8 days, got '+previews[3]);
await p.click('.grade.g2'); await p.waitForTimeout(200);
// answer a handful, then inspect the stored memory state
for(let i=0;i<10;i++){
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(30);}
  const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(30);}
}
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(400);
const st=await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const vals=Object.values(d.items);
  return {n:vals.length, withMem:vals.filter(v=>v.length>=13 && v[11]>0).length,
    sample:vals.filter(v=>v[0]===1)[0], log:(d.log||[]).length};
});
ok(st.withMem>0,st.withMem+' of '+st.n+' cards carry a stability value');
if(st.sample) ok(st.sample[11]>0 && st.sample[10]>=1 && st.sample[10]<=10,
  'a graduated card has stability '+st.sample[11]+' and difficulty '+st.sample[10]);

console.log('\n3. every scheduled answer is logged');
ok(st.log>0,'the review log holds '+st.log+' entries');
const logShape=await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const r=(d.log||[])[0]||[];
  return {len:r.length, t:r[0], grade:r[3], ok:r.length===6 && r[0]>1700000000 && r[3]>=1 && r[3]<=4};
});
ok(logShape.ok,'each row is [time, card, direction, grade, elapsed, state] (got '+logShape.len+' fields)');
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(400);
ok((await p.$eval('#nLog',e=>e.textContent))!=='0','the progress screen reports the log size');
ok(await p.$eval('#nEfLabel',e=>e.textContent)==='Average difficulty','progress shows difficulty, not ease');

console.log('\n4. target retention moves intervals the right way');
const ivAt=async (pct)=>{
  await p.click('.tab[data-go="set"]'); await p.waitForTimeout(300);
  await p.fill('#setRet',String(pct)); await p.dispatchEvent('#setRet','change'); await p.waitForTimeout(400);
  return p.evaluate(()=>{
    const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
    return d.settings.retention;
  });
};
const r80=await ivAt(80), r95=await ivAt(95);
ok(Math.abs(r80-0.80)<1e-9,'80 percent stored as 0.8');
ok(Math.abs(r95-0.95)<1e-9,'95 percent stored as 0.95');
await ivAt(120); const rHi=await p.evaluate(()=>JSON.parse(localStorage.getItem('kanaladder.v1')).settings.retention);
ok(rHi<=0.97,'an out-of-range target is clamped to 97 percent (got '+rHi+')');
await ivAt(90);
ok(errs.length===0, errs.length? errs.slice(0,2).join(' | ') : 'no errors so far');
await ctx.close();
}

// ---------- an SM-2 save must migrate ----------
{
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{
  if(localStorage.getItem('kanaladder.v1')) return;
  const now=Date.now(), items={};
  // written in the old ten-field shape, with no memory state at all
  for(let i=0;i<25;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,5,i%2?1.6:2.7,12+i,now+(i-5)*86400000,i%3,0,9,7]; }
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:30,
    settings:{newPerDay:12,revCap:150,reverse:"grad",typing:false,kanji:true,tts:false,theme:"auto"},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0},
    hist:{"2026-09-01":40}, streak:{cur:4,best:6,last:""}, life:{ans:300,ok:270}, items}));
});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);

console.log('\n5. a pre-FSRS save migrates on load');
const mig=await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {items:Object.keys(d.items).length, streak:d.streak.cur, life:d.life.ans, sched:d.settings.sched};
});
ok(mig.items===25,'all 25 cards survived');
ok(mig.streak===4 && mig.life===300,'streak and lifetime answers survived');
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
ok(await p.$eval('#setSched',e=>e.value)==='fsrs','the migrated save runs FSRS');
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(300);
// answering must produce a memory state derived from the old ease and interval
await p.click('#startBtn'); await p.waitForTimeout(400);
await p.click('#showBtn'); await p.waitForTimeout(250);
const pv=await p.evaluate(()=>[...document.querySelectorAll('.grade .iv')].map(e=>e.textContent));
ok(pv.every(x=>x && !/NaN|undefined/.test(x)),'grade previews are sane after migration: '+pv.join(' / '));
await p.click('.grade.g2'); await p.waitForTimeout(400);
const after=await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const withMem=Object.values(d.items).filter(v=>v.length>=13 && v[11]>0);
  return {withMem:withMem.length, sample:withMem[0]};
});
ok(after.withMem>0,after.withMem+' migrated cards now carry stability');
if(after.sample) ok(after.sample[10]>=1 && after.sample[10]<=10,'difficulty landed inside 1..10 (got '+after.sample[10]+')');

console.log('\n6. switching back to SM-2 works');
await p.click('#quitBtn').catch(()=>{}); await p.waitForTimeout(300);
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
await p.selectOption('#setSched','sm2'); await p.waitForTimeout(500);
ok((await p.$eval('#schedNote',e=>e.textContent)).indexOf('SM-2')===0,'the note switches to describe SM-2');
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(300);
await p.click('#startBtn'); await p.waitForTimeout(400);
await p.click('#showBtn'); await p.waitForTimeout(250);
const pv2=await p.evaluate(()=>[...document.querySelectorAll('.grade .iv')].map(e=>e.textContent));
ok(pv2.every(x=>x && !/NaN|undefined/.test(x)),'SM-2 previews are sane: '+pv2.join(' / '));
await p.click('.grade.g2'); await p.waitForTimeout(300);
const q2=await p.$('#quitBtn'); if(q2&&await q2.isVisible()) await q2.click(); await p.waitForTimeout(300);
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(300);
await p.selectOption('#setSched','fsrs'); await p.waitForTimeout(400);
ok(true,'switched back to FSRS without error');

console.log('\n7. the word sheet shows memory state');
await p.click('.tab[data-go="browse"]'); await p.waitForTimeout(400);
await p.selectOption('#filt','yng').catch(()=>{}); await p.waitForTimeout(300);
const row=await p.$('#rows .row');
if(row){ await row.click(); await p.waitForTimeout(400);
  const txt=await p.$eval('#sheet',e=>e.textContent);
  ok(/stability/.test(txt)||/not started/.test(txt),'the sheet reports stability and difficulty');
  await p.click('#sheetClose').catch(()=>{});
} else { console.log('  SKIP  no young card to open'); }
ok(errs.length===0, errs.length? errs.slice(0,2).join(' | ') : 'no errors');
await ctx.close();
}
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'ALL FSRS APP CHECKS PASSED'));
process.exit(fails.length?1:0);})();
