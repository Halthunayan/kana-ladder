(function(){
"use strict";
var DECK = JSON.parse(document.getElementById("deck-data").textContent);
var POS_JA = {noun:"名詞",verb:"動詞","adj-i":"形容詞","adj-na":"形容動詞",adv:"副詞",expr:"表現",
  particle:"助詞",counter:"助数詞",pron:"代名詞",num:"数詞",conj:"接続詞",interj:"感動詞"};
var POS_EN = {noun:"noun",verb:"verb","adj-i":"i-adjective","adj-na":"na-adjective",adv:"adverb",expr:"expression",
  particle:"particle",counter:"counter",pron:"pronoun",num:"number",conj:"conjunction",interj:"interjection"};
var IDX = {}; DECK.forEach(function(c,i){ c._i = i; IDX[c.id] = c; });

var LEARN = [60, 600], RELEARN = [600], SHARDS = 8, LS_KEY = "kanaladder.v1";
var DEFAULTS = {newPerDay:12, revCap:150, reverse:"grad", typing:false, kanji:true, tts:true, theme:"auto"};

var S = {rev:0, items:{}, settings:Object.assign({},DEFAULTS),
  daily:{key:"",newDone:0,revDone:0,ans:0,ok:0}, hist:{}, streak:{cur:0,best:0,last:""}, life:{ans:0,ok:0}};

/* ---------- time ---------- */
function dayKey(t){var d=new Date(t-14400000);
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");}
function dayEnd(t){var d=new Date(t-14400000); d.setHours(0,0,0,0);
  return d.getTime()+14400000+86400000;}
function prevKey(k,n){var p=k.split("-"); var d=new Date(+p[0],+p[1]-1,+p[2]); d.setDate(d.getDate()-n);
  return d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");}
function rollDay(){var k=dayKey(Date.now()); if(S.daily.key!==k){S.daily={key:k,newDone:0,revDone:0,ans:0,ok:0};}}

/* ---------- SM-2 ---------- */
function newItem(){return {s:0,st:0,n:0,ef:2.5,iv:0,due:0,lapses:0,piv:0,seen:0,ok:0};}
function clamp(v,a,b){return v<a?a:v>b?b:v;}
function grad(o,iv,now){o.s=1;o.st=0;o.n=Math.max(1,o.n+1);o.iv=iv;o.due=now+iv*86400000;}
function schedule(it,g,now,preview){
  var o=Object.assign({},it);
  if(o.s===0){
    if(g===0){o.st=0;o.due=now+LEARN[0]*1000;}
    else if(g===1){o.due=now+LEARN[Math.min(o.st,LEARN.length-1)]*1000;}
    else if(g===2){o.st++; if(o.st>=LEARN.length){grad(o,1,now);} else {o.due=now+LEARN[o.st]*1000;}}
    else {grad(o,4,now);}
    return o;
  }
  if(o.s===2){
    if(g===0){o.st=0;o.due=now+RELEARN[0]*1000;}
    else if(g===1){o.due=now+RELEARN[Math.min(o.st,RELEARN.length-1)]*1000;}
    else if(g===2){grad(o,Math.max(1,Math.round(o.piv*0.5)),now);}
    else {grad(o,Math.max(2,Math.round(o.piv*0.7)),now);}
    return o;
  }
  if(g===0){o.lapses++;o.ef=Math.max(1.3,o.ef-0.2);o.piv=o.iv;o.s=2;o.st=0;o.due=now+RELEARN[0]*1000;return o;}
  var q = g===1?3:(g===2?4:5);
  o.ef = clamp(o.ef + (0.1-(5-q)*(0.08+(5-q)*0.02)), 1.3, 3.0);
  o.n++;
  var iv;
  if(g===1) iv = Math.max(o.iv+1, Math.round(o.iv*1.2));
  else if(o.n<=1) iv = (g===3?4:1);
  else if(o.n===2) iv = (g===3?8:6);
  else iv = Math.round(o.iv*o.ef*(g===3?1.3:1));
  iv = clamp(Math.round(iv),1,730);
  if(!preview && iv>=4) iv = clamp(Math.round(iv*(0.95+Math.random()*0.10)),1,730);
  o.iv=iv;o.s=1;o.due=now+iv*86400000;
  return o;
}
function ivLabel(ms){
  var s=Math.max(30,ms/1000);
  if(s<3600) return Math.max(1,Math.round(s/60))+"m";
  if(s<86400) return Math.round(s/3600)+"h";
  var d=s/86400;
  if(d<30) return Math.round(d)+"d";
  if(d<365) return trimz((d/30.44).toFixed(d<90?1:0))+"mo";
  return trimz((d/365).toFixed(1))+"y";
}
function trimz(x){return String(x).replace(/\.0$/,"");}

/* ---------- storage ---------- */
var Store = {db:null, dirty:{}, timer:null, ready:false};
function packItem(o){return [o.s,o.st,o.n,Math.round(o.ef*1000)/1000,o.iv,o.due,o.lapses,o.piv,o.seen,o.ok];}
function unpackItem(a){return {s:a[0],st:a[1],n:a[2],ef:a[3],iv:a[4],due:a[5],lapses:a[6],piv:a[7],seen:a[8],ok:a[9]};}
function shardOf(key){var c=IDX[key.split("|")[0]]; return c?c._i%SHARDS:0;}
function packShard(n){var o={}; for(var k in S.items){ if(shardOf(k)===n) o[k]=packItem(S.items[k]); } return o;}
function packMeta(){return {rev:S.rev,settings:S.settings,daily:S.daily,hist:S.hist,streak:S.streak,life:S.life};}
function packAll(){var it={}; for(var k in S.items) it[k]=packItem(S.items[k]);
  return {rev:S.rev,settings:S.settings,daily:S.daily,hist:S.hist,streak:S.streak,life:S.life,items:it};}
function applyBlob(b){
  if(!b) return;
  S.rev = b.rev||0;
  S.settings = Object.assign({},DEFAULTS,b.settings||{});
  S.daily = Object.assign({key:"",newDone:0,revDone:0,ans:0,ok:0},b.daily||{});
  S.hist = b.hist||{}; S.streak = Object.assign({cur:0,best:0,last:""},b.streak||{});
  S.life = Object.assign({ans:0,ok:0},b.life||{});
  S.items = {}; var it=b.items||{};
  for(var k in it){ if(IDX[k.split("|")[0]]) S.items[k]=unpackItem(it[k]); }
}
function loadLocal(){
  try{var raw=localStorage.getItem(LS_KEY); if(raw) applyBlob(JSON.parse(raw));}catch(e){}
}
function saveLocal(){ try{localStorage.setItem(LS_KEY,JSON.stringify(packAll()));}catch(e){} }
function touch(key){ Store.dirty[shardOf(key)]=1; save(); }
function save(){
  S.rev++; saveLocal();
  if(Store.timer) clearTimeout(Store.timer);
  Store.timer = setTimeout(flush, 1400);
}
function flush(){
  Store.timer=null;
  if(!Store.db) return Promise.resolve();
  var jobs=[Store.db.doc("srs/meta").set(packMeta())];
  var d=Store.dirty; Store.dirty={};
  for(var n in d) jobs.push(Store.db.doc("srs/s"+n).set({items:packShard(+n)}));
  return Promise.all(jobs).catch(function(e){ setSync("error"); });
}
function pushAll(){ for(var i=0;i<SHARDS;i++) Store.dirty[i]=1; return flush(); }

function setSync(mode){
  var dot=document.getElementById("syncDot"), lab=document.getElementById("syncLabel");
  var note=document.getElementById("syncNote");
  if(mode==="on"){ dot.className="syncdot"; lab.innerHTML='<span class="syncdot" id="syncDot"></span> synced';
    note.textContent="Progress is saved to your account, so this deck picks up where you left off on any device you open it on."; }
  else if(mode==="error"){ dot.className="syncdot off"; lab.innerHTML='<span class="syncdot off" id="syncDot"></span> local';
    note.textContent="Account sync could not be reached just now. Progress is still being saved in this browser and will sync when the connection returns."; }
  else { dot.className="syncdot off"; lab.innerHTML='<span class="syncdot off" id="syncDot"></span> this device';
    note.textContent="Progress is stored in this browser only. It stays put on this device but will not follow you to another one."; }
}

function initDb(){
  if(!(window.claude && typeof window.claude.use==="function")) { setSync("local"); return; }
  window.claude.use("db").then(function(db){
    if(!db){ setSync("local"); return; }
    Store.db = db;
    var reads=[db.doc("srs/meta").get()];
    for(var i=0;i<SHARDS;i++) reads.push(db.doc("srs/s"+i).get());
    return Promise.all(reads).then(function(snaps){
      var meta = snaps[0].exists ? snaps[0].data() : null;
      if(meta && (meta.rev||0) > S.rev){
        var items={};
        for(var i=1;i<snaps.length;i++){ if(snaps[i].exists){ var m=snaps[i].data().items||{}; for(var k in m) items[k]=m[k]; } }
        applyBlob({rev:meta.rev,settings:meta.settings,daily:meta.daily,hist:meta.hist,streak:meta.streak,life:meta.life,items:items});
        saveLocal(); applySettings(); render();
      } else if(S.rev>0 || Object.keys(S.items).length){
        pushAll();
      }
      setSync("on");
    });
  }).catch(function(){ setSync("error"); });
}

/* ---------- queues ---------- */
function cardOf(key){return IDX[key.split("|")[0]];}
function dirOf(key){return key.split("|")[1];}
function pools(){
  var now=Date.now(), de=dayEnd(now), lrn=[], rev=[];
  for(var k in S.items){ var it=S.items[k];
    if(it.s===1){ if(it.due<=de) rev.push(k); }
    else lrn.push(k);
  }
  rev.sort(function(a,b){return S.items[a].due-S.items[b].due;});
  lrn.sort(function(a,b){return S.items[a].due-S.items[b].due;});
  var nw=[], mode=S.settings.reverse;
  if(mode!=="off"){
    for(var i=0;i<DECK.length;i++){ var c=DECK[i]; var jk=c.id+"|j";
      if(S.items[jk] && !S.items[c.id+"|e"]){
        if(mode==="now" || S.items[jk].s===1) nw.push(c.id+"|e");
      }
    }
  }
  for(var j=0;j<DECK.length;j++){ if(!S.items[DECK[j].id+"|j"]) nw.push(DECK[j].id+"|j"); }
  return {lrn:lrn, rev:rev, nw:nw, now:now, de:de};
}
function counts(){
  var p=pools(); rollDay();
  var newLeft=Math.max(0,S.settings.newPerDay-S.daily.newDone);
  var revLeft=Math.max(0,S.settings.revCap-S.daily.revDone);
  return {newN:Math.min(newLeft,p.nw.length), lrnN:p.lrn.length, dueN:Math.min(revLeft,p.rev.length), p:p};
}

/* ---------- session ---------- */
var Sess = {on:false, key:null, shown:false, done:0, plan:0, intro:0, typed:false};
function pickNext(){
  rollDay();
  var p=pools(), now=p.now;
  var dueLrn=p.lrn.filter(function(k){return S.items[k].due<=now;});
  if(dueLrn.length) return dueLrn[0];
  var newLeft=Math.max(0,S.settings.newPerDay-S.daily.newDone);
  var revLeft=Math.max(0,S.settings.revCap-S.daily.revDone);
  var hasRev=p.rev.length>0 && revLeft>0, hasNew=p.nw.length>0 && newLeft>0;
  if(hasRev&&hasNew) return (Sess.done%4===3)?p.nw[0]:p.rev[0];
  if(hasRev) return p.rev[0];
  if(hasNew) return p.nw[0];
  if(p.lrn.length && S.items[p.lrn[0]].due-now < 1200000) return p.lrn[0];
  return null;
}
function planSize(){var c=counts(); return c.newN+c.dueN+c.lrnN;}

function startSession(){
  Sess.on=true; Sess.done=0; Sess.plan=planSize();
  go("review"); document.getElementById("tabs").classList.add("hide");
  nextCard();
}
function endSession(msg){
  Sess.on=false; document.getElementById("tabs").classList.remove("hide");
  go("home"); render(); if(msg) toast(msg);
}
function nextCard(){
  var k=pickNext();
  if(!k){ endSession(sessionEndMsg()); return; }
  Sess.key=k; Sess.shown=false; Sess.typed=false;
  renderCard();
}
function sessionEndMsg(){
  var p=pools(), now=Date.now();
  if(p.lrn.length){ return p.lrn.length+" card"+(p.lrn.length>1?"s":"")+" come back in "+ivLabel(S.items[p.lrn[0]].due-now); }
  return "Done for today. Nice work.";
}

/* ---------- rendering: review ---------- */
function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c];});}
function speak(text){
  if(!S.settings.tts || !("speechSynthesis" in window)) return;
  try{ speechSynthesis.cancel();
    var u=new SpeechSynthesisUtterance(text); u.lang="ja-JP"; u.rate=0.85; speechSynthesis.speak(u);
  }catch(e){}
}
function renderCard(){
  var k=Sess.key, c=cardOf(k), d=dirOf(k), it=S.items[k]||newItem();
  var front=document.getElementById("faceFront"), back=document.getElementById("faceBack");
  document.getElementById("fold").hidden=true;
  document.getElementById("dirChip").className="chip "+(d==="j"?"dir-j":"dir-e");
  document.getElementById("dirChip").innerHTML = d==="j" ? "Japanese &rarr; English" : "English &rarr; Japanese";
  document.getElementById("posChip").textContent = POS_JA[c.pos]||c.pos;
  document.getElementById("revCount").textContent = Sess.done+"/"+Math.max(Sess.plan,Sess.done+1);
  renderPips();

  var jpBlock = '<div class="kana">'+esc(c.kana)+'</div>'+
    '<div class="romaji">'+esc(c.romaji)+'</div>'+
    (S.settings.kanji && c.kanji ? '<div class="kanji">'+esc(c.kanji)+'</div>' : "")+
    '<button class="speak" id="speakBtn" aria-label="Read aloud"><svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6.5 9H3v6h3.5L11 19z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg></button>';

  if(d==="j"){
    front.innerHTML = jpBlock + '<div class="hint">What does this mean?</div>';
    back.innerHTML = '<div class="english">'+esc(c.en)+'</div>'+
      '<div class="tags"><span>'+esc(POS_EN[c.pos]||c.pos)+'</span>'+c.tags.map(function(t){return "<span>"+esc(t)+"</span>";}).join("")+'</div>';
  } else {
    front.innerHTML = '<div class="english">'+esc(c.en)+'</div>'+
      '<div class="hint">Say it in Japanese</div>'+
      (S.settings.typing ? '<div class="typebox"><input id="typeIn" type="text" inputmode="latin" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="romaji"></div><div class="verdict" id="verdict"></div>' : "");
    back.innerHTML = jpBlock +
      '<div class="tags"><span>'+esc(POS_EN[c.pos]||c.pos)+'</span>'+c.tags.map(function(t){return "<span>"+esc(t)+"</span>";}).join("")+'</div>';
  }
  wireSpeak(c);
  var ti=document.getElementById("typeIn");
  if(ti){ ti.addEventListener("keydown",function(e){ if(e.key==="Enter"){e.preventDefault(); reveal();} }); setTimeout(function(){ti.focus();},60); }
  renderGrades(false);
}
function wireSpeak(c){
  var b=document.getElementById("speakBtn");
  if(b) b.addEventListener("click",function(e){e.stopPropagation(); if(!S.settings.tts){toast("Read aloud is off in Settings");return;} speak(c.kana);});
}
function renderPips(){
  var el=document.getElementById("pips"), n=12, filled=Sess.plan?Math.round(Sess.done/Math.max(Sess.plan,1)*n):0, h="";
  for(var i=0;i<n;i++) h+='<i class="'+(i<filled?"a":"")+'"></i>';
  el.innerHTML=h;
}
function normRomaji(x){return String(x).toLowerCase().replace(/[^a-z]/g,"");}
function reveal(){
  if(Sess.shown) return;
  var c=cardOf(Sess.key), d=dirOf(Sess.key);
  if(d==="e" && S.settings.typing){
    var ti=document.getElementById("typeIn"), v=document.getElementById("verdict");
    if(ti && v){ var ok=normRomaji(ti.value)===normRomaji(c.romaji);
      v.textContent = ti.value ? (ok?"correct":"you typed "+ti.value) : "";
      v.className="verdict "+(ok?"ok":"no"); Sess.typed=ok; ti.blur(); }
  }
  Sess.shown=true;
  document.getElementById("fold").hidden=false;
  renderGrades(true);
  if(S.settings.tts) speak(c.kana);
}
function renderGrades(shown){
  var g=document.getElementById("grades");
  if(!shown){ g.innerHTML='<button class="btn showbtn" id="showBtn">Show answer</button>';
    document.getElementById("showBtn").addEventListener("click",reveal); return; }
  var it=S.items[Sess.key]||newItem(), now=Date.now();
  var labels=["Again","Hard","Good","Easy"], h="";
  for(var i=0;i<4;i++){
    var nx=schedule(it,i,now,true);
    h+='<button class="grade g'+i+'" data-g="'+i+'"><span class="iv">'+ivLabel(nx.due-now)+'</span><span class="lb">'+labels[i]+'</span></button>';
  }
  g.innerHTML=h;
  Array.prototype.forEach.call(g.querySelectorAll(".grade"),function(b){
    b.addEventListener("click",function(){ answer(+b.dataset.g); });
  });
}
function answer(gr){
  var k=Sess.key, fresh=!S.items[k], it=S.items[k]||newItem(), now=Date.now();
  var wasReview = it.s===1;
  var next=schedule(it,gr,now,false);
  next.seen=(it.seen||0)+1; next.ok=(it.ok||0)+(gr>0?1:0);
  S.items[k]=next;
  rollDay();
  if(fresh) S.daily.newDone++;
  if(wasReview) S.daily.revDone++;
  S.daily.ans++; if(gr>0) S.daily.ok++;
  S.life.ans++; if(gr>0) S.life.ok++;
  var dk=S.daily.key; S.hist[dk]=(S.hist[dk]||0)+1;
  trimHist();
  if(S.streak.last!==dk){
    S.streak.cur = (S.streak.last===prevKey(dk,1)) ? S.streak.cur+1 : 1;
    S.streak.best = Math.max(S.streak.best,S.streak.cur); S.streak.last=dk;
  }
  Sess.done++;
  touch(k);
  nextCard();
}
function trimHist(){
  var ks=Object.keys(S.hist); if(ks.length<=400) return;
  ks.sort(); ks.slice(0,ks.length-400).forEach(function(k){delete S.hist[k];});
}

/* ---------- rendering: home ---------- */
function stateOf(it){
  if(!it) return "new";
  if(it.s!==1) return "lrn";
  return it.iv>=21 ? "mat" : "yng";
}
function render(){
  rollDay();
  var c=counts();
  setTile("tileNew",c.newN); setTile("tileLrn",c.lrnN); setTile("tileDue",c.dueN);
  var total=c.newN+c.lrnN+c.dueN;
  var btn=document.getElementById("startBtn");
  btn.disabled = total===0;
  btn.textContent = total===0 ? "Nothing due right now" : "Start review · "+total+" card"+(total>1?"s":"");
  var note=document.getElementById("startNote");
  if(total===0){ var p=c.p;
    note.textContent = p.lrn.length ? p.lrn.length+" learning card"+(p.lrn.length>1?"s":"")+" return in "+ivLabel(S.items[p.lrn[0]].due-Date.now())
      : (S.daily.ans>0 ? "Today's queue is clear. Come back tomorrow." : "Set a daily pace in Settings to begin.");
  } else { note.textContent = ""; }

  var mat=0,yng=0,lrn=0,words={};
  for(var k in S.items){ var st=stateOf(S.items[k]); if(st==="mat")mat++; else if(st==="yng")yng++; else lrn++;
    words[k.split("|")[0]]=1; }
  var totalCards=DECK.length*(S.settings.reverse==="off"?1:2);
  var touched=mat+yng+lrn, nwords=Object.keys(words).length;
  document.getElementById("progAux").textContent=nwords+" of "+DECK.length+" words started";
  var rail=document.getElementById("rail").children;
  rail[0].style.width=(mat/totalCards*100)+"%";
  rail[1].style.width=(yng/totalCards*100)+"%";
  rail[2].style.width=(lrn/totalCards*100)+"%";
  document.getElementById("lgMat").textContent=mat;
  document.getElementById("lgYng").textContent=yng;
  document.getElementById("lgLrn").textContent=lrn;
  document.getElementById("lgNew").textContent=totalCards-touched;

  document.getElementById("streakAux").textContent = S.streak.cur ? S.streak.cur+" day"+(S.streak.cur>1?"s":"")+" · best "+S.streak.best : "not started";
  drawStreak();
  document.getElementById("kvAns").textContent=S.daily.ans;
  document.getElementById("kvAcc").textContent=S.daily.ans?Math.round(S.daily.ok/S.daily.ans*100)+"%":"—";
  document.getElementById("kvNewToday").textContent=S.daily.newDone;
  renderStats();
}
function setTile(id,n){var el=document.getElementById(id); el.querySelector(".n").textContent=n; el.classList.toggle("zero",n===0);}

function svgBars(el,vals,labels,color,unit,emptyMsg){
  var W=320,H=+el.getAttribute("viewBox").split(" ")[3],pad=14,bw=W/vals.length;
  var real=Math.max.apply(null,vals), max=Math.max(real,1);
  var h="";
  h+='<line x1="0" y1="'+(H-pad)+'" x2="'+W+'" y2="'+(H-pad)+'" stroke="var(--rule)" stroke-width="1"/>';
  for(var i=0;i<vals.length;i++){
    var bh=vals[i]/max*(H-pad-8), x=i*bw+bw*0.16, w=bw*0.68;
    if(vals[i]>0) h+='<rect x="'+x.toFixed(1)+'" y="'+(H-pad-bh).toFixed(1)+'" width="'+w.toFixed(1)+'" height="'+bh.toFixed(1)+'" rx="1.6" fill="'+color+'"/>';
    else h+='<rect x="'+x.toFixed(1)+'" y="'+(H-pad-2)+'" width="'+w.toFixed(1)+'" height="2" rx="1" fill="var(--rule)"/>';
  }
  if(labels) for(var j=0;j<labels.length;j++){ if(!labels[j]) continue;
    h+='<text x="'+(j*bw+bw/2).toFixed(1)+'" y="'+(H-3)+'" text-anchor="middle" font-size="8" fill="var(--ink-3)" font-family="IBM Plex Mono, monospace">'+labels[j]+'</text>';
  }
  if(real>0) h+='<text x="0" y="9" font-size="8.5" fill="var(--ink-3)" font-family="IBM Plex Mono, monospace">'+real+(unit||"")+'</text>';
  else h+='<text x="'+(W/2)+'" y="'+((H-pad)/2+3)+'" text-anchor="middle" font-size="10" fill="var(--ink-3)">'+(emptyMsg||"")+'</text>';
  el.innerHTML=h;
}
function drawStreak(){
  var today=dayKey(Date.now()), vals=[], labs=[];
  for(var i=29;i>=0;i--){ var k=prevKey(today,i); vals.push(S.hist[k]||0);
    labs.push(i===29?k.slice(5).replace("-","/"):(i===0?"today":"")); }
  svgBars(document.getElementById("streakChart"),vals,labs,"var(--ai)","","No reviews logged yet");
}
function renderStats(){
  var now=Date.now(), de=dayEnd(now), vals=[], labs=[];
  for(var d=0;d<14;d++){ var lo=de+(d-1)*86400000, hi=de+d*86400000, n=0;
    for(var k in S.items){ var it=S.items[k]; if(it.s!==1) continue;
      if(d===0){ if(it.due<hi) n++; } else if(it.due>=lo && it.due<hi) n++; }
    vals.push(n); labs.push(d===0?"today":(d%3===0?"+"+d:""));
  }
  svgBars(document.getElementById("forecast"),vals,labs,"var(--shu)","","Nothing scheduled ahead yet");

  var bands=[[1,1],[2,3],[4,7],[8,14],[15,30],[31,90],[91,99999]];
  var bl=["1d","2-3","4-7","1-2w","2-4w","1-3mo","3mo+"], bv=bands.map(function(){return 0;});
  var efs=[],ivs=[],mx=0,rot=0;
  for(var k2 in S.items){ var it2=S.items[k2]; if(it2.s!==1) continue; rot++;
    efs.push(it2.ef); ivs.push(it2.iv); if(it2.iv>mx) mx=it2.iv;
    for(var b=0;b<bands.length;b++){ if(it2.iv>=bands[b][0]&&it2.iv<=bands[b][1]){bv[b]++;break;} }
  }
  svgBars(document.getElementById("ivChart"),bv,bl,"var(--matcha)","","No cards on the long schedule yet");
  var avg=function(a){return a.length?a.reduce(function(x,y){return x+y;},0)/a.length:0;};
  document.getElementById("nRot").textContent=rot;
  document.getElementById("nEf").textContent=efs.length?avg(efs).toFixed(2):"—";
  document.getElementById("nIv").textContent=ivs.length?trimz(avg(ivs).toFixed(1))+"d":"—";
  document.getElementById("nAns").textContent=S.life.ans;
  document.getElementById("nAcc").textContent=S.life.ans?Math.round(S.life.ok/S.life.ans*100)+"%":"—";
  document.getElementById("nMax").textContent=mx?ivLabel(mx*86400000):"—";
  document.getElementById("statsSub").textContent=S.life.ans+" answers";
}

/* ---------- browse ---------- */
function renderBrowse(){
  var q=document.getElementById("q").value.trim().toLowerCase();
  var f=document.getElementById("filt").value;
  var out=[], nq=normRomaji(q);
  for(var i=0;i<DECK.length && out.length<200;i++){
    var c=DECK[i];
    if(q){ var hit = c.kana.indexOf(q)>=0 || c.kanji.indexOf(q)>=0 ||
      (nq && normRomaji(c.romaji).indexOf(nq)>=0) || c.en.toLowerCase().indexOf(q)>=0;
      if(!hit) continue; }
    var it=S.items[c.id+"|j"], st=stateOf(it);
    if(f!=="all"){
      if(f==="hard"){ if(!it || it.lapses<3) continue; }
      else if(f!==st) continue;
    }
    out.push({c:c,it:it,st:st});
  }
  var h="";
  for(var j=0;j<out.length;j++){
    var o=out[j], lab = o.st==="new"?"new":(o.st==="lrn"?"learning":ivLabel(o.it.iv*86400000));
    h+='<button class="row" data-id="'+o.c.id+'"><span><span class="jp">'+esc(o.c.kana)+
      (S.settings.kanji&&o.c.kanji?' <span style="color:var(--ink-3);font-size:15px">'+esc(o.c.kanji)+'</span>':"")+
      '</span><span class="rm"> '+esc(o.c.romaji)+'</span><span class="en">'+esc(o.c.en)+'</span></span>'+
      '<span class="state s-'+o.st+'">'+lab+'</span></button>';
  }
  document.getElementById("rows").innerHTML = h || '<div class="empty"><div class="big">無</div>No words match that.</div>';
  document.getElementById("browseCount").textContent = DECK.length+" words";
  document.getElementById("browseNote").textContent = out.length>=200 ? "Showing the first 200 matches. Narrow the search to see more." : (out.length+" shown");
  Array.prototype.forEach.call(document.querySelectorAll("#rows .row"),function(b){
    b.addEventListener("click",function(){
      var c=IDX[b.dataset.id], it=S.items[c.id+"|j"];
      speak(c.kana);
      toast(c.romaji+" · "+(it? (it.s===1? "next in "+ivLabel(it.due-Date.now())+", ease "+it.ef.toFixed(2) : "in learning") : "not started"));
    });
  });
}

/* ---------- settings ---------- */
function applySettings(){
  document.getElementById("setNew").value=S.settings.newPerDay;
  document.getElementById("setRev").value=S.settings.revCap;
  document.getElementById("setRev2").value=S.settings.reverse;
  document.getElementById("setType").setAttribute("aria-checked",String(!!S.settings.typing));
  document.getElementById("setKanji").setAttribute("aria-checked",String(!!S.settings.kanji));
  document.getElementById("setTts").setAttribute("aria-checked",String(!!S.settings.tts));
  document.getElementById("setTheme").value=S.settings.theme;
  if(S.settings.theme==="auto") document.documentElement.removeAttribute("data-theme");
  else document.documentElement.setAttribute("data-theme",S.settings.theme);
}
function bindSettings(){
  document.getElementById("setNew").addEventListener("change",function(){
    S.settings.newPerDay=clamp(parseInt(this.value,10)||0,0,80); this.value=S.settings.newPerDay; save(); render();});
  document.getElementById("setRev").addEventListener("change",function(){
    S.settings.revCap=clamp(parseInt(this.value,10)||10,10,600); this.value=S.settings.revCap; save(); render();});
  document.getElementById("setRev2").addEventListener("change",function(){S.settings.reverse=this.value; save(); render();});
  document.getElementById("setTheme").addEventListener("change",function(){S.settings.theme=this.value; applySettings(); save();});
  [["setType","typing"],["setKanji","kanji"],["setTts","tts"]].forEach(function(p){
    document.getElementById(p[0]).addEventListener("click",function(){
      S.settings[p[1]]=!S.settings[p[1]]; this.setAttribute("aria-checked",String(S.settings[p[1]])); save();
      if(p[1]==="kanji") renderBrowse();
    });
  });
  document.getElementById("exportBtn").addEventListener("click",function(){
    var txt=JSON.stringify(packAll());
    if(navigator.clipboard&&navigator.clipboard.writeText){
      navigator.clipboard.writeText(txt).then(function(){toast("Progress copied to the clipboard");},function(){toast("Could not copy");});
    } else toast("Clipboard is unavailable here");
  });
  document.getElementById("resetBtn").addEventListener("click",function(){
    if(!confirm("Erase all scheduling and start the deck from zero? This cannot be undone.")) return;
    S.items={}; S.daily={key:"",newDone:0,revDone:0,ans:0,ok:0}; S.hist={}; S.streak={cur:0,best:0,last:""}; S.life={ans:0,ok:0};
    pushAll(); save(); render(); renderBrowse(); toast("Deck reset");
  });
}

/* ---------- shell ---------- */
function go(name){
  ["home","review","browse","stats","set"].forEach(function(n){
    document.getElementById("s-"+n).classList.toggle("on",n===name);
  });
  Array.prototype.forEach.call(document.querySelectorAll(".tab"),function(t){
    t.classList.toggle("on",t.dataset.go===name);
  });
  window.scrollTo(0,0);
  if(name==="browse") renderBrowse();
  if(name==="home"||name==="stats") render();
}
var toastTimer=null;
function toast(msg){
  var t=document.getElementById("toast"); t.textContent=msg; t.classList.add("on");
  if(toastTimer) clearTimeout(toastTimer);
  toastTimer=setTimeout(function(){t.classList.remove("on");},2600);
}
function bind(){
  Array.prototype.forEach.call(document.querySelectorAll(".tab"),function(t){
    t.addEventListener("click",function(){ if(Sess.on) return; go(t.dataset.go); });
  });
  document.getElementById("startBtn").addEventListener("click",startSession);
  document.getElementById("quitBtn").addEventListener("click",function(){ endSession(Sess.done?Sess.done+" answered this session":""); });
  document.getElementById("q").addEventListener("input",renderBrowse);
  document.getElementById("filt").addEventListener("change",renderBrowse);
  document.getElementById("faceFront").addEventListener("click",function(e){
    if(e.target.closest("#speakBtn")||e.target.closest("input")) return;
    if(Sess.on&&!Sess.shown) reveal();
  });
  document.addEventListener("keydown",function(e){
    if(!Sess.on) return;
    if(e.key===" "||e.key==="Enter"){ if(!Sess.shown){e.preventDefault();reveal();} }
    else if(Sess.shown && e.key>="1" && e.key<="4"){ answer(+e.key-1); }
  });
  ["visibilitychange","pagehide"].forEach(function(ev){
    document.addEventListener(ev,function(){ if(Store.timer){clearTimeout(Store.timer);flush();} });
  });
  setInterval(function(){ if(!Sess.on) render(); },60000);
}

loadLocal(); rollDay(); applySettings(); bind(); bindSettings(); render(); renderBrowse(); setSync("local"); initDb();
})();
