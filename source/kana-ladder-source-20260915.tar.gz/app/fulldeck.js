const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});

// discover every card in the deck, in every direction it can have
let all;
{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  const p=await ctx.newPage();
  await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(900);
  all=await p.evaluate(()=>{
    const D=JSON.parse(document.getElementById('deck-data').textContent);
    const S=JSON.parse(document.getElementById('sent-data').textContent);
    const out=[];
    D.forEach(c=>{ out.push(c.id+'|j'); out.push(c.id+'|e'); out.push(c.id+'|a'); });
    S.forEach(s=>{ out.push(s.id+'|j'); out.push(s.id+'|a'); });
    return out;
  });
  await ctx.close();
}
console.log('cards to exercise:', all.length);

const BATCH=700, nb=Math.ceil(all.length/BATCH);
let tested=0, answered=0; const failures=[]; const seenDir={}; const errs=[];
for(let bi=0; bi<nb; bi++){
  const keys=all.slice(bi*BATCH,(bi+1)*BATCH);
  // a fresh context per batch, seeded before any app code runs
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(({keys})=>{
    const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    try{window.speechSynthesis.speak=()=>{};window.speechSynthesis.cancel=()=>{};}catch(e){}
    if(localStorage.getItem('kanaladder.v1')) return;
    const now=Date.now(); const items={};
    keys.forEach(k=>{ items[k]=[1,0,3,2.5,5,now-86400000,0,0,3,3]; });
    localStorage.setItem('kanaladder.v1', JSON.stringify({rev:5,
      settings:{newPerDay:0,revCap:100000,reverse:"grad",softCap:false,separate:false,listen:true,
        sentences:true,sentPerDay:0,badge:false,typing:false,kanji:true,tts:false,theme:"auto"},
      daily:{key:"",newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,consDone:0,buried:{},done:{}},
      hist:{},streak:{cur:0,best:0,last:""},life:{ans:0,ok:0},backup:{last:""},notes:{},susp:{},items}));
  },{keys});
  const p=await ctx.newPage();
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text());});
  await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1100);

  const due=await p.evaluate(()=>document.querySelector('#tileDue .n').textContent);
  if(due!==String(keys.length)) failures.push({batch:bi, why:'seed did not take: due='+due+' expected '+keys.length});
  await p.click('#startBtn');

  const res = await p.evaluate(async (n)=>{
    const bad=[]; const dirs={}; let count=0;
    const txt=el=>el?el.textContent.replace(/\s+/g,' ').trim():'';
    for(let i=0;i<n+50;i++){
      if(!document.querySelector('#s-review.on')) break;
      const show=document.getElementById('showBtn');
      if(!show){ bad.push({i,why:'no show button'}); break; }
      const chip=txt(document.getElementById('dirChip'));
      const pos=txt(document.getElementById('posChip'));
      const front=txt(document.getElementById('faceFront'));
      if(!chip) bad.push({i,why:'empty direction chip'});
      if(!pos) bad.push({i,why:'empty part of speech chip', chip});
      if(!front) bad.push({i,why:'empty front face', chip});
      dirs[chip]=(dirs[chip]||0)+1;
      show.click();
      const back=txt(document.getElementById('faceBack'));
      if(document.getElementById('fold').hidden) bad.push({i,why:'answer did not reveal', chip, front:front.slice(0,24)});
      if(!back) bad.push({i,why:'empty back face', chip, front:front.slice(0,24)});
      const grades=[...document.querySelectorAll('.grade')];
      if(grades.length!==4){ bad.push({i,why:'expected 4 grade buttons, got '+grades.length}); break; }
      for(const g of grades){
        const iv=txt(g.querySelector('.iv'));
        if(!iv || /NaN|undefined|Infinity/.test(iv)) bad.push({i,why:'bad interval label "'+iv+'"', chip});
      }
      if(chip.indexOf('Japanese')===0 || chip==='Listening'){
        if(!document.querySelector('#faceFront .kana, #faceBack .kana')) bad.push({i,why:'no kana rendered', chip, front:front.slice(0,24)});
        if(!document.querySelector('#faceFront .romaji, #faceBack .romaji')) bad.push({i,why:'no romaji rendered', chip, front:front.slice(0,24)});
      }
      if(chip.indexOf('English')===0){
        if(!document.querySelector('#faceFront .english')) bad.push({i,why:'no English prompt', chip});
        if(!document.querySelector('#faceBack .kana')) bad.push({i,why:'no kana answer', chip});
      }
      grades[2].click(); count++;
      await new Promise(r=>setTimeout(r,0));
      if(bad.length>40) break;
    }
    return {bad, dirs, count};
  }, keys.length);

  tested+=keys.length; answered+=res.count;
  for(const k in res.dirs) seenDir[k]=(seenDir[k]||0)+res.dirs[k];
  res.bad.forEach(x=>failures.push(Object.assign({batch:bi},x)));
  if(res.count<keys.length) failures.push({batch:bi, why:'only '+res.count+' of '+keys.length+' cards were served'});
  console.log('  batch '+(bi+1)+'/'+nb+': served '+res.count+'/'+keys.length+', failures so far '+failures.length);
  await ctx.close();
}
console.log('\ncards seeded:', tested, ' cards actually served:', answered);
console.log('directions seen:', JSON.stringify(seenDir));
console.log('render failures:', failures.length);
failures.slice(0,25).forEach(f=>console.log('   ',JSON.stringify(f)));
console.log('page errors:', errs.length? errs.slice(0,5).join(' | ') : 'none');
await b.close();
process.exit(failures.length||errs.length?1:0);})();
