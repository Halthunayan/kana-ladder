/* Data operations and invariants: the things that would lose or corrupt
   progress rather than merely display it wrongly. */
const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const today=new Date(Date.now()-14400000).toISOString().slice(0,10);  // the app's day starts at 04:00 UTC
const state=(over)=>{ const now=Date.now(), items={};
  for(let i=0;i<40;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,4,2.4,12+i,now+(i-5)*86400000,i%7,0,9,7,4.5,12+i,now-2*86400000]; }
  items['c0003|j'][6]=8;                       // a leech: eight lapses
  items['s001|j']=[1,0,2,2.5,5,now+5*86400000,0,0,3,3,5,5,now-86400000];
  items['g001|j']=[1,0,2,2.5,5,now+5*86400000,0,0,3,3,5,5,now-86400000];
  return Object.assign({rev:42,
    settings:{sched:"fsrs",retention:0.93,newPerDay:7,revCap:120,reverse:"grad",softCap:false,
      separate:true,sentences:true,sentPerDay:3,conj:true,conjPerDay:1,listen:true,tts:false,
      autoPlay:false,speechRate:0.75,speechVary:false,badge:false,typing:true,kanji:false,theme:"light"},
    daily:{key:today,newDone:3,revDone:11,ans:14,ok:12,credit:2,sentDone:1,conjDone:1,consDone:2,
      noNew:false,buried:{'c0009|e':1},done:{'c0009|j':1},missed:{'c0002|j':1}},
    hist:{[today]:14,'2026-09-01':30}, streak:{cur:6,best:9,last:today},
    life:{ans:410,ok:370,practice:88}, backup:{last:"2026-08-20"},
    notes:{'c0004':'looks like the one for water'}, susp:{'c0011|j':1}, pfail:{'c0005|j':1},
    log:[[1780000000,5,0,3,2.2,1],[1780000600,6,1,2,1.1,1]], items}, over||{}); };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const open=async(st)=>{ const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(s=>{ const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    localStorage.setItem('kanaladder.v1',JSON.stringify(s)); }, st);
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1300);
  return {ctx,p,errs}; };

console.log('\n1. a backup round trip loses nothing');
{
const fs=require('fs'), os=require('os'), path=require('path');
const ctx=await b.newContext({viewport:{width:393,height:852}, acceptDownloads:true});
await ctx.addInitScript(s2=>{ const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  if(!localStorage.getItem('kanaladder.v1')) localStorage.setItem('kanaladder.v1',JSON.stringify(s2)); }, state());
const p=await ctx.newPage();
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1300);
const blob=await p.evaluate(()=>JSON.parse(JSON.stringify(__kl.S)));
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
const [dl]=await Promise.all([p.waitForEvent('download'), p.click('#exportBtn')]);
const file=path.join(os.tmpdir(),'kl-backup.json');
await dl.saveAs(file);
const raw=JSON.parse(fs.readFileSync(file,'utf8'));
ok(Object.keys(raw.items).length===Object.keys(blob.items).length,
   'the downloaded file holds all '+Object.keys(raw.items).length+' cards');
ok(Array.isArray(raw.log)&&raw.log.length===2,'it holds the review log');
ok(raw.settings.retention===0.93 && raw.settings.conjPerDay===1 && raw.settings.speechRate===0.75,
   'it holds the newer settings');
ok(raw.daily.conjDone===1 && raw.daily.sentDone===1,'it holds the daily conjugation and sentence counters (conj '+raw.daily.conjDone+', sent '+raw.daily.sentDone+')');
await ctx.close();

const ctx2=await b.newContext({viewport:{width:393,height:852}});
const p2=await ctx2.newPage();
await p2.goto('http://localhost:8100/index.html'); await p2.waitForTimeout(1300);
ok(await p2.evaluate(()=>Object.keys(__kl.S.items).length===0),'the second install started empty');
await p2.click('.tab[data-go="set"]'); await p2.waitForTimeout(400);
p2.on('dialog',d=>d.accept());
await p2.setInputFiles('#importFile', file); await p2.waitForTimeout(1200);
await p2.reload(); await p2.waitForTimeout(1400);
const back=await p2.evaluate(()=>JSON.parse(JSON.stringify(__kl.S)));
const cmp=(a,bb,pth)=>{ const out=[];
  for(const k of Object.keys(a)){ const x=a[k], y=bb?bb[k]:undefined;
    if(typeof x==='object'&&x&&!Array.isArray(x)) out.push(...cmp(x,y||{},pth+'.'+k));
    else if(Array.isArray(x)){ if(JSON.stringify(x)!==JSON.stringify(y)) out.push(pth+'.'+k); }
    else if(x!==y) out.push(pth+'.'+k+' ('+x+' vs '+y+')'); }
  return out; };
// rev is a save counter and is expected to advance; backup.last records the export itself
const diff=cmp(blob,back,'S').filter(d=>!/^S\.backup\.|^S\.rev/.test(d));
ok(diff.length===0,'every field came back identical'+(diff.length?': '+diff.slice(0,8).join(', '):''));
ok(Object.keys(back.items).length===Object.keys(blob.items).length,
   'all '+Object.keys(back.items).length+' cards came back');
ok(back.log.length===2 && back.notes['c0004']==='looks like the one for water' &&
   back.susp['c0011|j']===1 && back.streak.best===9,
   'log, hints, set-aside words and the streak all came back');
await ctx2.close();
}

console.log('\n2. suspend, bring back, and reset one word');
{
const {ctx,p}=await open(state());
await p.click('.tab[data-go="browse"]'); await p.waitForTimeout(400);
await p.fill('#q','c'); await p.waitForTimeout(300);
const before=await p.evaluate(()=>Object.keys(__kl.S.susp).length);
const row=await p.$('#rows .row');
await row.click(); await p.waitForTimeout(400);
const id=await p.evaluate(()=>{ const t=document.querySelector('#sheet .sheet-word .kana');
  return t?t.textContent:null; });
await p.click('#sheetSusp'); await p.waitForTimeout(400);
const after=await p.evaluate(()=>Object.keys(__kl.S.susp).length);
ok(after>before,'setting a word aside suspends its cards ('+before+' -> '+after+')');
await p.click('#sheetSusp'); await p.waitForTimeout(400);
const back=await p.evaluate(()=>Object.keys(__kl.S.susp).length);
ok(back===before,'bringing it back removes them again ('+back+')');
await p.click('#sheetClose').catch(()=>{});
await ctx.close();
}

console.log('\n3. a leech is flagged at eight lapses, not before');
{
const {ctx,p}=await open(state());
const flags=await p.evaluate(()=>{
  const S=__kl.S; const out={};
  for(const k in S.items) if(S.items[k].lapses>=8) out[k]=S.items[k].lapses;
  return out; });
ok(Object.keys(flags).length===1 && flags['c0003|j']===8,'exactly the eight-lapse card qualifies');
await ctx.close();
}

console.log('\n4. the day rollover resets the right things and keeps the rest');
{
const {ctx,p}=await open(state());
const before=await p.evaluate(()=>({streak:__kl.S.streak.cur, life:__kl.S.life.ans,
  items:Object.keys(__kl.S.items).length, notes:Object.keys(__kl.S.notes).length,
  susp:Object.keys(__kl.S.susp).length, hist:Object.keys(__kl.S.hist).length}));
await p.evaluate(()=>{ __kl.S.daily.key='2000-01-01'; });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(500);
const after=await p.evaluate(()=>({d:__kl.S.daily, streak:__kl.S.streak.cur, life:__kl.S.life.ans,
  items:Object.keys(__kl.S.items).length, notes:Object.keys(__kl.S.notes).length,
  susp:Object.keys(__kl.S.susp).length, hist:Object.keys(__kl.S.hist).length}));
ok(after.d.ans===0 && after.d.newDone===0 && after.d.sentDone===0 && after.d.conjDone===0,
   'the daily counters all reset');
ok(Object.keys(after.d.buried).length===0 && Object.keys(after.d.done).length===0,
   'held cards and today-done cards clear for the new day');
ok(after.d.noNew===false,'"no new words today" does not carry over');
ok(after.items===before.items && after.notes===before.notes && after.susp===before.susp &&
   after.life===before.life && after.hist===before.hist,
   'cards, hints, set-aside words, lifetime totals and history are untouched');
await ctx.close();
}

console.log('\n5. undo puts a card back exactly as it was');
{
const {ctx,p}=await open(state());
await p.click('#startBtn'); await p.waitForTimeout(500);
const key=await p.evaluate(()=>__kl.sess().key);
const pre=await p.evaluate(k=>JSON.stringify(__kl.S.items[k]), key);
const preDaily=await p.evaluate(()=>JSON.stringify(__kl.S.daily));
await p.click('#showBtn'); await p.waitForTimeout(200);
await p.click('.grade.g0'); await p.waitForTimeout(300);
const mid=await p.evaluate(k=>JSON.stringify(__kl.S.items[k]), key);
ok(mid!==pre,'answering changed the card');
await p.click('#undoBtn'); await p.waitForTimeout(400);
const post=await p.evaluate(k=>JSON.stringify(__kl.S.items[k]), key);
const postDaily=await p.evaluate(()=>JSON.stringify(__kl.S.daily));
ok(post===pre,'undo restored the card byte for byte');
ok(postDaily===preDaily,'undo restored the daily counters too');
await ctx.close();
}

console.log('\n6. the storage panel reports real values');
{
const {ctx,p,errs}=await open(state());
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(600);
const st=await p.evaluate(()=>{ const g=id=>{const e=document.getElementById(id);return e?e.textContent.trim():null;};
  return {mode:g('stMode'), persist:g('stPersist'), usage:g('stUsage'), backup:g('stBackup'),
    deck:g('deckCountTxt'), sent:g('sentCountTxt'), conj:g('conjCountTxt'),
    ret:document.getElementById('setRet').value, rate:document.getElementById('setRate').value,
    newN:document.getElementById('setNew').value, cap:'', sentN:document.getElementById('setSentN').value,
    conjN:document.getElementById('setConjN').value};});
ok(st.deck==='1,812'||st.deck==='1812','the deck size shown matches the deck ("'+st.deck+'")');
ok(st.sent==='1,442','the sentence count matches and is formatted like the others ("'+st.sent+'")');
ok(st.conj==='40','the conjugation count matches ("'+st.conj+'")');
ok(st.ret==='93' && st.rate==='75' && st.newN==='7' && st.sentN==='3' && st.conjN==='1',
   'every numeric control reflects the saved settings ('+[st.ret,st.rate,st.newN,st.sentN,st.conjN].join('/')+')');
ok(/ago|today|never/.test(st.backup),'the last backup is reported in plain language ("'+st.backup+'")');
ok(errs.length===0, errs.length? errs.join(' | ') : 'no page errors');
await ctx.close();
}
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'DATA AND INVARIANTS ALL HOLD'));
process.exit(fails.length?1:0);})();
