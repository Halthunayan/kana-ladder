/* Ryan's real save file through the new build: does the flow actually open up */
const {chromium}=require('playwright'); const fs=require('fs');
let fails=0,n=0;
const ok=(c,m)=>{n++; if(!c){fails++;console.log("  FAIL  "+m);} else console.log("  ok    "+m);};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
const blob=fs.readFileSync('/tmp/bk2.json','utf8');
await ctx.addInitScript(raw=>{try{localStorage.setItem('kanaladder.v1',raw);}catch(e){}}, blob);
const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
await p.goto('http://127.0.0.1:8100/index.html',{timeout:15000});
await p.waitForFunction(()=>window.__kl&&window.__kl.DECK.length>0,null,{timeout:15000});
await p.waitForTimeout(1500);

const r=await p.evaluate(()=>{
  const k=window.__kl, S=k.S;
  /* A device with no Japanese voice. NOT his phone: his has one, and his save
     file carries 16 listening cards with review history and 21 listening
     answers in the log, so listening has been running there all along. An
     earlier comment here claimed otherwise and the claim was wrong. This is
     the harsher device, with the pre-rendered library as the only thing that
     can speak Japanese. */
  k.TTS.ja=false; k.TTS.voices=[];
  const sentOpenN = k.SENT.filter(x=>k.sentOpen(x)).length;
  const pl=k.pools();
  const c=k.counts();
  let buriedA=0, buriedGhost=0;
  for(const key in S.daily.buried){
    if(key.endsWith('|a')) buriedA++;
    if(!S.items[key]) buriedGhost++;
  }
  return {
    listenOn:k.listenOn(), listenBlocked:k.listenBlocked(),
    sentOpenN, sentPool:pl.sn.length, consPool:pl.cs.length, cj:pl.cj.length,
    consAllow:k.consAllowance(), newAllow:k.newAllowance(),
    dueN:c.dueN, newN:c.newN,
    buriedA, buriedGhost,
    weights:k.scoreParts().W,
    score:k.scoreParts().score,
    schema:JSON.parse(localStorage.getItem('kanaladder.v1')).schema
  };
});
console.log("  "+JSON.stringify({sentOpen:r.sentOpenN, sentPool:r.sentPool, consPool:r.consPool, consAllow:r.consAllow, cj:r.cj}));

ok(r.listenBlocked===false,'with the library present, listening is not blocked even with no device voice');
ok(r.listenOn===true,'so listening cards are in the pools again');
ok(r.weights.a>0,'and the listening weight is a real share of the score ('+r.weights.a+')');
/* the other half of the same rule: nothing can speak Japanese at all */
const noVoice=await p.evaluate(()=>{ const k=window.__kl; const m=k.AUD.man;
  k.TTS.ja=false; k.AUD.man=null;
  const out={on:k.listenOn(), blocked:k.listenBlocked(), a:k.scoreParts().W.a,
             warn:!document.getElementById('listenWarn').hidden};
  k.AUD.man=m; return out; });
ok(noVoice.blocked===true && noVoice.on===false,'with no device voice and no library, listening is blocked');
ok(noVoice.a===0,'and its weight drops to zero rather than leaving a phantom share');
ok(r.sentOpenN>0 && r.sentPool>0,'sentences open at all-but-one word ('+r.sentOpenN+' open, '+r.sentPool+' in the pool)');
ok(r.sentPool>0,'sentences actually reach the daily pool ('+r.sentPool+')');
ok(r.consAllow>=r.newAllow,'the follow-up budget tracks the new-word rate ('+r.consAllow+'/day, new words '+r.newAllow+')');
ok(r.consPool>=0 && r.consAllow>0,'the follow-up pool is reachable and has a budget ('+r.consPool+' waiting, '+r.consAllow+' a day)');
/* the pool that matters is tomorrow's, once the day rolls over */
const fresh=await p.evaluate(()=>{ const k=window.__kl; k.S.daily.buried={}; k.TTS.ja=false;
  return {cs:k.pools().cs.length, sn:k.pools().sn.length}; });
ok(fresh.cs>=25,'on a fresh day the follow-up queue is served, not starved ('+fresh.cs+' waiting, 4 a day)');
ok(fresh.sn>0,'and sentences are served alongside them ('+fresh.sn+')');
ok(errs.length===0,'no uncaught page errors'+(errs.length?': '+errs[0]:''));

/* burial must stop inventing cards */
const bur=await p.evaluate(()=>{
  const k=window.__kl, S=k.S;
  S.daily.buried={};
  k.TTS.ja=false;
  // answer one recognition card the way the app does
  const key='c0022|j';
  S.items[key].due=Date.now()-1000;
  k.sess().on=true; k.sess().key=key; k.sess().practice=false; k.sess().focus=false;
  k.answer(2);
  const out={total:0, ghost:0, listen:0};
  for(const kk in S.daily.buried){ out.total++; if(!S.items[kk]) out.ghost++; if(kk.endsWith('|a')) out.listen++; }
  return out;
});
ok(bur.ghost>0,'a sibling not yet introduced is still held, so the word cannot be tested twice in one day ('+bur.ghost+' held)');
/* The rule is conditional, not absolute: a listening sibling is held only when
   listening can actually run, or the hold stands for a card that can never be
   shown. With the library present it can run, so it is held. */
ok(bur.listen>0,'a listening sibling is held now that listening can run ('+bur.listen+')');

/* the score must fall when a card is left overdue */
const dec=await p.evaluate(()=>{
  const k=window.__kl;
  const mk=over=>({s:1,st:0,n:3,iv:10,due:Date.now()-over*86400000,lapses:0,piv:5,seen:5,ok:5,df:5,sb:10,lr:0});
  return {d0:+k.strengthOf(mk(0)).toFixed(3), d30:+k.strengthOf(mk(30)).toFixed(3),
          d365:+k.strengthOf(mk(365)).toFixed(3)};
});
ok(dec.d30<dec.d0 && dec.d365<dec.d30,'strength now falls the longer a card is left overdue ('+dec.d0+' -> '+dec.d30+' -> '+dec.d365+')');
ok(dec.d365<dec.d0*0.7,'a year of neglect costs a real share of the score ('+Math.round(100*(1-dec.d365/dec.d0))+'% off)');

/* the backup must declare its shape and refuse a newer one */
const bk=await p.evaluate(()=>{
  const k=window.__kl;
  const blob=JSON.parse(JSON.stringify(k.packAll ? k.packAll() : {}));
  return {schema:blob.schema, tooNew:k.validateBlob({schema:99,items:{'c0000|j':[1,0,1,2.5,1,1,0,0,1,1,1,1,1]}})};
});
ok(bk.schema===6,'a backup written now carries a schema stamp ('+bk.schema+')');
ok(typeof bk.tooNew==='string' && /newer version/.test(bk.tooNew),'a newer backup is refused instead of silently losing fields');

await b.close();
console.log(fails? "\n"+fails+" FAILURES of "+n : "\nTHE FLOW IS OPEN ("+n+" checks)");
process.exit(fails?1:0);
})();
