const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const seed=(learnedIds)=>{
  const now=Date.now(), items={};
  learnedIds.forEach(id=>{ items[id+'|j']=[1,0,4,2.5,30,now+30*86400000,0,0,8,7,5,30,now-2*86400000]; });
  return {rev:99, settings:{sched:"fsrs",retention:0.9,newPerDay:0,revCap:150,reverse:"off",
    sentences:false,sentPerDay:0,conj:true,conjPerDay:2,listen:false,theme:"dark",tts:false,kanji:true},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0}, hist:{}, streak:{cur:1,best:1,last:""},
    life:{ans:10,ok:9,practice:0}, log:[], items};
};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
// nomu c0115 known, taberu c0114 not
await ctx.addInitScript(st=>localStorage.setItem('kanaladder.v1',JSON.stringify(st)), seed(['c0115']));
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error'&&!/favicon|sw\.js|404/.test(m.text()))errs.push('console '+m.text());});
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);

console.log('\n1. anchors open only for words already known');
const pool=await p.evaluate(()=>{
  const seen=[];
  for(let i=0;i<__kl.CONJ.length;i++){ const g=__kl.CONJ[i]; const par=__kl.S.items[g.w[0]+'|j'];
    if(par && par.s===1) seen.push(g.id); }
  return {open:seen, total:__kl.CONJ.length, forms:Object.keys(__kl.FORMS).length};
});
ok(pool.total===40,'40 anchor cards shipped, the two tai anchors included');
ok(pool.forms===438,'438 words carry generated forms');
ok(pool.open.length>0 && pool.open.length<10,pool.open.length+' anchors open on one known verb: '+pool.open.join(','));

console.log('\n2. an anchor is served and reads correctly');
await p.click('#startBtn'); await p.waitForTimeout(500);
let found=null;
for(let i=0;i<12;i++){
  const info=await p.evaluate(()=>{
    const c=__kl.cardOf(__kl.sess().key);
    return {conj:__kl.isConj(c), id:c.id, base:c.base, baseR:c.baseRomaji, form:c.formEn,
      ans:c.kana, ansR:c.romaji, rule:c.rule,
      frontText:document.getElementById('faceFront').textContent,
      chip:document.getElementById('posChip').textContent};
  });
  if(info.conj){ found=info; break; }
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(60);}
  const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(60);} else break;
}
ok(!!found,'a conjugation anchor reached the queue');
if(found){
  console.log('        '+found.base+' ('+found.baseR+') -> '+found.ans+' ('+found.ansR+') · '+found.form);
  ok(found.frontText.indexOf(found.base)>=0,'the front shows the dictionary form');
  ok(found.frontText.indexOf(found.ans)<0,'the front does not give the answer away');
  ok(found.chip==='活用','the chip marks it as conjugation');
  await p.click('#showBtn'); await p.waitForTimeout(300);
  const back=await p.$eval('#faceBack',e=>e.textContent);
  ok(back.indexOf(found.ans)>=0,'the back shows the conjugated form');
  ok(back.indexOf(found.ansR)>=0,'the back shows its romaji');
  ok(found.rule && back.indexOf(found.rule)>=0,'the back states the rule: "'+found.rule+'"');
  ok(await p.evaluate(()=>document.querySelectorAll('#grades .grade').length===4),'it is graded like any scheduled card');
  await p.click('.grade.g2'); await p.waitForTimeout(400);
}
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(400);

console.log('\n3. the daily budget is separate and respected');
const st=await p.evaluate(()=>({conjDone:__kl.S.daily.conjDone, sentDone:__kl.S.daily.sentDone,
  newDone:__kl.S.daily.newDone, budget:__kl.S.settings.conjPerDay}));
ok(st.conjDone>=1,'answered anchors count against conjDone ('+st.conjDone+')');
ok(st.newDone===0,'they did not consume the new-word budget');

console.log('\n4. every generated form is correct for its verb class');
const spot=await p.evaluate(()=>{
  const want={c0115:['のみます','のみました','のみません','のみませんでした','のめます','のんで','のみたいです'],
              c0181:['かえります','かえりました','かえりません','かえりませんでした','かえれます','かえって','かえりたいです'],
              c0114:['たべます','たべました','たべません','たべませんでした','たべられます','たべて','たべたいです'],
              c0178:['します','しました','しません','しませんでした','できます','して','したいです'],
              c0179:['きます','きました','きません','きませんでした','こられます','きて','きたいです'],
              c0180:['いきます','いきました','いきません','いきませんでした','いけます','いって','いきたいです'],
              c0193:['よかった','よかったです','よくない','よくて']};
  const bad=[];
  for(const id in want){ const row=__kl.FORMS[id]||[];
    const got=[]; for(let i=0;i+2<row.length;i+=3) got.push(row[i+1]);
    if(got.join('|')!==want[id].join('|')) bad.push(id+': '+got.join('|')+' != '+want[id].join('|'));
  }
  return bad;
});
ok(spot.length===0, spot.length? spot.join(' ; ') : 'seven hand-checked verbs match, including kaeru (godan that looks ichidan) and iku (the te-form exception)');

console.log('\n5. conjugation appears in the practice drill and changes nothing');
const before=await p.evaluate(()=>JSON.stringify(__kl.S.items));
await p.click('#focusBtn'); await p.waitForTimeout(600);
const inDrill=await p.evaluate(()=>{
  let n=0; for(const k of __kl.sess().queue) if(/^x/.test(k)) n++;
  return {n, total:__kl.sess().queue.length};
});
ok(inDrill.n>0, inDrill.n+' of '+inDrill.total+' drill cards are conjugation');
for(let i=0;i<10;i++){
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(40);}
  const g=await p.$('.grade.g0'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(40);} else break;
}
const after=await p.evaluate(()=>({items:JSON.stringify(__kl.S.items), pfail:Object.keys(__kl.S.pfail||{})}));
ok(after.items===before,'not one scheduled card changed');
ok(after.pfail.filter(k=>/^x/.test(k)).length===0,'drill-only cards left nothing in the saved state');
const q2=await p.$('#quitBtn'); if(q2&&await q2.isVisible()) await q2.click(); await p.waitForTimeout(400);

console.log('\n6. the switch turns it all off');
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
await p.click('#setConj'); await p.waitForTimeout(400);
ok(await p.evaluate(()=>__kl.S.settings.conj===false),'the setting flips off');
ok(await p.evaluate(()=>__kl.pools().cj.length===0),'no anchors are offered when it is off');
ok(errs.length===0, errs.length? errs.slice(0,3).join(' | ') : 'no page errors');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'ALL CONJUGATION CHECKS PASSED'));
process.exit(fails.length?1:0);})();
