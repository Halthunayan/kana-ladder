const {chromium}=require('playwright');
const fails=[];
const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m); } };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
// seed a realistic rotation: strong cards, weak cards, and one already failed twice in practice
await ctx.addInitScript(()=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  try{window.speechSynthesis.speak=()=>{};window.speechSynthesis.cancel=()=>{};}catch(e){}
  if(localStorage.getItem('kanaladder.v1')) return;
  const now=Date.now(), items={}, pfail={};
  for(let i=0;i<30;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,8,2.6,60,now+40*86400000,0,0,10,10]; }        // mature and strong
  for(let i=30;i<40;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,4,1.35,25,now+10*86400000,7,0,20,12]; }        // weak: low ease, many lapses
  items['c0035|j'][6]=9;                                              // the very weakest
  pfail['c0035|j']=1;                                                 // already missed once in practice
  for(let i=40;i<45;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,3,2.5,3,now-86400000,0,0,5,4]; }               // due today
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:20,
    settings:{newPerDay:12,revCap:150,reverse:"grad",softCap:true,separate:true,listen:false,
      sentences:true,sentPerDay:4,badge:false,typing:false,kanji:true,tts:false,theme:"auto"},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,consDone:0,noNew:false,buried:{},done:{},missed:{}},
    hist:{},streak:{cur:3,best:5,last:""},life:{ans:200,ok:180,practice:0},backup:{last:""},notes:{},susp:{},pfail,items}));
});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);

const openDrill=async(pg)=>{ await pg.evaluate(()=>__kl.startPractice()); };
const snap=()=>p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const items={}; for(const k in d.items) items[k]=d.items[k].slice();
  return {items, daily:d.daily, life:d.life, pfail:d.pfail, streak:d.streak};
});

console.log('\n1. a single practice button, no chooser');
ok(await p.evaluate(()=>!!document.getElementById('focusBtn') && !document.getElementById('pracBtn')),'one Practice button, not two');
ok(await p.evaluate(()=>document.querySelectorAll('[data-drill]').length===0),'no drill tiles anywhere');
ok((await p.$eval('#pracNote',e=>e.textContent)).indexOf('45')>=0,'panel reports 45 in rotation');
await p.evaluate(()=>__kl.startPractice()); await p.waitForTimeout(500);
ok(await p.evaluate(()=>!!document.querySelector('#s-review.on')),'tapping it starts a session immediately');
const mix=await p.evaluate(()=>document.getElementById('revCount').textContent);
ok(/practice/.test(mix),'the session is a practice session ('+mix+')');
const qz=await p.$('#quitBtn'); if(qz&&await qz.isVisible()) await qz.click(); await p.waitForTimeout(300);

console.log('\n2. practice must not touch the schedule');
const before=await snap();
await openDrill(p); await p.waitForTimeout(400);
ok(await p.evaluate(()=>!document.getElementById('pracBanner').hidden),'the practice banner is shown');
ok((await p.$eval('#revCount',e=>e.textContent)).indexOf('practice')===0,'the counter says practice');
ok(await p.evaluate(()=>document.getElementById('undoBtn').hidden),'undo is hidden in practice');
await p.click('#showBtn'); await p.waitForTimeout(200);
const gradeCount=await p.evaluate(()=>document.querySelectorAll('.grade').length);
ok(gradeCount===2,'two buttons instead of four grades (got '+gradeCount+')');
const labels=await p.evaluate(()=>[...document.querySelectorAll('.grade .lb')].map(e=>e.textContent));
ok(labels.join('/')==='Missed it/Got it','buttons read "Missed it" and "Got it"');
ok(await p.evaluate(()=>document.querySelectorAll('.grade .iv').length===0),'no interval labels are shown');
// answer the whole drill: half missed, half got
let n=0;
for(let i=0;i<50;i++){
  if(await p.$('#s-review.on')===null) break;
  // the mixed queue is shuffled, so decide per card rather than by position:
  // the card already carrying one practice failure must be missed again here
  const key=await p.evaluate(()=>__kl.sess().key);
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){ await s.click(); await p.waitForTimeout(30); }
  const miss = (key==='c0035|j') || (n%2===0);
  const g=await p.$(miss?'.grade.g0':'.grade.g3'); if(!g) break;
  await g.click(); await p.waitForTimeout(30); n++;
}
await p.waitForTimeout(500);
const after=await snap();
let moved=0;
for(const k in before.items){
  const a=before.items[k], c=after.items[k];
  if(!c){ moved++; continue; }
  for(let i=0;i<10;i++) if(a[i]!==c[i]) { moved++; break; }
}
ok(n>0,'the drill served '+n+' cards');
ok(moved===0,'not one scheduled card changed (fields differing: '+moved+')');
ok(after.daily.ans===before.daily.ans,'the daily answered count did not move');
ok(after.life.ans===before.life.ans,'lifetime answers did not move');
ok(after.streak.cur===before.streak.cur,'the streak did not move');
ok((after.life.practice||0)===n,'practice answers counted separately ('+after.life.practice+')');

console.log('\n3. repeated failures are offered as a reset, never applied silently');
await p.waitForTimeout(600);
const sheetUp=await p.evaluate(()=>!document.getElementById('sheet').hidden);
ok(sheetUp,'the reset offer appeared');
if(sheetUp){
  const listed=await p.evaluate(()=>document.querySelectorAll('#sheet .exline').length);
  ok(listed>0,'it lists '+listed+' twice-missed card(s)');
  ok(await p.evaluate(()=>!!document.getElementById('resetSkip')),'there is a way to decline');
  const pre=await snap();
  await p.click('#resetGo'); await p.waitForTimeout(500);
  const post=await snap();
  let reset=0;
  for(const k in pre.items){ if(post.items[k] && post.items[k][0]===0 && pre.items[k][0]===1) reset++; }
  ok(reset===listed,'accepting reset '+reset+' card(s) back into learning');
  let stillTwo=0, stillOne=0;
  for(const k in (post.pfail||{})){ if(post.pfail[k]>=2) stillTwo++; else stillOne++; }
  ok(stillTwo===0,'no card is left sitting on two practice failures');
  ok(stillOne>0,'cards missed only once keep their counter ('+stillOne+' of them)');
}

console.log('\n4. today’s mistakes drill picks up real misses');
await p.waitForTimeout(200);
await p.click('#startBtn'); await p.waitForTimeout(400);
for(let i=0;i<6;i++){
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){ await s.click(); await p.waitForTimeout(30); }
  const g=await p.$('.grade.g0'); if(g&&await g.isVisible()){ await g.click(); await p.waitForTimeout(30); }
}
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(400);
const subTxt=await p.$eval('#focusBtnSub',e=>e.textContent);
ok(/struggling with|mixed draw|nothing met/.test(subTxt),'the Practice button says what it will drill ("'+subTxt+'")');
await p.evaluate(()=>__kl.startPractice()); await p.waitForTimeout(400);
ok(await p.evaluate(()=>!!document.querySelector('#s-review.on')),'the mistakes drill starts');
const qq=await p.$('#quitBtn'); if(qq&&await qq.isVisible()) await qq.click(); await p.waitForTimeout(300);

console.log('\n5. no new words today');
const dueBefore=await p.$eval('#tileNew .n',e=>e.textContent);
await p.click('#noNewSw'); await p.waitForTimeout(500);
const dueAfter=await p.$eval('#tileNew .n',e=>e.textContent);
ok(dueBefore!=='0' && dueAfter==='0','new words went from '+dueBefore+' to '+dueAfter);
ok((await p.$eval('#tileDue .n',e=>e.textContent))!=='0','scheduled reviews are untouched');
await p.click('#noNewSw'); await p.waitForTimeout(500);
ok(await p.$eval('#tileNew .n',e=>e.textContent)!=='0','turning it back off restores new words');

console.log('\n6. the mixed queue always includes today\u2019s misses');
await p.evaluate(()=>__kl.startPractice()); await p.waitForTimeout(500);
const started=await p.evaluate(()=>!!document.querySelector('#s-review.on'));
ok(started,'the mixed drill starts');
if(started){ const q3=await p.$('#quitBtn'); if(q3&&await q3.isVisible()) await q3.click(); }
await p.waitForTimeout(300);
await p.screenshot({path:'prac-home.png',fullPage:true});

console.log('\n7. no errors');
ok(errs.length===0, errs.length? errs.slice(0,3).join(' | ') : 'clean');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'ALL PRACTICE CHECKS PASSED'));
process.exit(fails.length?1:0);})();
