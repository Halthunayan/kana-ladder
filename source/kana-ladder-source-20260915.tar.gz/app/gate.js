const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const seed=(iv)=>{ const now=Date.now(), items={};
  // nomu c0115 graduated, sitting on the given interval
  items['c0115|j']=[1,0,3,2.5,iv,now+iv*86400000,0,0,5,5,5,iv,now-1*86400000];
  return {rev:99, settings:{sched:"fsrs",retention:0.9,newPerDay:0,revCap:150,reverse:"off",
    sentences:false,conj:true,conjPerDay:2,listen:false,theme:"dark",tts:false,kanji:true},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0}, hist:{}, streak:{cur:1,best:1,last:""},
    life:{ans:5,ok:5,practice:0}, log:[], items}; };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const probe=async(iv)=>{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(st=>localStorage.setItem('kanaladder.v1',JSON.stringify(st)), seed(iv));
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1400);
  const r=await p.evaluate(()=>({
    anchors:__kl.pools().cj.length,
    drill:(function(){ let n=0; for(const k in __kl.FORMS){ const it=__kl.S.items[k+'|j'];
      if(it && it.s===1 && it.iv>=3) n++; } return n; })(),
    gate:__kl.S.items['c0115|j'].iv
  }));
  await ctx.close();
  console.log('  interval '+String(r.gate).padStart(2)+'d -> anchors offered: '+r.anchors+', words eligible for the drill: '+r.drill+(errs.length?'  ERRORS '+errs.join('|'):''));
  return r;
};
console.log('\nconjugation unlocks once the base word holds a three day interval');
const a=await probe(1), c=await probe(2), d=await probe(3), e=await probe(30);
ok(a.anchors===0,'nothing at a 1 day interval');
ok(c.anchors===0,'still nothing at 2 days');
ok(d.anchors>0,d.anchors+' anchors open at exactly 3 days');
ok(e.anchors>=d.anchors,'still open at 30 days');
ok(a.drill===0 && d.drill===1,'the practice drill uses the same gate');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'THREE DAY GATE CONFIRMED'));
process.exit(fails.length?1:0);})();
