const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
// Pretend the device has a Japanese voice, and let the test move the clock forward.
await ctx.addInitScript(()=>{
  const v=[{lang:'ja-JP',name:'Kyoko',default:true,localService:true,voiceURI:'Kyoko'}];
  try{ Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v}); }catch(e){}
  try{ window.speechSynthesis.speak=()=>{}; window.speechSynthesis.cancel=()=>{}; }catch(e){}
  let off=0; try{ off=parseInt(localStorage.getItem('__tOffset')||'0',10)||0; }catch(e){}
  const RealDate=Date, realNow=Date.now;
  function D(...a){ return a.length? new RealDate(...a) : new RealDate(realNow()+off); }
  D.prototype=RealDate.prototype;
  D.now=()=>realNow()+off; D.parse=RealDate.parse; D.UTC=RealDate.UTC;
  window.Date=new Proxy(RealDate,{
    construct(t,a){ return a.length? new t(...a) : new t(realNow()+off); },
    get(t,k){ return k==='now' ? (()=>realNow()+off) : t[k]; }
  });
});
let p=await ctx.newPage(); const errs=[];
const wire=pg=>{ pg.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
  pg.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());}); };
wire(p);
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1600);

async function run(n){const seen=[];
  for(let i=0;i<n;i++){ if(await p.$('#s-review.on')===null) break;
    await p.waitForSelector('#showBtn',{state:'visible',timeout:5000}).catch(()=>{});
    const chip=await p.$eval('#dirChip',e=>e.textContent).catch(()=>'?');
    const pos=await p.$eval('#posChip',e=>e.textContent).catch(()=>'');
    seen.push(chip+(pos==='文'?' [sent]':''));
    await p.click('#showBtn').catch(()=>{});
    await p.waitForSelector('.grade.g2',{state:'visible',timeout:5000}).catch(()=>{});
    await p.click('.grade.g2').catch(()=>{}); await p.waitForTimeout(30); }
  return seen;}

for(let day=1; day<=9; day++){
  const btn=await p.$('#startBtn');
  if(btn && !(await btn.isDisabled())) await btn.click();
  const seen=await run(500);
  const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click();
  await p.waitForTimeout(250);
  const counts=seen.reduce((a,d)=>{a[d]=(a[d]||0)+1;return a;},{});
  const st=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));const k=Object.keys(d.items);
    return {items:k.length, listen:k.filter(x=>x.endsWith('|a')).length, sent:k.filter(x=>x[0]==='s').length,
      lvl:document.getElementById('lvlN').textContent, score:document.getElementById('lvlScore').textContent};});
  console.log('day '+day+' '+JSON.stringify(counts));
  console.log('        items '+st.items+' | listening '+st.listen+' | sentence cards '+st.sent+' | '+st.lvl+' '+st.score);
  await p.evaluate(()=>{ const o=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;
    localStorage.setItem('__tOffset', String(o+86400000)); });
  await p.reload(); await p.waitForTimeout(1000);
}
await p.screenshot({path:'v6-home.png'});
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(700);
console.log('progress:',JSON.stringify(await p.evaluate(()=>({recog:document.getElementById('pRecog').textContent,
  recall:document.getElementById('pRecall').textContent, listen:document.getElementById('pListen').textContent,
  sent:document.getElementById('pSent').textContent}))));
await p.screenshot({path:'v6-stats.png',fullPage:true});
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
