/* Every setting, checked against what the app actually does. The study-ahead
   defect was a setting the engine quietly ignored, so each switch here is
   exercised rather than merely read back. */
const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const seed=(settings,extra)=>({rev:99,
  settings:Object.assign({sched:"fsrs",retention:0.9,newPerDay:12,revCap:150,reverse:"grad",softCap:true,
    separate:true,sentences:true,sentPerDay:4,conj:true,conjPerDay:2,listen:true,tts:true,autoPlay:true,
    badge:true,typing:false,kanji:true,theme:"dark"},settings),
  daily:Object.assign({key:new Date(Date.now()-14400000).toISOString().slice(0,10),newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,conjDone:0,consDone:0,
    noNew:false,buried:{},done:{},missed:{}},(extra||{}).daily),
  hist:{}, streak:{cur:1,best:1,last:""}, life:{ans:50,ok:45,practice:0},
  backup:{last:""}, notes:{}, susp:{}, pfail:{}, log:[], items:(extra||{}).items||{}});
const learned=(n,iv)=>{ const now=Date.now(), items={};
  for(let i=0;i<n;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|j']=[1,0,4,2.5,iv,now+iv*86400000,0,0,6,6,5,iv,now-86400000]; }
  return items; };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const open=async(state)=>{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(st=>{
    const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    window.__spoken=[];
    window.SpeechSynthesisUtterance=function(t){this.text=t;this.lang='';this.rate=1;this.voice=null;};
    try{ window.speechSynthesis.speak=u=>window.__spoken.push(u.text);
         window.speechSynthesis.cancel=()=>{}; }catch(e){}
    localStorage.setItem('kanaladder.v1',JSON.stringify(st));
  }, state);
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1300);
  await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });
  return {ctx,p,errs};
};
// run a session and record what kinds of cards were served
const drive=async(p,n)=>{
  const seen=[];
  const btn=await p.$('#startBtn'); if(btn && !(await btn.isDisabled())) await btn.click();
  await p.waitForTimeout(400);
  for(let i=0;i<n;i++){
    const on=await p.evaluate(()=>!!document.querySelector('#s-review.on')); if(!on) break;
    seen.push(await p.evaluate(()=>{ const k=__kl.sess().key, c=__kl.cardOf(k);
      return {key:k, dir:k.split('|')[1], sent:__kl.isSent(c), conj:__kl.isConj(c), fresh:!__kl.S.items[k]};}));
    const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
    const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} else break;
  }
  return seen;
};

console.log('\n1. new words per day is an exact cap');
for(const n of [1,3,7]){
  const {ctx,p}=await open(seed({newPerDay:n, softCap:false, sentences:false, conj:false, reverse:"off", listen:false}));
  const seen=await drive(p,40);
  const fresh=seen.filter(x=>x.fresh && x.dir==='j').length;
  ok(fresh===n,'newPerDay '+n+' introduced exactly '+fresh);
  await ctx.close();
}

console.log('\n2. review cap is an exact cap');
{
const {ctx,p}=await open(seed({revCap:9, newPerDay:0, sentences:false, conj:false, reverse:"off", listen:false},
  {items:learned(60,-1)}));
const seen=await drive(p,40);
ok(seen.length===9,'revCap 9 served exactly '+seen.length+' cards');
await ctx.close();
}

console.log('\n3. the soft cap only adds when answers are easy');
{
const {ctx,p}=await open(seed({newPerDay:2, softCap:true, sentences:false, conj:false, reverse:"off", listen:false}));
// answer everything Easy: the bonus should let more than 2 in
let fresh=0;
await p.click('#startBtn'); await p.waitForTimeout(400);
for(let i=0;i<40;i++){
  const on=await p.evaluate(()=>!!document.querySelector('#s-review.on')); if(!on) break;
  if(await p.evaluate(()=>!__kl.S.items[__kl.sess().key] && __kl.sess().key.endsWith('|j'))) fresh++;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
  const g=await p.$('.grade.g3'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} else break;
}
ok(fresh>2,'easy answers earned extra new words beyond the cap of 2 (got '+fresh+')');
const bonus=await p.evaluate(()=>__kl.S.daily.credit);
ok(bonus>0,'the credit counter grew ('+bonus+')');
await ctx.close();
}
{
const {ctx,p}=await open(seed({newPerDay:2, softCap:false, sentences:false, conj:false, reverse:"off", listen:false}));
let fresh=0;
await p.click('#startBtn'); await p.waitForTimeout(400);
for(let i=0;i<40;i++){
  const on=await p.evaluate(()=>!!document.querySelector('#s-review.on')); if(!on) break;
  if(await p.evaluate(()=>!__kl.S.items[__kl.sess().key] && __kl.sess().key.endsWith('|j'))) fresh++;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
  const g=await p.$('.grade.g3'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} else break;
}
ok(fresh===2,'with the soft cap off, easy answers earn nothing (got '+fresh+')');
await ctx.close();
}

console.log('\n4. reverse cards: off / after graduation / straight away');
{
const {ctx,p}=await open(seed({reverse:"off", newPerDay:3, sentences:false, conj:false, listen:false}));
const seen=await drive(p,30);
ok(seen.filter(x=>x.dir==='e').length===0,'reverse off served no English to Japanese card');
await ctx.close();
}
{
const {ctx,p}=await open(seed({reverse:"now", newPerDay:0, sentences:false, conj:false, listen:false},
  {items:learned(5,-1)}));
const n=await p.evaluate(()=>__kl.pools().cs.length);
ok(n>0,'reverse "now" offers the follow-up card for words already learned ('+n+')');
await ctx.close();
}
{
const {ctx,p}=await open(seed({reverse:"grad", newPerDay:0, sentences:false, conj:false, listen:false},
  {items:(function(){const now=Date.now(),it={};
    it['c0000|j']=[0,1,0,2.5,0,now+600000,0,0,1,0,0,0,0];   // still in learning
    return it;})()}));
const n=await p.evaluate(()=>__kl.pools().cs.length);
ok(n===0,'reverse "after graduation" holds the follow-up while the word is still in learning');
await ctx.close();
}

console.log('\n5. keep the two directions apart');
{
const {ctx,p}=await open(seed({separate:true, reverse:"now", newPerDay:2, sentences:false, conj:false, listen:false}));
const seen=await drive(p,40);
const dirs={};
for(const x of seen){ const w=x.key.split('|')[0]; (dirs[w]=dirs[w]||new Set()).add(x.dir); }
const twice=Object.entries(dirs).filter(([w,set])=>set.size>1);
ok(twice.length===0,'with burying on, no word was served in two directions the same day'+
   (twice.length?' (offenders: '+twice.map(([w,s2])=>w+':'+[...s2].join('+')).join(', ')+')':''));
await ctx.close();
}
{
const {ctx,p}=await open(seed({separate:false, reverse:"now", newPerDay:2, sentences:false, conj:false, listen:false}));
const seen=await drive(p,40);
const dirs={};
for(const x of seen){ const w=x.key.split('|')[0]; (dirs[w]=dirs[w]||new Set()).add(x.dir); }
const twice=Object.values(dirs).filter(s2=>s2.size>1).length;
ok(twice>0,'with burying off, a word can be served in both directions ('+twice+' were)');
await ctx.close();
}

console.log('\n6. listening cards');
{
const {ctx,p}=await open(seed({listen:false, reverse:"off", newPerDay:0, sentences:false, conj:false},
  {items:learned(5,-1)}));
ok(await p.evaluate(()=>__kl.pools().cs.length===0),'listening off offers no audio card');
await ctx.close();
}
{
const {ctx,p}=await open(seed({listen:true, reverse:"off", newPerDay:0, sentences:false, conj:false},
  {items:learned(5,-1)}));
ok(await p.evaluate(()=>__kl.pools().cs.length===5),'listening on offers one audio card per learned word');
await ctx.close();
}

console.log('\n7. sentences');
{
const {ctx,p}=await open(seed({sentences:false, newPerDay:0, conj:false, reverse:"off", listen:false},
  {items:learned(200,-1)}));
ok(await p.evaluate(()=>__kl.pools().sn.length===0),'sentences off offers none even when the words are known');
await ctx.close();
}
{
const {ctx,p}=await open(seed({sentences:true, sentPerDay:2, newPerDay:0, conj:false, reverse:"off", listen:false},
  {items:learned(200,-1)}));
const seen=await drive(p,30);
const s=seen.filter(x=>x.sent && x.fresh).length;
ok(s<=2,'sentPerDay 2 introduced at most 2 sentences (got '+s+')');
ok(await p.evaluate(()=>__kl.pools().sn.length>0),'sentences were available beyond the budget');
await ctx.close();
}

console.log('\n8. typing, kanji and read aloud');
{
// the recall cards must already exist: with newPerDay 0 none would ever be introduced
const bothWays=(function(){ const now=Date.now(), it={};
  for(let i=0;i<3;i++){ const id='c'+String(i).padStart(4,'0');
    it[id+'|j']=[1,0,4,2.5,10,now+10*86400000,0,0,6,6,5,10,now-86400000];
    it[id+'|e']=[1,0,3,2.5,2,now-86400000,0,0,4,4,5,2,now-86400000]; }
  return it; })();
const {ctx,p}=await open(seed({typing:true, reverse:"now", separate:false, newPerDay:0, sentences:false, conj:false, listen:false},
  {items:bothWays}));
await p.click('#startBtn'); await p.waitForTimeout(500);
// walk to an English to Japanese card
let found=false;
for(let i=0;i<8;i++){
  if(await p.evaluate(()=>__kl.sess().key.endsWith('|e'))){ found=true; break; }
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(30);}
  const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(30);} else break;
}
ok(found && await p.evaluate(()=>!!document.getElementById('typeIn')),'typing on puts a romaji box on the recall card');
if(found){
  const romaji=await p.evaluate(()=>__kl.cardOf(__kl.sess().key).romaji);
  await p.fill('#typeIn',romaji); await p.click('#showBtn'); await p.waitForTimeout(300);
  ok((await p.$eval('#verdict',e=>e.textContent))==='correct','a correct romaji answer is marked correct');
}
await ctx.close();
}
{
const {ctx,p}=await open(seed({kanji:false, newPerDay:1, sentences:false, conj:false, reverse:"off", listen:false}));
await p.click('#startBtn'); await p.waitForTimeout(500);
ok(await p.evaluate(()=>document.querySelectorAll('.kanji').length===0),'kanji off hides the kanji line');
await ctx.close();
}
{
const {ctx,p}=await open(seed({kanji:true, newPerDay:1, sentences:false, conj:false, reverse:"off", listen:false}));
await p.click('#startBtn'); await p.waitForTimeout(500);
const has=await p.evaluate(()=>{ const c=__kl.cardOf(__kl.sess().key);
  return {kanji:!!c.kanji, shown:document.querySelectorAll('.kanji').length}; });
ok(!has.kanji || has.shown>0,'kanji on shows it when the card has one');
await ctx.close();
}
{
const {ctx,p}=await open(seed({tts:false, autoPlay:true, newPerDay:2, sentences:false, conj:false, reverse:"off", listen:false}));
await p.click('#startBtn'); await p.waitForTimeout(600);
ok(await p.evaluate(()=>window.__spoken.length===0),'read aloud off means nothing is ever spoken');
await ctx.close();
}

console.log('\n9. theme');
for(const [t,expect] of [["dark","dark"],["light","light"]]){
  const {ctx,p}=await open(seed({theme:t}));
  ok(await p.evaluate(e=>document.documentElement.getAttribute('data-theme')===e,expect),
     'theme "'+t+'" is applied to the document');
  await ctx.close();
}
{
const {ctx,p}=await open(seed({theme:"auto"}));
ok(await p.evaluate(()=>!document.documentElement.getAttribute('data-theme')),
   'theme "auto" leaves the choice to the device');
await ctx.close();
}

console.log('\n10. no new words today');
{
const {ctx,p}=await open(seed({newPerDay:12, sentences:true, conj:true},
  {items:learned(200,-1), daily:{noNew:true}}));
const c=await p.evaluate(()=>{ const x=__kl.counts(); return {newN:x.newN, dueN:x.dueN}; });
ok(c.newN===0,'nothing new is offered');
ok(c.dueN>0,'scheduled reviews are untouched ('+c.dueN+')');
await ctx.close();
}
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'EVERY SETTING DOES WHAT IT SAYS'));
process.exit(fails.length?1:0);})();
