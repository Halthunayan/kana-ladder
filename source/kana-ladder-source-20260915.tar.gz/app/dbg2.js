const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
const p=await ctx.newPage();
p.on('pageerror',e=>console.log('PAGEERROR',e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1200);
const keys=await p.evaluate(()=>{
  const D=JSON.parse(document.getElementById('deck-data').textContent).slice(0,100);
  const out=[]; D.forEach(c=>{out.push(c.id+'|j');}); return out;});
await p.evaluate(async ({keys,rev})=>{
  await new Promise(res=>{const r=indexedDB.deleteDatabase('kanaladder');
    r.onsuccess=()=>res(1); r.onerror=()=>res(0); r.onblocked=()=>res(0); setTimeout(()=>res(0),1500);});
  const now=Date.now(); const items={};
  keys.forEach(k=>{ items[k]=[1,0,3,2.5,5,now-86400000,0,0,3,3]; });
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev,
    settings:{newPerDay:0,revCap:100000,reverse:"grad",softCap:false,separate:false,listen:true,
      sentences:true,sentPerDay:0,badge:false,typing:false,kanji:true,tts:false,theme:"auto"},
    daily:{key:"",newDone:0,revDone:0,ans:0,ok:0,credit:0,sentDone:0,consDone:0,buried:{},done:{}},
    hist:{},streak:{cur:0,best:0,last:""},life:{ans:0,ok:0},backup:{last:""},notes:{},susp:{},items}));
},{keys,rev:1000000});
await p.reload(); await p.waitForTimeout(1500);
console.log(JSON.stringify(await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {storedItems:Object.keys(d.items).length, rev:d.rev, revCap:d.settings.revCap,
    tileNew:document.querySelector('#tileNew .n').textContent,
    tileLrn:document.querySelector('#tileLrn .n').textContent,
    tileDue:document.querySelector('#tileDue .n').textContent,
    btn:document.getElementById('startBtn').textContent,
    sample:Object.entries(d.items)[0]};}),null,1));
await b.close();})();
