/* The 30-day audit. Until 15 September 2026 this file contained 26 logging
   calls and no assertions, so it printed numbers and then printed AUDIT
   COMPLETE whatever they were: it could not fail. It also only ever exercised
   study mode, which is one of the three modes in the app. Two of the defects
   Ryan reported, both about a word repeating, sat in that blind spot.
   Every number that means something now has a threshold, and Focus and car
   mode run for the same simulated month. */
const {chromium}=require('playwright');
const R=[]; const log=(k,v)=>{R.push([k,v]); console.log(String(k).padEnd(46),v);};
const fails=[];
const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m); } };
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});

// ---------- 1. cold load, performance, integrity ----------
{
  const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
  await ctx.addInitScript(()=>{const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    try{window.speechSynthesis.speak=()=>{};window.speechSynthesis.cancel=()=>{};}catch(e){}});
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error'){const l=m.location()||{};errs.push('console '+m.text()+' @ '+(l.url||'?'));}});
  const t0=Date.now();
  await p.goto('http://localhost:8099/index.html',{waitUntil:'load'});
  await p.waitForSelector('#lvlN'); const tLoad=Date.now()-t0;
  await p.waitForTimeout(1200);
  log('cold load to first paint (ms)',tLoad);
  const m=await p.evaluate(()=>({words:JSON.parse(document.getElementById('deck-data').textContent).length,
    sents:JSON.parse(document.getElementById('sent-data').textContent).length,
    sw:!!navigator.serviceWorker.controller || true}));
  log('words in page',m.words); log('sentences in page',m.sents);
  const nav=await p.evaluate(()=>{const e=performance.getEntriesByType('navigation')[0];
    return {transfer:Math.round((e.transferSize||0)/1024), dom:Math.round(e.domContentLoadedEventEnd)};});
  log('page transfer size (KB)',nav.transfer);
  // render timing on the heaviest screen
  const tStats=await p.evaluate(()=>{const t=performance.now();
    document.querySelector('.tab[data-go="stats"]').click(); return Math.round(performance.now()-t);});
  await p.waitForTimeout(400);
  log('progress screen render (ms)',tStats);
  const heat=await p.evaluate(()=>document.querySelectorAll('#heat .cell').length);
  log('heatmap cells',heat);
  const tBrowse=await p.evaluate(()=>{const t=performance.now();
    document.querySelector('.tab[data-go="browse"]').click(); return Math.round(performance.now()-t);});
  await p.waitForTimeout(300);
  log('browse screen render (ms)',tBrowse);
  const tSearch=await p.evaluate(()=>{const i=document.getElementById('q'); i.value='taberu';
    const t=performance.now(); i.dispatchEvent(new Event('input')); return Math.round(performance.now()-t);});
  log('search across 1812 words (ms)',tSearch);
  log('console errors on load',errs.length?errs.join(' | '):'none');
  ok(errs.length===0, errs.length? 'console errors on load: '+errs[0] : 'the app loads with no console or page errors');
  ok(m.words>1700 && m.sents>1400, 'the shipped deck is whole ('+m.words+' words, '+m.sents+' sentences)');
  ok(heat>0, 'the progress heatmap renders ('+heat+' cells)');
  ok(tLoad<12000, 'cold load is not pathological ('+tLoad+' ms)');
  ok(tStats<3000 && tBrowse<3000 && tSearch<3000,
     'no screen takes seconds to draw (stats '+tStats+', browse '+tBrowse+', search '+tSearch+' ms)');
  await ctx.close();
}

// ---------- 2. a full simulated month in the real app ----------
{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(()=>{
    const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    try{window.speechSynthesis.speak=()=>{};window.speechSynthesis.cancel=()=>{};}catch(e){}
    let off=0; try{off=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;}catch(e){}
    const RD=Date, rn=Date.now;
    window.Date=new Proxy(RD,{construct(t,a){return a.length?new t(...a):new t(rn()+off);},
      get(t,k){return k==='now'?(()=>rn()+off):t[k];}});
  });
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error'){const l=m.location()||{};errs.push('console '+m.text()+' @ '+(l.url||'?'));}});
  await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1200);
  let totalAnswers=0, maxSession=0, twiceInDay=0, repeats=0; const repeatDetail=[];
  for(let day=1; day<=30; day++){
    const btn=await p.$('#startBtn');
    if(btn && !(await btn.isDisabled())) await btn.click();
    let n=0; const seenKeys=[];
    for(let i=0;i<600;i++){
      if(await p.$('#s-review.on')===null) break;
      await p.waitForSelector('#showBtn',{state:'visible',timeout:5000}).catch(()=>{});
      /* The real card key, not the text on the face. Two different cards can
         show the same front, so the face over-counted repeats eightfold and
         made the number unusable, which is part of why nobody put a threshold
         on it. The grade is recorded with it: a card served again straight
         after a miss is the relearning step doing its job, and only a repeat
         after a pass is a fault. */
      const cur=await p.evaluate(()=>{const k=window.__kl, s=k&&k.sess(); if(!s||!s.on) return null;
        const it=k.S.items[s.key]; return {key:s.key, due: it&&it.due? it.due-Date.now() : null};}).catch(()=>null);
      const key=cur?cur.key:null;
      await p.click('#showBtn').catch(()=>{});
      await p.waitForSelector('.grade.g2',{state:'visible',timeout:5000}).catch(()=>{});
      const r=Math.random();
      const gr = r<0.06?0:(r<0.16?3:2);
      if(key) seenKeys.push({key, gr, dueIn:cur.due});
      await p.click(gr===0?'.grade.g0':(gr===3?'.grade.g3':'.grade.g2')).catch(()=>{});
      // a miss now holds the screen with the words it is confused with
      const mn=await p.$('#missNext');
      if(mn && await mn.isVisible()) await mn.click().catch(()=>{});
      await p.waitForTimeout(8); n++;
    }
    totalAnswers+=n; if(n>maxSession) maxSession=n;
    for(let i=1;i<seenKeys.length;i++){
      const a=seenKeys[i-1], c=seenKeys[i];
      if(a.key!==c.key) continue;
      if(a.gr===0) continue;                 // relearning step, doing its job
      if(c.dueIn!==null && c.dueIn<=0) continue;  // its step really had elapsed
      repeats++; repeatDetail.push(c.key+' still '+Math.round(c.dueIn/1000)+'s from due');
    }
    const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click();
    await p.waitForTimeout(120);
    const dayCheck=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
      const done=Object.keys(d.daily.done||{}), bur=Object.keys(d.daily.buried||{});
      const words=done.map(k=>k.split('|')[0]);
      return words.filter((w,i)=>words.indexOf(w)!==i).length;});
    twiceInDay += dayCheck;
    await p.evaluate(()=>{const o=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;
      localStorage.setItem('__tOffset',String(o+86400000));});
    await p.reload(); await p.waitForTimeout(700);
  }
  log('30 days simulated: total answers',totalAnswers);
  log('  busiest single day',maxSession);
  log('  same card served twice in a row',repeats);
  log('  a word finished twice in one day',twiceInDay);
  const fin=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
    const k=Object.keys(d.items);
    return {items:k.length, words:new Set(k.filter(x=>x[0]==='c').map(x=>x.split('|')[0])).size,
      listen:k.filter(x=>x.endsWith('|a')).length, sent:k.filter(x=>x[0]==='s').length,
      lapses:Object.values(d.items).reduce((a,v)=>a+v[6],0),
      lvl:document.getElementById('lvlN').textContent, score:document.getElementById('lvlScore').textContent,
      streak:d.streak.cur, acc:Math.round(d.life.ok/d.life.ans*100)+'%', bytes:localStorage.getItem('kanaladder.v1').length};});
  log('  cards in rotation',fin.items);
  log('  distinct words met',fin.words);
  log('  listening cards',fin.listen);
  log('  sentence cards',fin.sent);
  log('  total lapses',fin.lapses);
  log('  level after 30 days',fin.lvl+' '+fin.score);
  log('  streak',fin.streak); log('  accuracy',fin.acc);
  log('  saved state size (KB)',Math.round(fin.bytes/1024));
  log('errors during the month',errs.length?errs.slice(0,3).join(' | '):'none');
  ok(errs.length===0, errs.length? 'errors during the month: '+errs[0] : 'a simulated month produced no errors');
  ok(totalAnswers>200, 'the month actually studied ('+totalAnswers+' answers)');
  ok(repeats===0, repeats? 'a card was served twice in a row after a pass '+repeats+' times: '
       +repeatDetail.slice(0,3).join('; ')
     : 'no card was served twice in a row except straight after a miss, which is the relearning step');
  ok(twiceInDay===0, twiceInDay? 'a word was finished twice in one day '+twiceInDay+' times'
     : 'no word was finished twice in one day');
  ok(maxSession<=300, 'no single day exploded ('+maxSession+' answers on the busiest)');
  ok(Math.round(fin.bytes/1024)<2000, 'saved state stays well inside the storage budget ('
     +Math.round(fin.bytes/1024)+' KB)');
  ok(fin.words>0 && fin.items>0, 'the month left real progress behind ('+fin.words+' words met)');
  await ctx.close();
}

// ---------- 3. offline after install ----------
{
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(2500);
  await p.click('#startBtn');
  for(let i=0;i<12;i++){const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
    const g=await p.$('.grade.g2'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);}}
  const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(300);
  await ctx.setOffline(true); await p.reload(); await p.waitForTimeout(1500);
  const off=await p.evaluate(()=>({t:document.title,
    words:JSON.parse(document.getElementById('deck-data').textContent).length,
    sents:JSON.parse(document.getElementById('sent-data').textContent).length,
    items:Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length}));
  log('offline reload title',off.t);
  log('offline words / sentences',off.words+' / '+off.sents);
  log('offline progress preserved (items)',off.items);
  for(const t of ['browse','stats','set']){ await p.click('.tab[data-go="'+t+'"]'); await p.waitForTimeout(350); }
  log('offline screens render',await p.evaluate(()=>document.querySelectorAll('#heat .cell').length>0?'yes':'no'));
  log('offline errors',errs.length?errs.join(' | '):'none');
  ok(errs.length===0, errs.length? 'offline errors: '+errs[0] : 'a month-old install reopens offline with no errors');
  ok(/./.test(off.t) && off.words>1700 && off.sents>1400,
     'the whole deck is available offline ('+off.words+' words, '+off.sents+' sentences)');
  ok(off.items>0, 'progress survives the offline reload ('+off.items+' cards)');
  await ctx.close();
}

// ---------- 4. a month of Focus, which the audit never used to open ----------
{
  const fs=require('fs');
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(raw=>{
    const v=[{lang:'ja-JP',name:'Kyoko'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    window.__spoke=[];
    try{window.speechSynthesis.speak=u=>{window.__spoke.push(u.text);setTimeout(()=>u.onend&&u.onend(),3);};
        window.speechSynthesis.cancel=()=>{};}catch(e){}
    try{ localStorage.setItem('kanaladder.v1', raw); }catch(e){}
    let off=0; try{off=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;}catch(e){}
    const RD=Date, rn=Date.now;
    window.Date=new Proxy(RD,{construct(t,a){return a.length?new t(...a):new t(rn()+off);},
      get(t,k){return k==='now'?(()=>rn()+off):t[k];}});
  }, fs.readFileSync('/tmp/bk.json','utf8'));
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error'){const l=m.location()||{};errs.push('console '+m.text()+' @ '+(l.url||'?'));}});
  await p.goto('http://localhost:8099/index.html');
  await p.waitForFunction(()=>window.__kl&&window.__kl.DECK.length>0,null,{timeout:20000});
  await p.waitForTimeout(1200);
  let backToBack=0, malformed=[], built=0, empty=0;
  for(let day=1; day<=30; day++){
    const r=await p.evaluate(()=>{
      const k=window.__kl, q=k.focusQueue()||[];
      const seq=q.map(x=>x.id);
      const b2b=seq.filter((x,i)=>i>0 && x===seq[i-1]).length;
      const bad=[];
      for(const x of q){
        if(!x||!x.kind){ bad.push('a question with no kind'); continue; }
        if(x.opts){
          if(x.opts.length<2) bad.push(x.kind+' '+x.id+': fewer than two options');
          const right=x.opts.filter(o=>o.ok).length;
          if(right!==1) bad.push(x.kind+' '+x.id+': '+right+' correct options');
          if(new Set(x.opts.map(o=>o.text)).size!==x.opts.length)
            bad.push(x.kind+' '+x.id+': a duplicated option');
        }
      }
      return {n:q.length, b2b, bad:bad.slice(0,4)};
    });
    built += r.n; backToBack += r.b2b; if(!r.n) empty++;
    malformed = malformed.concat(r.bad);
    await p.evaluate(()=>{const o=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;
      localStorage.setItem('__tOffset',String(o+86400000));});
    await p.reload(); await p.waitForTimeout(500);
  }
  log('focus questions built over 30 days',built);
  log('  days with an empty focus queue',empty);
  log('  same word twice in a row',backToBack);
  log('  malformed questions',malformed.length);
  ok(built>0,'Focus builds a queue at all ('+built+' questions over 30 days)');
  ok(backToBack===0, backToBack? 'the same word appeared twice in a row '+backToBack+' times'
     : 'no word is ever asked twice in a row in Focus');
  ok(malformed.length===0, malformed.length? malformed.slice(0,2).join('; ')
     : 'every Focus question has one correct answer and no duplicate option');
  // and one session actually driven through the interface, to catch render faults
  await p.evaluate(()=>{ localStorage.setItem('__tOffset','0'); });
  await p.reload(); await p.waitForTimeout(800);
  const ran=await p.evaluate(async()=>{
    const fb=document.getElementById('focusBtn'); if(!fb) return {opened:false};
    fb.click(); await new Promise(r=>setTimeout(r,600));
    let n=0;
    for(let i=0;i<120;i++){
      const s=window.__kl.sess(); if(!s||!s.on) break;
      const b=document.querySelector('.opt-btn') || document.getElementById('showBtn')
            || document.getElementById('typeGo') || document.getElementById('nextBtn');
      if(!b) break;
      b.click(); n++; await new Promise(r=>setTimeout(r,45));
    }
    return {opened:true, answered:n};
  });
  log('  a focus session driven through the UI',ran.opened? ran.answered+' taps' : 'could not open');
  ok(ran.opened===true,'the Focus button opens a session');
  ok(errs.length===0, errs.length? 'errors in Focus: '+errs[0] : 'a month of Focus produced no errors');
  await ctx.close();
}

// ---------- 5. a drive, on the scaled clock ----------
{
  const fs=require('fs');
  const ctx=await b.newContext({viewport:{width:393,height:852}});
  await ctx.addInitScript(raw=>{
    const v=[{lang:'ja-JP',name:'Kyoko'},{lang:'en-US',name:'Sam'}];
    try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
    window.__said=[];
    window.SpeechSynthesisUtterance=function(t){this.text=t;this.rate=1;this.voice=null;this.lang='';};
    try{window.speechSynthesis.speak=u=>{ let el=0;
          try{ el=window.__kl?Math.round(window.__kl.carEl()):0; }catch(e){}
          window.__said.push({t:u.text, el:el}); setTimeout(()=>u.onend&&u.onend(),8);};
        window.speechSynthesis.cancel=()=>{};}catch(e){}
    try{Object.defineProperty(navigator,'wakeLock',
      {value:{request:()=>Promise.resolve({release(){},addEventListener(){}})}});}catch(e){}
    try{ const d=JSON.parse(raw); d.settings.carChecked=true; d.settings.carMin=0;
         d.settings.carSent=false; d.settings.carConj=false;
         localStorage.setItem('kanaladder.v1', JSON.stringify(d)); }catch(e){}
  }, fs.readFileSync('/tmp/bk.json','utf8'));
  const p=await ctx.newPage(); const errs=[];
  p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
  p.on('console',m=>{if(m.type()==='error'){const l=m.location()||{};errs.push('console '+m.text()+' @ '+(l.url||'?'));}});
  await p.goto('http://localhost:8099/index.html');
  await p.waitForFunction(()=>window.__kl&&window.__kl.DECK.length>0,null,{timeout:20000});
  await p.waitForTimeout(1200);
  await p.evaluate(()=>__kl.carClock(120));
  await p.click('#carBtn').catch(()=>{});
  await p.waitForTimeout(400);
  const drive=await p.evaluate(async()=>{
    /* The gaps are scaled but each clip still plays in real time, so a pass
       costs about five real seconds. Fifty seconds of wall clock is nine or ten
       passes, which is two full rounds of the gap arithmetic. */
    for(let i=0;i<500;i++){ if(!__kl.CAR.running) break; await new Promise(r=>setTimeout(r,100)); }
    /* With the library present the drive plays clips, not the device voice, so
       reading window.__said finds nothing: the first version of this section
       reported zero passes while three clips had played. The clip log is the
       real channel and carries the key directly. */
    const started=__kl.CAR.started;
    const fromClips=(__kl.AUD.log||[]).map(x=>({id:(x.k||'').split(':')[1]||null,
                                                el:Math.round((x.t-started)*120)})).filter(x=>x.id);
    const by={};
    for(const key in __kl.S.items){ const id=key.split('|')[0], c=__kl.IDX[id]; if(!c) continue;
      by[c.kana]=id; by[c.romaji]=id; by[c.en]=id; }
    const fromVoice=(window.__said||[]).map(u=>({id:by[u.t]||null, el:u.el})).filter(x=>x.id);
    const said=(fromClips.length?fromClips:fromVoice).slice().sort((a,b)=>a.el-b.el);
    const passes=[];
    for(const u of said) if(!passes.length || passes[passes.length-1].id!==u.id) passes.push(u);
    const clips=(__kl.AUD.log||[]).length;
    __kl.carFinish(); __kl.carClock(1);
    return {passes, clips, heard:__kl.CAR.heard, channel: fromClips.length?'library':'device voice'};
  });
  const seq=drive.passes.map(x=>x.id);
  const b2b=seq.filter((x,i)=>i>0&&x===seq[i-1]).length;
  const seen={}; let tooSoon=0;
  for(const r of drive.passes){
    if(seen[r.id]!==undefined && r.el-seen[r.id] < 38000) tooSoon++;
    seen[r.id]=r.el;
  }
  log('car passes in one simulated drive',drive.passes.length);
  log('  a word played twice in a row',b2b);
  log('  a word back before its gap',tooSoon);
  log('  clips played from the library',drive.clips);
  log('  channel under test',drive.channel);
  ok(drive.passes.length>=6,'the drive actually ran ('+drive.passes.length+' passes)');
  ok(b2b===0, b2b? 'a word played twice in a row '+b2b+' times' : 'no word played twice in a row');
  ok(tooSoon===0, tooSoon? 'a word came back before its gap '+tooSoon+' times'
     : 'every repeat waited out its gap');
  ok(drive.channel==='library','the drive plays the pre-rendered library, the channel his phone uses');
  ok(errs.length===0, errs.length? 'errors on the drive: '+errs[0] : 'the drive produced no errors');
  await ctx.close();
}

console.log('\n'+(fails.length? 'AUDIT FAILED: '+fails.length+' of the thresholds were not met\n  - '
  +fails.join('\n  - ') : 'AUDIT COMPLETE, every threshold met'));
await b.close();
process.exit(fails.length?1:0);})();
