const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
let p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1200);

// Write a blob shaped like the FIRST shipped build: no credit, no buried/done,
// no backup, no softCap/separate settings. Then reload and see what survives.
const legacy = {
  rev: 42,
  settings:{newPerDay:12,revCap:150,reverse:"grad",typing:false,kanji:true,tts:true,theme:"auto"},
  daily:{key:"2026-09-04",newDone:9,revDone:31,ans:60,ok:55},
  hist:{"2026-09-03":40,"2026-09-04":60},
  streak:{cur:2,best:2,last:"2026-09-04"},
  life:{ans:100,ok:92},
  items:{
    "c0000|j":[1,0,3,2.5,12,Date.now()-86400000,0,0,4,4],
    "c0000|e":[1,0,2,2.36,6,Date.now()+3*86400000,1,12,3,2],
    "c0005|j":[0,1,0,2.5,0,Date.now()-60000,0,0,1,1],
    "c0009|j":[1,0,5,2.7,40,Date.now()+20*86400000,0,0,6,6]
  }
};
await p.evaluate(o=>{ localStorage.setItem('kanaladder.v1',JSON.stringify(o));
  return new Promise(res=>{const r=indexedDB.open('kanaladder',1);
    r.onsuccess=()=>{const t=r.result.transaction('kv','readwrite');t.objectStore('kv').put(o,'state');t.oncomplete=()=>res(1);};
    r.onerror=()=>res(0);});}, legacy);
await p.close();
p=await ctx.newPage();
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);

console.log('after loading a legacy save:');
console.log(JSON.stringify(await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {items:Object.keys(d.items).length,
          streak:d.streak.cur, lifeAns:d.life.ans, lifeOk:d.life.ok,
          settingsSoftCap:d.settings.softCap, settingsSeparate:d.settings.separate,
          dailyCredit:d.daily.credit, buried:typeof d.daily.buried, done:typeof d.daily.done,
          backup:JSON.stringify(d.backup),
          lvl:document.getElementById('lvlN').textContent,
          score:document.getElementById('lvlScore').textContent,
          due:document.querySelector('#tileDue .n').textContent,
          lrn:document.querySelector('#tileLrn .n').textContent,
          btn:document.getElementById('startBtn').textContent};}),null,1));
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(600);
console.log('stats ok:',await p.evaluate(()=>document.querySelectorAll('#heat .cell').length+' cells, level '+document.getElementById('pLvlBig').textContent));
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(800);
console.log('settings:',JSON.stringify(await p.evaluate(()=>({
  sep:document.getElementById('setSep').getAttribute('aria-checked'),
  soft:document.getElementById('setSoft').getAttribute('aria-checked'),
  newPerDay:document.getElementById('setNew').value}))));
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400);
await p.click('#startBtn'); await p.waitForTimeout(500);
console.log('review starts:',await p.evaluate(()=>document.querySelector('.screen.on').id));
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
