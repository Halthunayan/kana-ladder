const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);
// reverse cards from the start, and typing on
await p.click('.tab[data-go="set"]'); await p.waitForTimeout(400);
await p.selectOption('#setRev2','now'); await p.waitForTimeout(200);
await p.click('#setType'); await p.waitForTimeout(200);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(300);
await p.click('#startBtn'); await p.waitForTimeout(400);
async function answer(){ await p.waitForSelector('#showBtn',{state:'visible',timeout:5000}).catch(()=>{});
  await p.click('#showBtn').catch(()=>{}); await p.waitForSelector('.grade.g2',{state:'visible',timeout:5000}).catch(()=>{});
  await p.click('.grade.g2').catch(()=>{}); await p.waitForTimeout(40); }
let found=false;
for(let i=0;i<60;i++){
  const chip=await p.$eval('#dirChip',e=>e.textContent).catch(()=>'');
  if(chip.indexOf('English')===0 && await p.$('#typeIn')){ found=true; break; }
  await answer();
}
if(!found){ console.log('could not reach a reverse card'); await b.close(); return; }
const beforeItems=await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length);
await p.click('#typeIn');
await p.type('#typeIn','mizu z zenzen',{delay:15}); await p.waitForTimeout(300);
const v=await p.$eval('#typeIn',e=>e.value);
console.log('typed value:', JSON.stringify(v));
console.log('  z reached the field:', v.indexOf('z')>=0 ? 'PASS' : 'FAIL');
console.log('  answer still hidden:', await p.evaluate(()=>document.getElementById('fold').hidden) ? 'PASS' : 'FAIL');
// space must also reach the field, not reveal the card
console.log('  space reached the field:', v.indexOf(' ')>=0 ? 'PASS' : 'FAIL');
const afterItems=await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length);
console.log('  no card was scheduled while typing:', beforeItems===afterItems ? 'PASS' : 'FAIL');
// Enter submits
await p.press('#typeIn','Enter'); await p.waitForTimeout(400);
console.log('  Enter reveals the answer:', await p.evaluate(()=>!document.getElementById('fold').hidden) ? 'PASS' : 'FAIL');
console.log('  verdict shown:', await p.$eval('#verdict',e=>e.textContent).catch(()=>'(none)'));
// after reveal, keyboard grading works again
await p.press('body','3'); await p.waitForTimeout(400);
console.log('  keyboard grading works outside the field:', await p.evaluate(()=>Object.keys(JSON.parse(localStorage.getItem('kanaladder.v1')).items).length)>afterItems ? 'PASS':'FAIL');
console.log('errors:', errs.length?errs.join(' | '):'none');
await b.close();})();
