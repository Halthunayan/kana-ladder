const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1500);
// record the (word, direction) of every card served, in order
await p.evaluate(()=>{window.__seen=[];});
async function run(n){
  const seq=[];
  for(let i=0;i<n;i++){
    if(await p.$('#s-review.on')===null) break;
    const info=await p.evaluate(()=>{const c=window.__k; return null;}).catch(()=>null);
    const chip=await p.$eval('#dirChip',e=>e.textContent).catch(()=>null);
    const kana=await p.$eval('.face .kana, .face .english',e=>e.textContent).catch(()=>null);
    seq.push((chip||'').indexOf('Japanese')===0?'J:'+kana:'E:'+kana);
    const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(20);}
    const g=await p.$('.grade.g3'); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(20);}
  }
  return seq;
}
await p.click('#startBtn');
let seq=await run(120);
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(300);
console.log('cards served day 1:',seq.length);
// any word appearing twice in one day?
const byWord={};
const state=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {keys:Object.keys(d.items), buried:Object.keys(d.daily.buried||{}), newDone:d.daily.newDone};});
const words=state.keys.map(k=>k.split('|')[0]);
const dupes=words.filter((w,i)=>words.indexOf(w)!==i);
console.log('items:',state.keys.length,'| words touched twice today:',dupes.length,'| buried:',state.buried.length);
console.log('home note:',await p.$eval('#startNote',e=>e.textContent));
// study ahead must also respect the bury
await p.click('#startBtn'); await p.waitForTimeout(400);
const inRev=await p.$('#s-review.on');
if(inRev){ const s2=await run(60);
  const q2=await p.$('#quitBtn'); if(q2&&await q2.isVisible()) await q2.click(); await p.waitForTimeout(300);
  const st2=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));return Object.keys(d.items);});
  const w2=st2.map(k=>k.split('|')[0]);
  console.log('after study-ahead: items',st2.length,'| words twice today:',w2.filter((w,i)=>w2.indexOf(w)!==i).length);
} else { console.log('study ahead: nothing available (all remaining are buried)'); }
// next day: the reverse cards should now be available
await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  for(const k in d.items) d.items[k][5]-=2*86400000;
  d.daily={key:'',newDone:0,revDone:0,ans:0,ok:0,credit:0,buried:{}};
  localStorage.setItem('kanaladder.v1',JSON.stringify(d));});
await p.reload(); await p.waitForTimeout(1200);
console.log('next day tiles:',JSON.stringify(await p.evaluate(()=>({n:document.querySelector('#tileNew .n').textContent,l:document.querySelector('#tileLrn .n').textContent,d:document.querySelector('#tileDue .n').textContent}))));
await p.click('#startBtn');
const seq2=await run(30);
console.log('day 2 first 8 served:',seq2.slice(0,8).join('  |  '));
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
