const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
let p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1400);

async function run(n){
  const seq=[];
  for(let i=0;i<n;i++){
    if(await p.$('#s-review.on')===null) break;
    await p.waitForSelector('#showBtn',{state:'visible',timeout:4000}).catch(()=>{});
    const chip=await p.$eval('#dirChip',e=>e.textContent);
    const face=await p.$eval('#faceFront',e=>e.textContent.trim().split('\n')[0]);
    seq.push((chip.indexOf('Japanese')===0?'J:':'E:')+face);
    await p.click('#showBtn');
    await p.waitForSelector('.grade.g3',{state:'visible',timeout:4000});
    await p.click('.grade.g3');
    await p.waitForTimeout(60);
  }
  return seq;
}
await p.click('#startBtn');
let s1=await run(200);
console.log('day 1 served:',s1.length,'| unique:',new Set(s1).size,'| adjacent repeats:',s1.filter((x,i)=>i>0&&x===s1[i-1]).length);
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click(); await p.waitForTimeout(400);

// second session same day
await p.click('#startBtn'); await p.waitForTimeout(400);
let s2=[];
if(await p.$('#s-review.on')){ s2=await run(200); const q2=await p.$('#quitBtn'); if(q2&&await q2.isVisible()) await q2.click(); }
console.log('study-ahead served:',s2.length,'| overlap with session 1 words:',
  s2.filter(x=>s1.some(y=>y.slice(2)===x.slice(2))).length);
const day1=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const w=Object.keys(d.items).map(k=>k.split('|')[0]);
  return {items:Object.keys(d.items).length, wordsTwice:w.filter((x,i)=>w.indexOf(x)!==i).length,
          reverseCards:Object.keys(d.items).filter(k=>k.endsWith('|e')).length, buried:Object.keys(d.daily.buried||{}).length};});
console.log('day 1 state:',JSON.stringify(day1));

// --- advance a day cleanly: close the page so its unload write lands first ---
const blob=await p.evaluate(()=>localStorage.getItem('kanaladder.v1'));
await p.close();
p=await ctx.newPage();
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1200);
await p.evaluate((raw)=>{
  const d=JSON.parse(raw);
  for(const k in d.items) d.items[k][5]-=3*86400000;
  d.daily={key:'',newDone:0,revDone:0,ans:0,ok:0,credit:0,buried:{}};
  d.rev=(d.rev||0)+1000;
  localStorage.setItem('kanaladder.v1',JSON.stringify(d));
  return new Promise(res=>{const r=indexedDB.open('kanaladder',1);
    r.onsuccess=()=>{const t=r.result.transaction('kv','readwrite');t.objectStore('kv').put(d,'state');t.oncomplete=()=>res(1);};
    r.onerror=()=>res(0);});
}, blob);
await p.reload(); await p.waitForTimeout(1400);
console.log('day 2 tiles:',JSON.stringify(await p.evaluate(()=>({
  n:document.querySelector('#tileNew .n').textContent, l:document.querySelector('#tileLrn .n').textContent,
  d:document.querySelector('#tileDue .n').textContent, btn:document.getElementById('startBtn').textContent}))));
await p.click('#startBtn');
const s3=await run(60);
console.log('day 2 first 10:',s3.slice(0,10).join('  |  '));
console.log('day 2 adjacent repeats:',s3.filter((x,i)=>i>0&&x===s3[i-1]).length,'| reverse cards served:',s3.filter(x=>x[0]==='E').length);
const d2=await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  const w=Object.keys(d.daily.buried||{}); return {buriedToday:w.length};});
console.log('day 2:',JSON.stringify(d2));
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
