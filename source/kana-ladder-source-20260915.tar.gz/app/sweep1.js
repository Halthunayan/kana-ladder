/* Every number the app puts on screen, recomputed independently from the saved
   state and compared. The two defects found so far were both of this shape. */
const {chromium}=require('playwright');
const fails=[]; const ok=(c,m)=>{ if(c) console.log('  PASS  '+m); else { fails.push(m); console.log('  FAIL  '+m);} };
const num=t=>+String(t).replace(/[^0-9.]/g,'');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{
  const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  const now=Date.now(), items={}, hist={}, log=[];
  const day=d=>new Date(now-d*86400000-14400000).toISOString().slice(0,10);
  // a messy, realistic state: every card type, every state, some suspended, some lapsed
  for(let i=0;i<120;i++){ const id='c'+String(i).padStart(4,'0');
    const iv = i<20?40 : (i<80?6 : 1);
    const st = i<100?1:0;
    items[id+'|j']=[st,0,4,2.5-(i%5)*0.15,iv,now+(i%7-3)*86400000,i%9===0?3:0,0,8,6,4+(i%5),iv,now-2*86400000]; }
  for(let i=0;i<40;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|e']=[1,0,3,2.4,5,now+(i%5-2)*86400000,0,0,5,4,5,5,now-86400000]; }
  for(let i=0;i<15;i++){ const id='c'+String(i).padStart(4,'0');
    items[id+'|a']=[1,0,2,2.5,3,now+86400000,0,0,3,3,5,3,now-86400000]; }
  items['s001|j']=[1,0,2,2.5,9,now+9*86400000,0,0,3,3,5,9,now-86400000];
  items['s002|j']=[1,0,2,2.5,2,now-86400000,0,0,3,3,5,2,now-86400000];
  items['g001|j']=[1,0,2,2.5,9,now+9*86400000,0,0,3,3,5,9,now-86400000];
  items['g002|j']=[0,1,0,2.5,0,now+600000,0,0,1,0,0,0,0];
  const susp={'c0005|j':1,'c0006|e':1};
  for(let d=0;d<12;d++) hist[day(d)]=10+d*3;
  for(let i=0;i<57;i++) log.push([Math.round(now/1000)-i*600, i, i%3, 1+(i%4), 1.5, 1]);
  localStorage.setItem('kanaladder.v1', JSON.stringify({rev:99,
    settings:{sched:"fsrs",retention:0.9,newPerDay:12,revCap:150,reverse:"grad",softCap:true,separate:true,
      sentences:true,sentPerDay:4,conj:true,conjPerDay:2,listen:true,tts:true,autoPlay:true,
      badge:true,typing:false,kanji:true,theme:"dark"},
    daily:{key:new Date(now-14400000).toISOString().slice(0,10),newDone:5,revDone:31,ans:44,ok:37,credit:1,
      sentDone:1,conjDone:1,consDone:3,noNew:false,buried:{},done:{},missed:{'c0003|j':1,'c0007|j':1}},
    hist, streak:{cur:12,best:19,last:""}, life:{ans:900,ok:800,practice:120},
    backup:{last:""}, notes:{}, susp, pfail:{}, log, items}));
});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR '+e.message));
p.on('console',m=>{if(m.type()==='error'&&!/favicon|sw\.js|404/.test(m.text()))errs.push('console '+m.text());});
await p.goto('http://localhost:8100/index.html'); await p.waitForTimeout(1500);
await p.evaluate(()=>{ __kl.TTS.ja=true; __kl.TTS.voices=speechSynthesis.getVoices(); });
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(300);
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(600);

// ---------- ground truth, computed here rather than by the app ----------
const T = await p.evaluate(()=>{
  const S=__kl.S, DECK=__kl.DECK, SENT=__kl.SENT, CONJ=__kl.CONJ, IDX=__kl.IDX;
  const dayEnd=(()=>{const d=new Date(); d.setHours(23,59,59,999); return d.getTime();})();
  const susp=k=>!!S.susp[k];
  const done=k=>!!(S.daily.done&&S.daily.done[k]);
  const buried=k=>!!(S.daily.buried&&S.daily.buried[k]);
  const usable=k=>!susp(k)&&!done(k)&&!buried(k);
  let due=0, lrn=0, mat=0, yng=0, lrnState=0, rot=0, words=new Set(), ivs=[], dfs=[];
  for(const k in S.items){ const it=S.items[k];
    if(!susp(k)) rot++;
    const id=k.split('|')[0], c=IDX[id];
    if(c && c.t==='w') words.add(id);
    if(it.s===1){ if(it.iv>=21) mat++; else yng++; ivs.push(it.iv); if(it.sb>0) dfs.push(it.df); }
    else lrnState++;
    if(usable(k)){ if(it.s===1 && it.due<=dayEnd) due++; else if(it.s!==1) lrn++; }
  }
  // fresh material still available today, inside its own budget
  let nw=0; for(let i=0;i<DECK.length;i++){ const k=DECK[i].id+'|j'; if(!S.items[k]&&usable(k)) nw++; }
  let cs=0;
  for(let i=0;i<DECK.length;i++){ const id=DECK[i].id, j=S.items[id+'|j']; if(!j) continue;
    const grad=j.s===1;
    if(S.settings.reverse!=='off' && !S.items[id+'|e'] && usable(id+'|e') && grad) cs++;
    // a word that sounds like another word gets no listening card
    if(!__kl.soundIsAmbiguous(id) && !S.items[id+'|a'] && usable(id+'|a') && grad) cs++; }
  let sn=0;
  for(const x of SENT){ const sj=x.id+'|j';
    // a sentence opens with at most one word still unknown, which is the gap setting
    if(!S.items[sj]){ if(__kl.sentOpen(x) && usable(sj)) sn++; }
    else {
      // the transactional lines are also asked the other way round
      if(x.say && !S.items[x.id+'|e'] && usable(x.id+'|e') && S.items[sj].s===1) sn++;
      if(!S.items[x.id+'|a'] && usable(x.id+'|a') && S.items[sj].s===1) sn++; } }
  let cj=0;
  for(const g of CONJ){ const gj=g.id+'|j'; if(S.items[gj]||!usable(gj)) continue;
    const par=S.items[g.w[0]+'|j']; if(par && par.s===1 && par.iv>=7) cj++; }
  // the allowance formulas are proved in sweep2; here the app's own figures are the model
  const newLeft=Math.max(0,__kl.newAllowance()-S.daily.newDone);
  // the follow-up budget now tracks the new-word rate unless it is pinned
  // the budget now carries a backlog term, so the app's own figure is the model
  const consN=__kl.consAllowance();
  const consLeft=Math.max(0,consN-S.daily.consDone);
  const sentLeft=Math.max(0,S.settings.sentPerDay-S.daily.sentDone);
  const conjLeft=Math.max(0,S.settings.conjPerDay-S.daily.conjDone);
  const revLeft=Math.max(0,S.settings.revCap-S.daily.revDone);
  const listenOn=true;
  const total=DECK.length*3 + SENT.length*2 + CONJ.length;
  // score, recomputed from scratch
  const W=[0.212,1.2931,2.3065,8.2956,6.4133,0.8334,3.0194,0.001,1.8722,0.1666,0.796,
           1.4835,0.0614,0.2629,1.6483,0.6014,1.8729,0.5425,0.0912,0.0658,0.1542];
  const decay=-W[20], factor=Math.pow(0.9,1/decay)-1;
  const R=(t,S0)=>S0<=0?0:Math.pow(1+factor*(Math.max(0,t)/S0),decay);
  const str=it=>{ if(!it) return 0; if(it.s!==1) return 0.12;
    const iv=(typeof it.iv==='number'&&isFinite(it.iv)&&it.iv>0)?it.iv:1;
    let base=Math.min(1, Math.log(1+iv)/Math.log(61));
    if(typeof it.due==='number'&&isFinite(it.due)){
      const over=(Date.now()-it.due)/86400000;
      if(over>0){ const sb=(typeof it.sb==='number'&&isFinite(it.sb)&&it.sb>0)?it.sb:iv;
        const r=R(iv+over,sb);
        if(isFinite(r)&&r>=0&&r<1) base*=Math.max(0,Math.min(1,r/0.9)); } }
    return Math.max(0,Math.min(1,base)); };
  let rec=0,rcl=0,lis=0,sc=0,known=0;
  for(const c of DECK){ const a=str(S.items[c.id+'|j']), e=str(S.items[c.id+'|e']), l2=str(S.items[c.id+'|a']);
    rec+=a; rcl+=e; lis+=l2; sc+=0.45*a+0.35*e+0.20*l2; if(a>=0.5) known++; }
  let sent=0; for(const x of SENT) if(str(S.items[x.id+'|j'])>=0.4) sent++;
  let conj=0; for(const g of CONJ) if(str(S.items[g.id+'|j'])>=0.4) conj++;
  const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
  const pctOf=v=>{const x=v*100; return (x>0&&x<10)?(Math.round(x*10)/10).toFixed(1)+'%':Math.round(x)+'%';};
  return {due:Math.min(due,revLeft), lrn, newTile:Math.min(newLeft,nw)+Math.min(consLeft,cs)+Math.min(sentLeft,sn)+Math.min(conjLeft,cj),
    mat, yng, lrnState, rot, words:words.size, total,
    score:Math.round(sc), rec:pctOf(rec/DECK.length), rcl:pctOf(rcl/DECK.length),
    lis:pctOf(lis/DECK.length), known, sent, sentTot:SENT.length, conj, conjTot:CONJ.length,
    ans:S.daily.ans, ok:S.daily.ok, log:S.log.length, life:S.life.ans, prac:S.life.practice,
    avgIv:avg(ivs), avgDf:avg(dfs), acc:S.life.ans?Math.round(S.life.ok/S.life.ans*100):null,
    maxHist:Math.max(...Object.values(S.hist)), streak:S.streak.cur, best:S.streak.best,
    longestIv:(function(){ let mx=0; for(const k in S.items){ if(S.susp[k]) continue; const it=S.items[k];
      if(it.s===1 && it.iv>mx) mx=it.iv; } return mx?__kl.ivLabel(mx*86400000):'\u2014'; })()};
});
const D = await p.evaluate(()=>{ const g=id=>{const e=document.getElementById(id); return e?e.textContent.trim():null;};
  return {tileNew:g('tileNew'), tileLrn:g('tileLrn'), tileDue:g('tileDue'), startBtn:g('startBtn'),
    progAux:g('progAux'), mat:g('lgMat'), yng:g('lgYng'), lrn:g('lgLrn'), untouched:g('lgNew'),
    pracNote:g('pracNote'), kvAns:g('kvAns'), kvAcc:g('kvAcc'), streakAux:g('streakAux'),
    lvlScore:g('lvlScore'), lvlAux:g('lvlAux')};});
console.log('\n1. the study screen');
ok(num(D.tileNew)===T.newTile,'NEW tile = new words + follow-ups + sentences + conjugation still inside budget ('+D.tileNew+' vs '+T.newTile+')');
ok(num(D.tileLrn)===T.lrn,'LEARNING tile ('+D.tileLrn+' vs '+T.lrn+')');
ok(num(D.tileDue)===T.due,'DUE tile, capped by the review cap ('+D.tileDue+' vs '+T.due+')');
const btnTotal=num(D.tileNew)+num(D.tileLrn)+num(D.tileDue);
ok(D.startBtn.indexOf(String(btnTotal))>=0,'the start button total equals the three tiles ("'+D.startBtn+'")');

console.log('\n2. deck progress');
ok(num(D.mat)===T.mat,'mature ('+D.mat+' vs '+T.mat+')');
ok(num(D.yng)===T.yng,'young ('+D.yng+' vs '+T.yng+')');
ok(num(D.lrn)===T.lrnState,'learning ('+D.lrn+' vs '+T.lrnState+')');
ok(num(D.mat)+num(D.yng)+num(D.lrn)+num(D.untouched)===T.total,'all four add up to '+T.total);
ok(D.progAux===T.words.toLocaleString()+' words · '+(T.mat+T.yng+T.lrnState).toLocaleString()+' cards started',
   'the header states both units, words and cards ("'+D.progAux+'")');

console.log('\n3. today, streak and practice');
ok(num(D.kvAns)===T.ans,'cards answered today ('+D.kvAns+' vs '+T.ans+')');
ok(T.ans===0 || num(D.kvAcc)===Math.round(T.ok/T.ans*100),'first-try accuracy ('+D.kvAcc+')');
ok(num(D.pracNote)===T.rot,'practice rotation excludes suspended cards ('+D.pracNote+' vs '+T.rot+')');
ok(/12/.test(D.streakAux)&&/19/.test(D.streakAux),'streak shows current and best ("'+D.streakAux+'")');

console.log('\n4. the progress screen');
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(600);
const P = await p.evaluate(()=>{ const g=id=>{const e=document.getElementById(id); return e?e.textContent.trim():null;};
  return {big:g('pLvlBig'), score:g('pLvlScore'), rec:g('pRecog'), rcl:g('pRecall'), lis:g('pListen'),
    sent:g('pSent'), conj:g('pConj'), rot:g('nRot'), ef:g('nEf'), efLabel:g('nEfLabel'),
    iv:g('nIv'), ans:g('nAns'), prac:g('nPrac'), log:g('nLog'), acc:g('nAcc'), max:g('nMax'),
    lvlAux:g('lvlAux'), heat:[...document.querySelectorAll('#heat .cell')].length};});
ok(num(P.score)===T.score,'score matches an independent recomputation ('+P.score+' vs '+T.score+')');
ok(P.rec===T.rec && P.rcl===T.rcl && P.lis===T.lis,
  'recognition / recall / listening ('+P.rec+' '+P.rcl+' '+P.lis+' vs '+T.rec+' '+T.rcl+' '+T.lis+')');
ok(P.sent===T.sent+' / '+T.sentTot,'sentences read ("'+P.sent+'")');
ok(P.conj===T.conj+' / '+T.conjTot,'conjugation rules ("'+P.conj+'")');
ok(num(P.rot)===T.rot,'cards in rotation on the progress screen ('+P.rot+' vs '+T.rot+')');
ok(num(P.log)===T.log,'review log size ('+P.log+' vs '+T.log+')');
ok(num(P.ans)===T.life,'lifetime answers ('+P.ans+' vs '+T.life+')');
ok(num(P.prac)===T.prac,'practice answers ('+P.prac+' vs '+T.prac+')');
ok(num(P.acc)===T.acc,'lifetime accuracy ('+P.acc+' vs '+T.acc+'%)');
ok(P.max===T.longestIv,'longest interval ("'+P.max+'" vs "'+T.longestIv+'")');
ok(Math.abs(num(P.iv)-T.avgIv)<0.6,'average interval ('+P.iv+' vs '+T.avgIv.toFixed(1)+'d)');
ok(P.efLabel==='Average difficulty' && Math.abs(num(P.ef)-T.avgDf)<0.15,'average difficulty ('+P.ef+' vs '+T.avgDf.toFixed(1)+')');
ok(/'?'?/.test(P.lvlAux) && num(P.lvlAux)===T.known,'"words recognised" uses the >=0.5 strength rule ('+P.lvlAux+' vs '+T.known+')');
ok(P.heat===15,'the heatmap draws all 15 areas (got '+P.heat+')');

console.log('\n5. proficiency by area sums back to the whole deck');
const area = await p.evaluate(()=>{
  const S=__kl.S, DECK=__kl.DECK;
  const cells=[...document.querySelectorAll('#heat .cell .ct')].map(e=>e.textContent);
  let n=0; const m=/(\d+)\s*\/\s*(\d+)/g;
  const totals=cells.map(t=>{ const mm=t.match(/of\s+(\d+)\s+recognised/); return mm?+mm[1]:null; });
  return {cells:cells.slice(0,2), totals};
});
const areaSum=area.totals.filter(x=>x!==null).reduce((a,c)=>a+c,0);
ok(areaSum===1812,'the 15 area sizes add to the whole deck ('+areaSum+')');
ok(errs.length===0, errs.length? errs.slice(0,3).join(' | ') : 'no page errors anywhere in the sweep');
await b.close();
console.log('\n'+(fails.length? fails.length+' FAILURES: '+fails.join('; ') : 'EVERY DISPLAYED NUMBER MATCHES'));
process.exit(fails.length?1:0);})();
