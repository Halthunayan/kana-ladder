const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(()=>{const v=[{lang:'ja-JP',name:'Kyoko'}];
  try{Object.defineProperty(window.speechSynthesis,'getVoices',{value:()=>v});}catch(e){}
  try{window.speechSynthesis.speak=()=>{};window.speechSynthesis.cancel=()=>{};}catch(e){}
  let off=0; try{off=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;}catch(e){}
  const RD=Date, rn=Date.now;
  window.Date=new Proxy(RD,{construct(t,a){return a.length?new t(...a):new t(rn()+off);},
    get(t,k){return k==='now'?(()=>rn()+off):t[k];}});});
const p=await ctx.newPage();
p.on('pageerror',e=>console.log('PAGEERROR',e.message));
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1400);
let worstDay=null, totalDup=0, adjacent=0;
for(let day=1; day<=12; day++){
  const btn=await p.$('#startBtn'); if(btn && !(await btn.isDisabled())) await btn.click();
  const served=[]; let prevSig=null;
  for(let i=0;i<400;i++){
    if(await p.$('#s-review.on')===null) break;
    await p.waitForSelector('#showBtn',{state:'visible',timeout:5000}).catch(()=>{});
    await p.click('#showBtn').catch(()=>{});
    await p.waitForSelector('.grade.g2',{state:'visible',timeout:5000}).catch(()=>{});
    // identify the card from the ANSWER side, which always shows the Japanese
    const sig=await p.evaluate(()=>{
      const chip=document.getElementById('dirChip').textContent;
      const k=document.querySelector('#faceBack .kana')||document.querySelector('#faceFront .kana');
      const e=document.querySelector('#faceBack .english')||document.querySelector('#faceFront .english');
      return (k?k.textContent:'')+'##'+(e?e.textContent:'')+'##'+chip;});
    if(sig===prevSig) adjacent++;
    prevSig=sig; served.push(sig);
    const r=Math.random();
    await p.click(r<0.08?'.grade.g0':(r<0.18?'.grade.g3':'.grade.g2')).catch(()=>{});
    await p.waitForTimeout(12);
  }
  const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click();
  await p.waitForTimeout(120);
  const d=await p.evaluate(()=>{const x=JSON.parse(localStorage.getItem('kanaladder.v1'));
    return {done:Object.keys(x.daily.done||{}), buried:Object.keys(x.daily.buried||{}), sep:x.settings.separate};});
  const words={}; const dup=[];
  d.done.forEach(k=>{const w=k.split('|')[0]; if(words[w]) dup.push(words[w]+' + '+k); words[w]=k;});
  totalDup+=dup.length;
  if(dup.length && !worstDay) worstDay={day, dup:dup.slice(0,6), served:served.length, sep:d.sep};
  // how many distinct Japanese faces repeated inside one day
  const jp=served.map(s=>s.split('##')[0]).filter(Boolean);
  const jdup=jp.filter((x,i)=>jp.indexOf(x)!==i);
  console.log('day '+String(day).padStart(2)+': served '+String(served.length).padStart(3)+
    ' | done '+String(d.done.length).padStart(3)+' | held '+String(d.buried.length).padStart(3)+
    ' | same word finished twice: '+dup.length+' | same Japanese seen twice in the day: '+new Set(jdup).size);
  await p.evaluate(()=>{const o=parseInt(localStorage.getItem('__tOffset')||'0',10)||0;
    localStorage.setItem('__tOffset',String(o+86400000));});
  await p.reload(); await p.waitForTimeout(700);
}
console.log('\nadjacent identical cards across 12 days:', adjacent);
console.log('total same-word-twice-in-a-day:', totalDup);
if(worstDay) console.log('first offending day:', JSON.stringify(worstDay,null,1));
await b.close();})();
