const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852},deviceScaleFactor:2});
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(2000);
console.log('sw:',await p.evaluate(()=>navigator.serviceWorker.getRegistration().then(r=>!!r)));
async function run(n,sel){for(let i=0;i<n;i++){ if(await p.$('#s-review.on')===null) break;
  const s=await p.$('#showBtn'); if(s&&await s.isVisible()){await s.click();await p.waitForTimeout(25);}
  const g=await p.$(sel); if(g&&await g.isVisible()){await g.click();await p.waitForTimeout(25);} }}
await p.click('#startBtn'); await run(40,'.grade.g2');
const q=await p.$('#quitBtn'); if(q&&await q.isVisible()) await q.click();
await p.waitForTimeout(400);
await ctx.setOffline(true); await p.reload(); await p.waitForTimeout(1600);
console.log('offline home:',JSON.stringify(await p.evaluate(()=>({lvl:document.getElementById('lvlN').textContent,score:document.getElementById('lvlScore').textContent,btn:document.getElementById('startBtn').textContent}))));
for(const t of ['browse','stats','set']){ await p.click('.tab[data-go="'+t+'"]'); await p.waitForTimeout(400); }
console.log('stats offline:',JSON.stringify(await p.evaluate(()=>({cells:document.querySelectorAll('#heat .cell').length,lvl:document.getElementById('pLvlBig').textContent}))));
console.log('soft toggle:',await p.evaluate(()=>!!document.getElementById('setSoft')));
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400); await p.screenshot({path:'v3-home.png'});
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
