const {chromium}=require('playwright');
const legacy = {
  rev: 42,
  settings:{newPerDay:12,revCap:150,reverse:"grad",typing:false,kanji:true,tts:true,theme:"auto"},
  daily:{key:"2026-09-04",newDone:9,revDone:31,ans:60,ok:55},
  hist:{"2026-09-03":40,"2026-09-04":60},
  streak:{cur:2,best:2,last:"2026-09-04"},
  life:{ans:100,ok:92},
  items:{
    "c0000|j":[1,0,3,2.5,12,Date.now()-86400000,0,0,4,4],
    "c0000|e":[1,0,2,2.36,6,Date.now()+3*86400000,1,12,3,2],
    "c0005|j":[0,1,0,2.5,0,Date.now()-60000,0,0,1,1],
    "c0009|j":[1,0,5,2.7,40,Date.now()+20*86400000,0,0,6,6],
    "c0020|j":[1,0,4,2.6,25,Date.now()+5*86400000,0,0,5,5]
  }
};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
// seed localStorage BEFORE the app's script runs, exactly as an existing install would look
await ctx.addInitScript(o=>{ try{ if(!localStorage.getItem('kanaladder.v1')) localStorage.setItem('kanaladder.v1',JSON.stringify(o)); }catch(e){} }, legacy);
const p=await ctx.newPage(); const errs=[];
p.on('pageerror',e=>errs.push('PAGEERROR: '+e.message));
p.on('console',m=>{if(m.type()==='error')errs.push('console: '+m.text());});
await p.goto('http://localhost:8099/index.html'); await p.waitForTimeout(1600);
console.log('legacy save opened in the new build:');
console.log(JSON.stringify(await p.evaluate(()=>{
  const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {items:Object.keys(d.items).length, streak:d.streak.cur, lifeAns:d.life.ans, lifeOk:d.life.ok,
    hist:Object.keys(d.hist).length, revCap:d.settings.revCap,
    newSettings:{softCap:d.settings.softCap,separate:d.settings.separate},
    newDaily:{credit:d.daily.credit,buried:typeof d.daily.buried,done:typeof d.daily.done},
    backup:JSON.stringify(d.backup),
    lvl:document.getElementById('lvlN').textContent, score:document.getElementById('lvlScore').textContent,
    tiles:[document.querySelector('#tileNew .n').textContent,document.querySelector('#tileLrn .n').textContent,document.querySelector('#tileDue .n').textContent],
    progress:document.getElementById('progAux').textContent};}),null,1));
await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(700);
console.log('stats:',await p.evaluate(()=>document.querySelectorAll('#heat .cell').length+' cells | rotation '+document.getElementById('nRot').textContent+' | lifetime answers '+document.getElementById('nAns').textContent));
await p.click('.tab[data-go="home"]'); await p.waitForTimeout(400);
await p.click('#startBtn'); await p.waitForTimeout(600);
console.log('review opens:',await p.evaluate(()=>document.querySelector('.screen.on').id));
// answer one, confirm the legacy item is updated not replaced
const s=await p.$('#showBtn'); if(s) await s.click(); await p.waitForTimeout(200);
const g=await p.$('.grade.g2'); if(g) await g.click(); await p.waitForTimeout(400);
console.log('after one answer:',JSON.stringify(await p.evaluate(()=>{const d=JSON.parse(localStorage.getItem('kanaladder.v1'));
  return {items:Object.keys(d.items).length, lifeAns:d.life.ans, streak:d.streak.cur};})));
// and check IndexedDB got the migrated copy
console.log('idb items:',await p.evaluate(()=>new Promise(res=>{const r=indexedDB.open('kanaladder',1);
  r.onsuccess=()=>{const q=r.result.transaction('kv','readonly').objectStore('kv').get('state');
    q.onsuccess=()=>res(q.result?Object.keys(q.result.items).length:'none');q.onerror=()=>res('err');};r.onerror=()=>res('err');})));
await b.close(); console.log(errs.length?'ERRORS:\n'+errs.join('\n'):'no errors');})();
