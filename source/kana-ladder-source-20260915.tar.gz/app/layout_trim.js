/* The Study page keeps its controls; the streak moves to Progress. */
const {chromium}=require('playwright'); const fs=require('fs');
let fails=0,n=0;
const ok=(c,m)=>{n++; if(!c){fails++;console.log("  FAIL  "+m);} else console.log("  ok    "+m);};
(async()=>{
const b=await chromium.launch({executablePath:'/opt/pw-browsers/chromium'});
const ctx=await b.newContext({viewport:{width:393,height:852}});
await ctx.addInitScript(raw=>{try{localStorage.setItem('kanaladder.v1',raw);}catch(e){}},
  fs.readFileSync('/tmp/bk2.json','utf8'));
const p=await ctx.newPage(); const errs=[]; p.on('pageerror',e=>errs.push(String(e)));
await p.goto('http://127.0.0.1:8100/index.html',{timeout:15000});
await p.waitForFunction(()=>window.__kl&&window.__kl.DECK.length>0,null,{timeout:15000});
await p.waitForTimeout(1200);

const home=await p.evaluate(()=>{
  const on=document.getElementById('s-home');
  const vis=id=>{const e=document.getElementById(id); return !!(e && on.contains(e));};
  return {
    streakOnHome: vis('streakChart'),
    progNote: !!document.getElementById('progNote'),
    practicePara: /sweeps everything you have met/.test(on.textContent),
    startBtn: vis('startBtn'), aheadBtn: vis('aheadBtn'),
    focusBtn: vis('focusBtn'), carBtn: vis('carBtn'), noNew: vis('noNewSw'),
    rail: vis('rail'), tiles: vis('tileDue'),
    height: on.scrollHeight
  };
});
ok(home.streakOnHome===false,'the streak block is off the Study page');
ok(home.progNote===false,'the "counts below are cards" paragraph is gone');
ok(home.practicePara===false,'the Regular / Focus paragraph is gone');
ok(home.startBtn && home.aheadBtn,'Start review and Study ahead still there');
ok(home.focusBtn && home.carBtn,'the Practice and Car buttons are still there');
ok(home.noNew,'"No new words today" still there');
ok(home.rail && home.tiles,'Deck progress bar and the three tiles still there');
console.log("  Study page height now: "+home.height+"px");

await p.click('.tab[data-go="stats"]'); await p.waitForTimeout(600);
const stats=await p.evaluate(()=>{
  const on=document.getElementById('s-stats');
  const el=document.getElementById('streakChart');
  return {
    here: !!(el && on.contains(el)),
    bars: el ? el.querySelectorAll('rect,path,line').length : 0,
    aux: (document.getElementById('streakAux')||{}).textContent||''
  };
});
ok(stats.here,'the streak now lives on the Progress tab');
ok(stats.bars>0,'its chart actually draws there ('+stats.bars+' marks)');
ok(/day/.test(stats.aux),'the streak count draws with it ("'+stats.aux.trim()+'")');
ok(errs.length===0,'no uncaught page errors'+(errs.length?': '+errs[0]:''));
await b.close();
console.log(fails? "\n"+fails+" FAILURES of "+n : "\nSTUDY PAGE TRIMMED, NOTHING LOST ("+n+" checks)");
process.exit(fails?1:0);
})();
