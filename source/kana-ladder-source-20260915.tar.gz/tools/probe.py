# -*- coding: utf-8 -*-
"""Probe: given candidate sentences, report which deck cards link and which gaps form.
Uses the exact logic of link_sentences.py so authoring can be verified before merge."""
import json, os, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT,'tools'))
import link_sentences as L

DECK=L.DECK; FORMS=L.FORMS
IDX={c['id']:c for c in DECK}
cards=sorted(DECK, key=lambda c:-len(c['romaji']))
seen={}
for c in DECK: seen.setdefault(c['kana'],[]).append(c['id'])
AMBIG={i for v in seen.values() if len(v)>1 for i in v}
# introduction position
for i,c in enumerate(DECK): c['_i']=i
intro=sorted(DECK, key=lambda c: c['ord'] if isinstance(c.get('ord'),(int,float)) else c['_i'])
POS={c['id']:p for p,c in enumerate(intro)}

def analyse(kana, romaji):
    spans=L.token_spans(romaji); st=[t for t,_ in spans]
    pos=L.align(kana, romaji)
    w=[]; g={}
    for c in cards:
        if c.get('dup'): continue
        allow_alt=L.is_particle(c)
        cands=[L.toks(c['romaji'])]
        row=FORMS.get(c['id'])
        if row:
            for k in range(2,len(row),3): cands.append(L.toks(row[k]))
        hits=[]; via_dict=False
        for ci,cand in enumerate(cands):
            if not cand: continue
            for i in range(len(st)-len(cand)+1):
                if all(L.eq_tok(st[i+j],cand[j],allow_alt) for j in range(len(cand))):
                    hits.append((i,cand))
            if hits: via_dict=(ci==0); break
        if not hits: continue
        if not allow_alt and via_dict and c['kana'] not in kana: continue
        w.append(c['id'])
        if pos is None or len(hits)!=1: continue
        i,cand=hits[0]; start=spans[i][1]
        if start>=len(pos): continue
        at=pos[start]
        if kana[at:at+len(c['kana'])]!=c['kana']: continue
        if kana.count(c['kana'])!=1: continue
        if c['id'] in AMBIG: continue
        g[c['id']]=at
    # which romaji tokens are covered by at least one linked card
    covered=[False]*len(st)
    for c in cards:
        if c['id'] not in w: continue
        allow_alt=L.is_particle(c)
        cands=[L.toks(c['romaji'])]
        row=FORMS.get(c['id'])
        if row:
            for k in range(2,len(row),3): cands.append(L.toks(row[k]))
        for cand in cands:
            if not cand: continue
            for i in range(len(st)-len(cand)+1):
                if all(L.eq_tok(st[i+j],cand[j],allow_alt) for j in range(len(cand))):
                    for j in range(len(cand)): covered[i+j]=True
    orphan=[st[i] for i in range(len(st)) if not covered[i]]
    return pos is not None, w, g, orphan

if __name__=='__main__':
    rows=json.load(open(sys.argv[1],encoding='utf-8'))
    bad=0
    for x in rows:
        ok,w,g,orphan=analyse(x['kana'],x['romaji'])
        tgt=x.get('target')
        mark=''
        if not ok: mark+=' UNALIGNED'; bad+=1
        if tgt and tgt not in w: mark+=' TARGET-NOT-LINKED'; bad+=1
        ps=sorted((POS.get(i,99999) for i in w), reverse=True)
        opens=ps[1] if len(ps)>1 else (ps[0] if ps else 0)
        if opens>=804: mark+=' OPENS-OUTSIDE-WINDOW(%d)'%opens; bad+=1
        far=[i for i in w if i!=tgt and POS.get(i,0)>POS.get(tgt,0)]
        if len(far)>1:
            mark+=' late(%d)'%len(far)
        if orphan: mark+=' ORPHAN:'+','.join(orphan); bad+=1
        print("%-30s %-36s tgt=%s gap=%s opens@%d%s"%(x['kana'],x['romaji'],tgt,'Y' if tgt in g else 'n',opens,mark))
        if mark: print("     w:", ",".join("%s:%s@%d"%(i,IDX[i]['romaji'],POS.get(i,-1)) for i in w))
    print("issues:",bad)
