# -*- coding: utf-8 -*-
"""Build the scheduled conjugation anchor cards.

One card per rule, taught through a fixed exemplar the learner already knows.
The point is the rule, so the set is deliberately small: the full 427-word
conjugation set lives in the practice drill, which costs no review time.
"""
import os as _os
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
def R(*p): return _os.path.join(ROOT, *p)
import json, sys
sys.path.insert(0, R('tools'))
from verbclass import classify
from conjugate import verb_forms, adj_forms

DECK = json.load(open(R('deck', 'deck_full.json'), encoding='utf-8'))
BY = {c['id']: c for c in DECK}

FORM_EN = {'masu':'polite present', 'mashita':'polite past',
           'masen':'polite negative', 'te':'te-form'}
FORM_USE = {'masu':'what you will hear at a counter or station',
            'mashita':'reporting something already done',
            'masen':'saying you do not or will not',
            'te':'joins clauses, and makes requests with kudasai'}

RULES = {
 ('godan','masu'):    'godan: the final -u sound becomes -i, then add masu',
 ('ichidan','masu'):  'ichidan: drop ru, then add masu',
 ('irregular','masu'):'irregular: learn it as it is',
 ('godan','mashita'): 'same stem as masu, ending in mashita',
 ('ichidan','mashita'):'drop ru, then add mashita',
 ('irregular','mashita'):'irregular: learn it as it is',
 ('godan','masen'):   'same stem as masu, ending in masen',
 ('ichidan','masen'): 'drop ru, then add masen',
 ('irregular','masen'):'irregular: learn it as it is',
}
TE_RULE = {
 'う':'godan te-form: verbs ending u, tsu or ru take tte',
 'つ':'godan te-form: verbs ending u, tsu or ru take tte',
 'る':'godan te-form: verbs ending u, tsu or ru take tte',
 'む':'godan te-form: verbs ending mu, bu or nu take nde',
 'ぶ':'godan te-form: verbs ending mu, bu or nu take nde',
 'ぬ':'godan te-form: verbs ending mu, bu or nu take nde',
 'く':'godan te-form: verbs ending ku take ite',
 'ぐ':'godan te-form: verbs ending gu take ide',
 'す':'godan te-form: verbs ending su take shite',
}

# exemplar, form  -> one anchor card each
PLAN = [
 # polite present, one per rule plus the godan verb that looks ichidan
 ('c0115','masu'), ('c0116','masu'), ('c0184','masu'), ('c0181','masu'),
 ('c0114','masu'), ('c0182','masu'), ('c0178','masu'), ('c0179','masu'),
 # polite past
 ('c0115','mashita'), ('c0187','mashita'), ('c0114','mashita'),
 ('c0178','mashita'), ('c0179','mashita'),
 # polite negative
 ('c0186','masen'), ('c0562','masen'), ('c0182','masen'),
 ('c0178','masen'), ('c0179','masen'),
 # te-form, one card per sub-rule, plus the single exception
 ('c0116','te'), ('c0562','te'), ('c0115','te'), ('c0836','te'),
 ('c0183','te'), ('c0180','te'), ('c0828','te'), ('c0184','te'),
 ('c0114','te'), ('c0182','te'), ('c0178','te'), ('c0179','te'),
]
ADJ_PLAN = [
 ('c0145','past'), ('c0145','neg'),          # takai, an i-adjective
 ('c0113','neg'),                            # oishii
 ('c0193','past'), ('c0193','neg'),          # ii, the irregular one
 ('c0206','past'), ('c0206','neg'),          # shizuka, a na-adjective
 ('c0208','past'),
]
ADJ_FORM_EN = {'past':'past', 'neg':'negative', 'te':'te-form'}
ADJ_RULE = {
 ('adj-i','past'):'i-adjective: drop the final i, add katta',
 ('adj-i','neg'): 'i-adjective: drop the final i, add kunai',
 ('adj-na','past'):'na-adjective: add deshita',
 ('adj-na','neg'): 'na-adjective: add janai',
}

def build():
    out = []
    n = 0
    for cid, form in PLAN:
        c = BY[cid]; cls = classify(c)
        f = verb_forms(c['kana'], c['romaji'], cls)
        assert f, cid
        kk, rr = f[form]
        if form == 'te':
            if cls == 'godan':      rule = TE_RULE[c['kana'][-1]]
            elif cls == 'ichidan':  rule = 'ichidan te-form: drop ru, add te'
            else:                   rule = 'irregular: learn it as it is'
        else:
            rule = RULES[(cls, form)]
        if c['kana'] == 'いく' and form == 'te':
            rule = 'the one exception: iku ends in ku but takes tte, not ite'
        n += 1
        out.append({'id':'g%03d' % n, 'kana':kk, 'romaji':rr,
                    'en':c['en'].split(' / ')[0].replace('to ','') + ', ' + FORM_EN[form],
                    'base':c['kana'], 'baseRomaji':c['romaji'], 'baseEn':c['en'],
                    'form':form, 'formEn':FORM_EN[form], 'use':FORM_USE[form],
                    'cls':cls, 'rule':rule, 'w':[cid],
                    'pos':'conjugation', 'tags':['conjugation', cls, form]})
    for cid, form in ADJ_PLAN:
        c = BY[cid]
        f = adj_forms(c['kana'], c['romaji'], c['pos'])
        assert f, cid
        kk, rr = f[form]
        rule = 'ii is irregular: every form is built on yo-' if c['kana'] == 'いい' \
               else ADJ_RULE[(c['pos'], form)]
        n += 1
        out.append({'id':'g%03d' % n, 'kana':kk, 'romaji':rr,
                    'en':c['en'].split(';')[0].split(' / ')[0] + ', ' + ADJ_FORM_EN[form],
                    'base':c['kana'], 'baseRomaji':c['romaji'], 'baseEn':c['en'],
                    'form':form, 'formEn':ADJ_FORM_EN[form],
                    'use':'describing how something was, or was not',
                    'cls':c['pos'], 'rule':rule, 'w':[cid],
                    'pos':'conjugation', 'tags':['conjugation', c['pos'], form]})
    return out

if __name__ == '__main__':
    a = build()
    json.dump(a, open(R('conj', 'anchors.json'),'w'), ensure_ascii=False)
    print('anchors:', len(a))
