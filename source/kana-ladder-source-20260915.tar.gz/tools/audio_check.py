"""Audio quality gate.

The yon defect shipped because nothing ever looked at what was inside a clip.
car_audio.js proves a clip exists, downloads and plays; it cannot tell a clear
word from a swallowed one, and neither can I by ear. So this measures every
Japanese clip we ship and reports the ones that carry too little audible
speech for the number of morae they are supposed to contain.

Run after tools/voice.py. Exits non-zero if anything falls under the floor.
"""
import json, os, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import voice as V

# Audible seconds per mora falls naturally with length, because a long clip
# carries more unvoiced consonants and internal pauses per mora than a short
# one. So the floor is applied only to the short clips the redraw ladder
# covers, where it means something; longer clips are measured and listed but
# not gated.
FLOOR = 0.090      # seconds of audible speech per mora, below which a word is swallowed
WARN  = 0.110      # worth looking at
SHOW  = 15
# Some words are legitimately quiet: hitotsu, futatsu and supootsu are built on
# tsu and su, which carry almost no voiced energy however slowly they are said.
# The renderer's ladder has already slowed those clips right down, so a long
# clip that still measures quiet is the voice's limit, not a swallowed word.
# Only a clip that is quiet AND short is a real failure, which is what the
# broken yon was: 0.28 s of clip per mora against these at 0.6 and above.
MAX_SEC_PER_MORA = 0.50

def decode(mp3_bytes):
    p = subprocess.run(['ffmpeg', '-loglevel', 'error', '-i', 'pipe:0',
                        '-f', 's16le', '-ac', '1', '-ar', '22050', 'pipe:1'],
                       input=mp3_bytes, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    return p.stdout

def main():
    man = json.load(open(os.path.join(V.OUT, 'manifest.json'), encoding='utf-8'))
    groups = V.plan()
    text = {k: (l, t) for items in groups.values() for k, l, t in items}
    rows = []
    for sprite, base in sorted(man['files'].items()):
        idx = json.load(open(os.path.join(V.OUT, base + '.json'), encoding='utf-8'))
        blob = open(os.path.join(V.OUT, base + '.mp3'), 'rb').read()
        for key, (off, ln) in idx.items():
            lang, t = text.get(key, (None, None))
            if lang != 'ja':
                continue
            m = V.morae(t)
            if not m:
                continue
            v = V.voiced(decode(blob[off:off+ln]), 22050)
            rows.append((v / m, v, m, key, t, V.laddered(lang, t), ln * 8.0 / 32000 / m))
        print('  %s checked' % sprite, flush=True)
    rows.sort()
    gated = [r for r in rows if r[5]]
    bad = [r for r in gated if r[0] < FLOOR and r[6] < MAX_SEC_PER_MORA]
    quiet = [r for r in gated if r[0] < FLOOR and r[6] >= MAX_SEC_PER_MORA]
    warn = [r for r in gated if FLOOR <= r[0] < WARN]
    print('\n%d Japanese clips measured, %d of them short enough to gate'
          % (len(rows), len(gated)))
    print('worst %d short clips by audible speech per mora:' % SHOW)
    for r in gated[:SHOW]:
        print('   %.3f s/mora  %5.2f s  %d morae  %4.2f s clip/mora  %-22s %s' % (r[0], r[1], r[2], r[6], r[3], r[4]))
    print('median %.3f s/mora over the gated set, %.3f over everything'
          % (gated[len(gated)//2][0], rows[len(rows)//2][0]))
    print('%d under the %.3f floor, %d between floor and %.3f'
          % (len(bad), FLOOR, len(warn), WARN))
    print('%d quiet but already drawn out, accepted: %s'
          % (len(quiet), ', '.join(r[4] for r in quiet) or 'none'))
    for r in bad:
        print('   FAIL %.3f s/mora  %4.2f s clip/mora  %-22s %s'
              % (r[0], r[6], r[3], r[4]))
    return 1 if bad else 0

if __name__ == '__main__':
    sys.exit(main())
