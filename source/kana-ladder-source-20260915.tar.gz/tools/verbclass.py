# -*- coding: utf-8 -*-
"""Conjugation class for every verb in the deck.

Precedence, highest first:
  1. a class already tagged on the card (curated, and verified against the
     kanji: 居る ichidan, 要る godan, 帰る godan, 変える ichidan, and so on)
  2. an explicit per-id table for the -iru / -eru verbs, whose class cannot be
     derived from spelling: 切る kiru "cut" is godan, 着る kiru "wear" is
     ichidan, and they are written identically in kana
  3. suru compounds, which are irregular
  4. the spelling rule, safe for every remaining shape
Anything that falls through is returned as None so the build fails loudly
rather than shipping a wrong verb form.
"""
IE = 'いえきけしせちてにねひへみめりれぇぎげじぜびべぢで'

# The -iru/-eru verbs that carry no tag in the deck, resolved one by one.
# Only three of the fifty-four are godan; the kanji is given for the record.
AMBIG = {
 'c0920':'godan',    # 切る   kiru        to cut            -> kirimasu, kitte
 'c1068':'godan',    # 減る   heru        to decrease       -> herimasu, hette
 'c1506':'godan',    # 握る   nigiru      to grip           -> nigirimasu, nigitte
 'c0114':'ichidan',  # 食べる taberu      to eat
 'c0499':'ichidan',  # 着る   kiru        to wear
 'c0731':'ichidan',  # 疲れる tsukareru   to get tired
 'c0997':'ichidan',  # 茹でる yuderu      to boil
 'c0998':'ichidan',  # 炒める itameru     to stir-fry
 'c1040':'ichidan',  # 比べる kuraberu    to compare
 'c1041':'ichidan',  # 集める atsumeru    to gather
 'c1043':'ichidan',  # 慣れる nareru      to get used to
 'c1044':'ichidan',  # 諦める akirameru   to give up
 'c1058':'ichidan',  # 止める tomeru      to stop something
 'c1060':'ichidan',  # 辞める yameru      to quit
 'c1064':'ichidan',  # 分ける wakeru      to divide
 'c1065':'ichidan',  # 別れる wakareru    to part
 'c1066':'ichidan',  # 増える fueru       to increase
 'c1075':'ichidan',  # 訪ねる tazuneru    to visit
 'c1079':'ichidan',  # 褒める homeru      to praise
 'c1083':'ichidan',  # 信じる shinjiru    to believe
 'c1089':'ichidan',  # 投げる nageru      to throw
 'c1090':'ichidan',  # 捕まえる tsukamaeru to catch
 'c1091':'ichidan',  # 落ちる ochiru      to fall
 'c1096':'ichidan',  # 掛ける kakeru      to hang
 'c1099':'ichidan',  # 煮る   niru        to simmer
 'c1100':'ichidan',  # 焼ける yakeru      to be grilled
 'c1102':'ichidan',  # 溶ける tokeru      to melt
 'c1103':'ichidan',  # 燃える moeru       to burn
 'c1105':'ichidan',  # 調べる shiraberu   to look up
 'c1106':'ichidan',  # 捨てる suteru      to throw away
 'c1109':'ichidan',  # 届ける todokeru    to deliver
 'c1133':'ichidan',  # 濡れる nureru      to get wet
 'c1256':'ichidan',  # 乗り換える norikaeru to change trains
 'c1278':'ichidan',  # 混ぜる mazeru      to mix
 'c1280':'ichidan',  # 温める atatameru   to warm up
 'c1302':'ichidan',  # 並べる naraberu    to line up
 'c1304':'ichidan',  # 汚れる yogoreru    to get dirty
 'c1313':'ichidan',  # 植える ueru        to plant
 'c1316':'ichidan',  # 着替える kigaeru   to change clothes
 'c1333':'ichidan',  # 負ける makeru      to lose
 'c1391':'ichidan',  # 過ぎる sugiru      to be excessive
 'c1399':'ichidan',  # し始める shihajimeru to begin doing
 'c1401':'ichidan',  # し続ける shitsuzukeru to keep doing
 'c1433':'ichidan',  # 多すぎる oosugiru  too many
 'c1475':'ichidan',  # 確かめる tashikameru to confirm
 'c1476':'ichidan',  # まとめる matomeru  to summarise
 'c1478':'ichidan',  # 任せる makaseru    to entrust
 'c1486':'ichidan',  # 認める mitomeru    to recognise
 'c1491':'ichidan',  # 避ける sakeru      to avoid
 'c1493':'ichidan',  # 受け入れる ukeireru to accept
 'c1495':'ichidan',  # 訪れる otozureru   to visit
 'c1515':'ichidan',  # 凍らせる kooraseru to freeze something
 'c1641':'ichidan',  # 焦げる kogeru      to get scorched
 'c1662':'ichidan',  # 組み立てる kumitateru to assemble
}
CLASSES = ('godan','ichidan','irregular')

def classify(card):
    tags = set(card.get('tags') or [])
    for c in CLASSES:
        if c in tags: return c
    if card['id'] in AMBIG: return AMBIG[card['id']]
    k = card['kana']
    if k == 'する' or k.endswith('する'): return 'irregular'
    if k == 'くる' or k.endswith('てくる'): return 'irregular'
    if k.endswith('る') and len(k) > 1 and k[-2] in IE: return None   # unresolved
    if k and k[-1] in 'うくぐすつぬぶむる': return 'godan'
    return None
