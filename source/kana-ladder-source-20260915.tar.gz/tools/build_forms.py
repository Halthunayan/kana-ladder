# -*- coding: utf-8 -*-
"""Precompute every conjugated form once, in Python, so the app never has to
re-implement the rules in JavaScript and the two can never drift apart.

Each row is a flat list of (form name, kana, romaji) triples. The name is
carried in the data because the app used to infer the set of forms from the
row length, which stopped being unique the moment two different form sets had
the same number of entries."""
import os as _os
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
def R(*p): return _os.path.join(ROOT, *p)
import json, sys
sys.path.insert(0,R('tools'))
from verbclass import classify
from conjugate import verb_forms, adj_forms
import kana as K

NO_CONJ = {'c0285'}                      # donna, a pre-noun form, does not inflate
# Verbs with no potential: already potential or spontaneous in meaning, or the
# intransitive half of a pair whose potential collides with the transitive.
NO_POTENTIAL = {
 # already potential, or spontaneous, so a potential is not a Japanese word
 'dekiru','mieru','kikoeru','wakaru','aru','iru',
 # intransitive, where the potential either does not exist or collides with the
 # transitive twin's polite present
 'kowareru','fueru','heru','tokeru','kooru','moeru','yakeru','hareru','furu',
 'aku','shimaru','mitsukaru','kakaru','todoku','tsuzuku','waku','wakareru',
 'kimaru','hajimaru','owaru','nokoru','kawaru','tsuku','ochiru','kieru',
 'tomaru','atsumaru','naoru','umareru','tsukareru','niau','sugiru'}
VERB_ORDER = ['masu','mashita','masen','masendeshita','potential','te','tai']
ADJ_ORDER  = ['past','politepast','neg','te']
LABEL = {'masu':'polite present','mashita':'polite past','masen':'polite negative',
         'masendeshita':'polite past negative','potential':'can do it form','te':'te-form',
         'tai':'want to do it form','past':'past',
         'politepast':'polite past','neg':'negative'}
# The tai form says the speaker wants to do something, so it needs a verb whose
# action the speaker can choose to perform. That is not the same test as the
# potential: half of NO_POTENTIAL is there because the potential collides with a
# transitive twin's polite present, which has nothing to do with agency. So the
# list is its own, and it differs in both directions. Verbs like tsuku (arrive),
# naoru (recover), owaru (end) and wakareru (part) have no potential but are
# things a person can want. Verbs like odoroku (be surprised), komaru (be
# troubled), kizuku (notice), nureru (get wet) and chirakaru (get messy) happen
# to you rather than by you. shinu is excluded on its own account: a solo
# learner should not be handed "I want to die" as a drill card.
NO_TAI = (NO_POTENTIAL - {'tsuku','naoru','owaru','wakareru'}) | {
 'odoroku','komaru','kizuku','nureru','chirakaru','shinu'}

def main():
    deck = json.load(open(R('deck', 'deck_full.json'), encoding='utf-8'))
    out, bad = {}, []
    for c in deck:
        if c['id'] in NO_CONJ: continue
        if c['pos'] == 'verb':
            f = verb_forms(c['kana'], c['romaji'], classify(c)); order = VERB_ORDER
        elif c['pos'] in ('adj-i','adj-na'):
            f = adj_forms(c['kana'], c['romaji'], c['pos']); order = ADJ_ORDER
        else: continue
        if not f: bad.append(c['id']); continue
        row = []
        if c['romaji'] in NO_POTENTIAL: f.pop('potential', None)
        if c['romaji'] in NO_TAI: f.pop('tai', None)
        for name in [n for n in order if n in f]:
            kk, rr = f[name]
            st, why = K.check(kk, rr)
            if st != 'OK': bad.append((c['id'], name, kk, rr, why)); continue
            row += [name, kk, rr]
        out[c['id']] = row
    assert not bad, bad[:10]
    json.dump(out, open(R('conj', 'forms.json'),'w'), ensure_ascii=False,
              separators=(',',':'))
    print('words with forms:', len(out))

if __name__ == '__main__': main()
