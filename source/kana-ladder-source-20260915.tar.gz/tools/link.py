# -*- coding: utf-8 -*-
"""Link a sentence to the deck words it contains.

Longest match first, left to right, with no overlaps, so that a longer word
always wins over a shorter one inside it. Conjugated verbs and adjectives are
matched through their generated forms rather than by substring, because
tabemasu does not contain taberu.
"""
import json, sys, os
HERE = os.path.dirname(os.path.abspath(__file__))

def build_index(deck, forms):
    """surface form -> word id, longest surface first"""
    idx = {}
    for c in deck:
        idx.setdefault(c['kana'], []).append(c['id'])
    for wid, row in (forms or {}).items():
        for i in range(0, len(row), 2):
            idx.setdefault(row[i], []).append(wid)
    return idx

def link(kana, idx, prefer=None, min_len=2):
    """Left to right, longest match at each position.

    Scanning left to right matters: a purely global longest-first pass matches
    tsukaimasu across the boundary of mittsu + kaimasu and links the wrong verb.
    Surfaces of one kana are skipped, because ha (tooth) and su (vinegar) are
    written exactly like the topic particle and the tail of desu, and a false
    link would lock the sentence forever under the all-words-known rule.
    """
    lens = sorted({len(k) for k in idx if len(k) >= min_len}, reverse=True)
    n = len(kana)
    out, seen = [], set()
    i = 0
    while i < n:
        hit = None
        for L in lens:
            if i + L > n: continue
            k = kana[i:i+L]
            if k in idx: hit = (k, L); break
        if not hit:
            i += 1
            continue
        k, L = hit
        ids = idx[k]
        pick = None
        if prefer:
            for cand in ids:
                if cand in prefer: pick = cand; break
        wid = pick or ids[0]
        if wid not in seen: seen.add(wid); out.append(wid)
        i += L
    return out
