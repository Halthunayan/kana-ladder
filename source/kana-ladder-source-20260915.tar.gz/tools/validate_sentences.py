# -*- coding: utf-8 -*-
"""Validate a batch of replacement sentences before it is allowed near the deck."""
import json, os, re, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT,'tools'))
import kana as K

DECK={x['id']:x for x in json.load(open(os.path.join(ROOT,'deck','deck_full.json'),encoding='utf-8'))}
OLD=json.load(open(os.path.join(ROOT,'sentences','sent_full.json'),encoding='utf-8'))
FORMS=json.load(open(os.path.join(ROOT,'conj','forms.json'),encoding='utf-8'))

def surfaces(wid):
    """Every kana surface a card can legitimately show: its dictionary form and
    every generated inflection. The linker matches inflected forms, so a batch
    that links a verb through masu-form is correct and must validate."""
    out={DECK[wid]['kana']}
    row=FORMS.get(wid)
    if row:
        for k in range(1,len(row),3): out.add(row[k])
    return out
OLDKANA={x['kana'] for x in OLD if x['id'][0]=='s'}
KANA_RX=re.compile(r'^[぀-ゟ゠-ヿー、。？！　]+$')
GRAMMAR={'question','past','negation','te-form','request','want','can','must','invitation',
 'permission','reason','comparison','existence','location','time','counter','copula','adjective',
 'adverb','conjunction','giving','plain','reply','polite-past-negative','ongoing','suggestion'}

def validate(path):
    rows=json.load(open(path,encoding='utf-8'))
    errs=[]; seen=set()
    for i,x in enumerate(rows):
        tag="%s[%d]"%(os.path.basename(path),i)
        for k in ('id','kana','romaji','en','level','grammar','w'):
            if k not in x: errs.append("%s missing field %s"%(tag,k)); break
        else:
            if not KANA_RX.match(x['kana']): errs.append("%s non-kana face: %s"%(tag,x['kana']))
            st,got=K.check_sentence(x['kana'], x['romaji'])
            if st!='OK': errs.append("%s romaji does not match kana: %s / %s"%(tag,x['kana'],x['romaji']))
            if x['kana'] in seen or x['kana'] in OLDKANA: errs.append("%s duplicate sentence: %s"%(tag,x['kana']))
            seen.add(x['kana'])
            if not x['w']: errs.append("%s links no word"%tag)
            for w in x['w']:
                if w not in DECK: errs.append("%s links missing word %s"%(tag,w))
                elif not any(f in x['kana'] for f in surfaces(w)):
                    errs.append("%s claims %s (%s) but it is not in the sentence"%(tag,w,DECK[w]['kana']))
            e=x['en'].strip()
            if not e or e[0].islower(): errs.append("%s English does not start with a capital: %r"%(tag,e))
            if not e.endswith(('.','?','!')): errs.append("%s English has no final stop: %r"%(tag,e))
            if re.search(r'\bthe the\b|\ba the\b|\bis important\.$', e): errs.append("%s bad English: %r"%(tag,e))
            if x['grammar'] not in GRAMMAR: errs.append("%s unknown grammar tag %s"%(tag,x['grammar']))
            if not isinstance(x['level'],int) or not 1<=x['level']<=5: errs.append("%s bad level"%tag)
            if len(x['kana'])>30: errs.append("%s too long (%d kana)"%(tag,len(x['kana'])))
    return rows, errs

if __name__=='__main__':
    total=0; bad=0
    for p in sys.argv[1:]:
        rows,errs=validate(p)
        total+=len(rows); bad+=len(errs)
        print("%-40s %4d sentences, %d errors"%(os.path.basename(p), len(rows), len(errs)))
        for e in errs[:25]: print("    "+e)
    print("TOTAL %d sentences, %d errors"%(total,bad))
    sys.exit(1 if bad else 0)
