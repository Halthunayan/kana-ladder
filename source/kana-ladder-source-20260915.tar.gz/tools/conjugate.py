# -*- coding: utf-8 -*-
"""Generate polite, te and tai forms for verbs, and past / negative forms for
adjectives. Every rule is written out rather than table-driven so it can be
read and checked by eye."""
I_ROW = {'う':'い','く':'き','ぐ':'ぎ','す':'し','つ':'ち','ぬ':'に','ぶ':'び','む':'み','る':'り'}
TE_G  = {'う':'って','つ':'って','る':'って','む':'んで','ぶ':'んで','ぬ':'んで',
         'く':'いて','ぐ':'いで','す':'して'}
ROM_I = {'う':'i','く':'ki','ぐ':'gi','す':'shi','つ':'chi','ぬ':'ni','ぶ':'bi','む':'mi','る':'ri'}
ROM_TE= {'う':'tte','つ':'tte','る':'tte','む':'nde','ぶ':'nde','ぬ':'nde',
         'く':'ite','ぐ':'ide','す':'shite'}
# the potential: a godan verb shifts its final sound to the e row, then takes masu
E_ROW = {'う':'え','く':'け','ぐ':'げ','す':'せ','つ':'て','ぬ':'ね','ぶ':'べ','む':'め','る':'れ'}
ROM_E = {'う':'e','く':'ke','ぐ':'ge','す':'se','つ':'te','ぬ':'ne','ぶ':'be','む':'me','る':'re'}
# the only verb whose te-form breaks its own class rule
IKU = {'いく','はいっていく','でていく'}

def _rom_stem(romaji, kana):
    """romaji of the dictionary form minus its final syllable"""
    last = kana[-1]
    syll = {'う':'u','く':'ku','ぐ':'gu','す':'su','つ':'tsu','ぬ':'nu',
            'ぶ':'bu','む':'mu','る':'ru'}[last]
    assert romaji.endswith(syll), (romaji, syll)
    return romaji[:-len(syll)]

def verb_forms(kana, romaji, cls):
    """returns {form: (kana, romaji)} or None when the class is unknown"""
    if cls == 'irregular':
        if kana == 'する' or kana.endswith('する'):
            k, r = kana[:-2], romaji[:-4] if romaji.endswith('suru') else romaji.rsplit('suru',1)[0]
            return {'masu':(k+'します', r+'shimasu'), 'mashita':(k+'しました', r+'shimashita'),
                    'masen':(k+'しません', r+'shimasen'),
                    'masendeshita':(k+'しませんでした', r+'shimasen deshita'),
                    'potential':(k+'できます', r+'dekimasu'),
                    'te':(k+'して', r+'shite'),
                    'tai':(k+'したいです', r+'shitai desu')}
        if kana == 'くる' or kana.endswith('てくる'):
            k = kana[:-2]; r = romaji[:-4] if romaji.endswith('kuru') else romaji.rsplit('kuru',1)[0]
            return {'masu':(k+'きます', r+'kimasu'), 'mashita':(k+'きました', r+'kimashita'),
                    'masen':(k+'きません', r+'kimasen'),
                    'masendeshita':(k+'きませんでした', r+'kimasen deshita'),
                    'potential':(k+'こられます', r+'koraremasu'),
                    'te':(k+'きて', r+'kite'),
                    'tai':(k+'きたいです', r+'kitai desu')}
        return None
    if cls == 'ichidan':
        k, r = kana[:-1], romaji[:-2]           # drop る / ru
        if not romaji.endswith('ru'): return None
        return {'masu':(k+'ます', r+'masu'), 'mashita':(k+'ました', r+'mashita'),
                'masen':(k+'ません', r+'masen'),
                'masendeshita':(k+'ませんでした', r+'masen deshita'),
                'potential':(k+'られます', r+'raremasu'),
                'te':(k+'て', r+'te'),
                'tai':(k+'たいです', r+'tai desu')}
    if cls == 'godan':
        last = kana[-1]
        if last not in I_ROW: return None
        ks, rs = kana[:-1], _rom_stem(romaji, kana)
        stem_k, stem_r = ks + I_ROW[last], rs + ROM_I[last]
        te_k = ks + ('って' if kana in IKU else TE_G[last])
        te_r = rs + ('tte' if kana in IKU else ROM_TE[last])
        pot_k, pot_r = ks + E_ROW[last], rs + ROM_E[last]
        return {'masu':(stem_k+'ます', stem_r+'masu'), 'mashita':(stem_k+'ました', stem_r+'mashita'),
                'masen':(stem_k+'ません', stem_r+'masen'),
                'masendeshita':(stem_k+'ませんでした', stem_r+'masen deshita'),
                'potential':(pot_k+'ます', pot_r+'masu'),
                'te':(te_k, te_r),
                'tai':(stem_k+'たいです', stem_r+'tai desu')}
    return None

def adj_forms(kana, romaji, pos):
    if pos == 'adj-i':
        if kana == 'いい':      # good: every inflected form is built on よ-
            return {'past':('よかった','yokatta'), 'neg':('よくない','yokunai'),
                    'politepast':('よかったです','yokatta desu'), 'te':('よくて','yokute')}
        if not kana.endswith('い') or not romaji.endswith('i'): return None
        k, r = kana[:-1], romaji[:-1]
        return {'past':(k+'かった', r+'katta'), 'neg':(k+'くない', r+'kunai'),
                'politepast':(k+'かったです', r+'katta desu'), 'te':(k+'くて', r+'kute')}
    if pos == 'adj-na':
        k = kana[:-1] if kana.endswith('な') else kana
        r = romaji[:-2] if romaji.endswith('na') else romaji
        # a na-adjective takes the copula as a separate word, so the romaji is
        # spaced: shizuka deshita, not shizukadeshita
        return {'past':(k+'だった', r+' datta'), 'neg':(k+'じゃない', r+' janai'),
                'politepast':(k+'でした', r+' deshita'), 'te':(k+'で', r+' de')}
    return None
