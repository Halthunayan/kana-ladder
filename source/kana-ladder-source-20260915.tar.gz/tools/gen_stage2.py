# -*- coding: utf-8 -*-
"""Sentences for the stage-2 vocabulary.

Built by composition, not by writing prose and then guessing what is in it:
each sentence is assembled from a template plus a target word, so the kana, the
romaji and the list of linked words all come out of the same construction and
cannot disagree. Every frame word is a tier-1 word, so a sentence never waits
on vocabulary the learner meets later than its own target.
"""
import os as _os
ROOT = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
def R(*p): return _os.path.join(ROOT, *p)
import json, sys, os
sys.path.insert(0, R('tools'))
from verbclass import classify
from conjugate import verb_forms, adj_forms
import kana as K
from curate_stage2 import BAD_DOKO, BAD_KUDASAI, BAD_TAISETSU, ROLE_OK, SYMPTOM

DECK  = json.load(open(R('deck', 'deck_full.json'), encoding='utf-8'))
BY    = {c['id']: c for c in DECK}

# frame words, all tier 1, all linked so the unlock rule stays honest
KORE=('c0224','これ','kore'); DOKO=('c0164','どこ','doko')
KUDASAI=('c0032','ください','kudasai'); ARU=('c0177',)
SUKI=('c0212','すき','suki'); KYOU=('c0051','きょう','kyou')
KINOU=('c0053','きのう','kinou'); ASHITA=('c0052','あした','ashita')
TOTEMO=('c0215','とても','totemo'); IKU=('c0180',)
SURU=('c0178',); WATASHI=('c0026','わたし','watashi')
YOKU=('c0058','よく','yoku'); AMARI=('c0059','あまり','amari')
KOKO=('c0161','ここ','koko'); TAKUSAN=('c0216','たくさん','takusan')


def vform(c, name):
    f = verb_forms(c['kana'], c['romaji'], classify(c))
    return f[name] if f else None

def aform(c, name):
    f = adj_forms(c['kana'], c['romaji'], c['pos'])
    return f[name] if f else None

def make(kana_parts, rom_parts, en, w, level, grammar):
    kana = ''.join(kana_parts) + '。'
    rom  = ' '.join([r for r in rom_parts if r]) + '.'
    st, why = K.check_sentence(kana, rom)
    if st != 'OK': return None, (kana, rom, why)
    return {'kana': kana, 'romaji': rom, 'en': en, 'level': level,
            'grammar': grammar, 'w': w}, None

import re as _re
def gloss(c):
    g = c['en'].split(';')[0].split(' / ')[0].strip()
    g = _re.sub(r'\s*\([^)]*\)', '', g).strip()
    g = g.split(',')[0].strip()
    return g[3:] if g.startswith('to ') else g

IRREG_PAST = {'become':'became','go':'went','come':'came','eat':'ate','drink':'drank','buy':'bought',
  'make':'made','take':'took','see':'saw','write':'wrote','read':'read','send':'sent',
  'lose':'lost','win':'won','put':'put','get':'got','give':'gave','meet':'met',
  'run':'ran','sleep':'slept','leave':'left','sell':'sold','pay':'paid','forget':'forgot',
  'hear':'heard','speak':'spoke','swim':'swam','wear':'wore','cut':'cut','throw':'threw',
  'catch':'caught','fall':'fell','build':'built','break':'broke','teach':'taught',
  'begin':'began','keep':'kept','feel':'felt','hold':'held','bring':'brought','find':'found'}
TAIL_IT = ('to','up','for','at','on','in','out','over','off','with','after','back')
def obj(g):
    """a verb gloss ending in a bare preposition needs an object in English"""
    return g + ' it' if g.split(' ')[-1] in TAIL_IT else g
def past_en(g):
    head = g.split(' ')[0]
    rest = g[len(head):]
    if head in IRREG_PAST: return IRREG_PAST[head] + rest
    if head.endswith('e'): return head + 'd' + rest
    if head.endswith('y') and len(head)>1 and head[-2] not in 'aeiou': return head[:-1] + 'ied' + rest
    return head + 'ed' + rest

PLACEY  = {'places','travel','city','transport','home','nature'}
THINGY  = {'objects','food','drink','shopping','clothes'}
ROLEY   = {'people'}
ABSTRACT= {'society','work','school','health','money','media','technology','feelings','time','counters'}

def build():
    out, bad, skipped = [], [], []
    for c in DECK:
        if c['stage'] != 2: continue
        tags = set(c.get('tags') or [])
        k, r, pos = c['kana'], c['romaji'], c['pos']
        s = err = None

        if 'grammar' in tags and pos in ('expr','particle','conj'):
            skipped.append((c['id'], k, 'grammar fragment, not a standalone sentence')); continue

        if pos == 'noun':
            gl = gloss(c); glc = gl.capitalize()
            if glc in SYMPTOM:
                s, err = make([k, 'があります'], [r, 'ga arimasu'],
                              'I have a %s.' % SYMPTOM[glc], [c['id'], ARU[0]], 3, 'existence')
                if s: out.append(s)
                continue
            if gl in ROLE_OK:
                s, err = make(['あのひとは', k, 'です'], ['ano hito wa', r, 'desu'],
                              'That person is the %s.' % gl, [c['id'], 'c0408'], 3, 'copula')
                if s: out.append(s)
                continue
            if 'counters' in tags:
                skipped.append((c['id'], k, 'a counter needs a number, not a frame')); continue
            if (tags & PLACEY) and gl not in BAD_DOKO:
                s, err = make([k, 'はどこですか'], [r, 'wa doko desu ka'],
                              'Where is the %s?' % gloss(c), [c['id'], DOKO[0]], 3, 'question')
            elif (tags & THINGY) and glc not in BAD_KUDASAI:
                s, err = make([k, 'をください'], [r, 'o kudasai'],
                              '%s, please.' % glc, [c['id'], KUDASAI[0]], 2, 'request')
            elif glc not in BAD_TAISETSU and (tags & (ABSTRACT | PLACEY | THINGY | ROLEY)):
                s, err = make([k, 'はたいせつです'], [r, 'wa taisetsu desu'],
                              '%s is important.' % glc, [c['id'], 'c0593'], 3, 'adjective')
            else:
                skipped.append((c['id'], k, 'no frame reads naturally for this noun')); continue

        elif pos == 'verb':
            m  = vform(c, 'masu'); mp = vform(c, 'mashita'); mn = vform(c, 'masen')
            if not m: bad.append((c['id'], 'no forms')); continue
            i = c['tier'] % 3
            if i == 0:
                s, err = make(['きょう', m[0]], ['kyou', m[1]],
                              'I will %s today.' % obj(gloss(c)), [c['id'], KYOU[0]], 3, 'time')
            elif i == 1:
                s, err = make(['きのう', mp[0]], ['kinou', mp[1]],
                              'I %s yesterday.' % obj(past_en(gloss(c))), [c['id'], KINOU[0]], 3, 'past')
            else:
                s, err = make(['あまり', mn[0]], ['amari', mn[1]],
                              'I do not %s much.' % obj(gloss(c)), [c['id'], AMARI[0]], 3, 'negation')

        elif pos == 'adj-i':
            if c['tier'] % 2 == 0:
                s, err = make(['とても', k, 'です'], ['totemo', r, 'desu'],
                              'It is very %s.' % gloss(c), [c['id'], TOTEMO[0]], 2, 'adjective')
            else:
                pa = aform(c, 'past')
                s, err = make(['きのうは', pa[0], 'です'], ['kinou wa', pa[1], 'desu'],
                              'Yesterday it was %s.' % gloss(c), [c['id'], KINOU[0]], 3, 'past')

        elif pos == 'adj-na':
            if c['tier'] % 2 == 0:
                s, err = make(['とても', k, 'です'], ['totemo', r, 'desu'],
                              'It is very %s.' % gloss(c), [c['id'], TOTEMO[0]], 2, 'adjective')
            else:
                ng = aform(c, 'neg')
                nr = r + ' ' + ng[1][len(r):] if ng[1].startswith(r) else ng[1]
                s, err = make(['あまり', ng[0], 'です'], ['amari', nr, 'desu'],
                              'It is not very %s.' % gloss(c), [c['id'], AMARI[0]], 3, 'negation')

        elif pos == 'adv':
            s, err = make([k, 'します'], [r, 'shimasu'],
                          'I do it %s.' % gloss(c), [c['id'], SURU[0]], 3, 'adverb')

        elif pos == 'counter':
            skipped.append((c['id'], k, 'a counter needs a number, not a frame')); continue

        elif pos == 'expr':
            s, err = make([k], [r], gloss(c).capitalize(), [c['id']], 2, 'expression')

        else:
            skipped.append((c['id'], k, 'part of speech has no frame')); continue

        if s: out.append(s)
        elif err: bad.append((c['id'], err))
    return out, bad, skipped

if __name__ == '__main__':
    rows, bad, skipped = build()
    print('generated', len(rows), '; rejected', len(bad), '; skipped', len(skipped))
    for b in bad[:10]: print('  reject', b)
    from collections import Counter
    print('  skip reasons:', Counter(x[2] for x in skipped).most_common())
    json.dump(rows, open(R('sentences', 'stage2_raw.json'),'w'), ensure_ascii=False)
