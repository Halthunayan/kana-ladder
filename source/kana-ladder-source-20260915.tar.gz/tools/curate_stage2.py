# -*- coding: utf-8 -*-
"""Curation pass over the generated stage-2 sentences.

A template can be grammatical and still be nonsense: "Where is the humidity?"
parses fine and means nothing. Every generated sentence was read, and the ones
that did not survive are routed to a frame that fits or dropped. Judgement is
recorded against the English gloss so the decision is legible.
"""
# "Where is the X?" does not work for these
BAD_DOKO = {
 'air temperature','business trip','cancellation','congestion','consecutive holidays',
 'driving','entry into a country','environment','fare','fee','freezing','fully booked',
 'guidance','humidity','nature','one night of a hotel stay','one-way trip','overseas',
 'pollution','population','rent','round trip','scenery','season','sightseeing','sorting',
 'storm','the Earth','thunder','traffic','world','accident','delivery','repair','recycling',
 'housing','autumn leaves','cherry blossom viewing','area',
}
# "X, please" does not work for these
BAD_KUDASAI = {
 'Allergy','Amount','Best-before date','Dieting','Exchange','Free of charge','Goods','Gram',
 'Half price','How to make','Ingredients','Nutrition','Payment','Percent','Postage','Price',
 'Raw','Shipping','Special sale','Splitting the bill','Stock','Tax included','Taste','Times',
 'Vegetarian','Advertisement','Cash register','Cardboard','Fitting room','Mail order',
 'Personal seal','Hem','Sleeve','Cotton','Animal feed','Loyalty points','Degrees of temperature or angle',
 'Bankbook','Copy','Freezing','Returning goods','Refill',
}
# "X is important" does not work for these
BAD_TAISETSU = {
 'Both','Most of','Half','The rest','Long ago','These days','The other day','Several times',
 'Three days from now','The year before last','Every month','Every year','Selfie','Lateness',
 'Anxiety','Nervousness','Regret','Tiredness','Absence','Injection','Sneeze','Dizziness',
 'Cavity','Headache','The flu','Wound','Crime','Nap','Breath','Excitement','Being deeply moved',
 'Being admitted to hospital','Being in charge of','Body temperature','Body weight','Mood',
 'Image','Content','Both','Fan','Channel','Era','New year','Basement','A walk',
 'Hem','Quarrel','Splitting the bill','Sleeve','Cotton','Half','Raw','Times','Percent','Gram',
}
# "That person is the X" only for real roles
ROLE_OK = {
 'boss','boyfriend','junior','senior','subordinate','prime minister','player','samurai',
 'university student','residents','fool','coach','actor','dentist','photographer','writer',
 'company employee','department manager','section chief','landlord','tour guide','tourist',
}
# these are complaints, and "I have a X" is the sentence a traveller needs
SYMPTOM = {
 'Headache':'headache','Dizziness':'dizziness','Cavity':'cavity','The flu':'the flu',
 'Wound':'wound','Sneeze':'sneeze','Lack of sleep':'lack of sleep','Allergy':'allergy',
}
# counters do not belong in a "please" frame; they get their own numeric frame or nothing
DROP_POS_TAGS = {'counters'}
