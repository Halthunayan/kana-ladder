# -*- coding: utf-8 -*-
"""Introduction order, written as data rather than left to array position.

The deck array order is load bearing elsewhere: the answer log indexes cards by
position and the audio sprites are grouped by it. So the order a learner MEETS
words in is carried in its own field, `ord`, and the array is never reshuffled.
"""
import json, os, collections

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P=os.path.join(ROOT,'deck','deck_full.json')
deck=json.load(open(P,encoding='utf-8'))
BY={x['id']:x for x in deck}
byrom=collections.defaultdict(list)
for x in deck: byrom[x['romaji']].append(x)

# Band 0: nothing works without these.
CORE_TAGS={'greetings','phrases'}
CORE_ROM=["hai","iie","sumimasen","arigatou","arigatou gozaimasu","onegai shimasu",
 # the grammar spine: without these he has nouns and no frame to put them in
 "desu","dewa arimasen","deshita","kono","sono","ano","kore","sore","are",
 "kara","made","mo","mou","ne","yo","dake","masen ka","mashou","tai desu",
 "ga arimasu","ga imasu","temo ii desu ka","nakereba narimasen","koto ga dekimasu",
 # the number system, which is what a price and a time are made of
 # the particle spine first: without it the sentence layer cannot open at all
 "wa","ga","o","ni","de","to","no","ka","e","mo","kara","made","ne","yo",
 # then the digits, then the counter heads before their own irregular readings
 "ichi","ni","san","yon","go","roku","nana","shichi","hachi","kyuu","juu",
 "ji","fun","nin","mai","gatsu","youbi","han",
 "iriguchi","deguchi","hoomu","yasai","chotto","sukoshi","okane",
 "zero","hyaku","sen","man","ichiman","nanji","nanban","ikutsu","hitotsu","futatsu",
 "mittsu","yottsu","itsutsu","hitori","futari","yoji","shichiji","kuji","ippun","sanpun",
 "juppun","gozen","gogo","keisatsu",
 # a date and a day of the week, which a hotel or a train booking turns on
 "getsuyoubi","kayoubi","suiyoubi","mokuyoubi","kinyoubi","doyoubi","nichiyoubi",
 "tsuitachi","futsuka","mikka","yokka","itsuka","muika","nanoka","youka","kokonoka",
 "tooka","juuyokka","hatsuka","sanbyaku","roppyaku","happyaku","sanzen","hassen",
 "ii","dou","dore","dochira","demo","soshite","dakara","yori","kyuukyuusha","tsugi",
 "wakarimasen","wakarimasu","daijoubu","chotto matte kudasai","mou ichido",
 "mou ichido onegai shimasu","mou ichido itte kudasai","yukkuri","gomennasai",
 "konnichiwa","ohayou gozaimasu","konbanwa","hajimemashite","douzo","dou itashimashite",
 "watashi","kore","sore","are","koko","soko","asoko","doko","nani","dare","ikura","ikutsu",
 "itsu","doushite","ichi","ni","san","yon","go","roku","nana","hachi","kyuu","juu","en",
 "nihongo","eigo","wa","ga","o","ni","de","to","no","ka"]

# Band 1: the trip. Tag driven, then a hand list for the things tags miss.
TRIP_TAGS={'travel','transport','money','health','restaurant','shopping','directions',
 'places','food','time','emergency','hotel','language','counters'}
TRIP_ROM=["itai","kusuri","byouin","isha","tasukete","pasupooto","genkin","kouban","arerugii",
 "norikaeru","katamichi","oufuku","yakkyoku","otsuri","menyuu","yoyaku","chekkuin","dame",
 "kega","wasureru","nakusu","ryougae","bejitarian","butaniku","gyuuniku","toriniku","sakana",
 "tamago","osake","mizu","ocha","koohii","matsu","tsukau","harau","wakaru","dekiru","noru",
 "oriru","hairu","deru","magaru","sagasu","komaru","tetsudau","kaeru","iku","kuru","taberu",
 "nomu","kau","miru","kiku","hanasu","iu","yomu","kaku","neru","suru","aru","iru",
 "eki","densha","basu","takushii","kuukou","hoteru","heya","kagi","toire","ginkou","yuubinkyoku",
 "mise","konbini","suupaa","resutoran","kissaten","chikatetsu","shinkansen","kippu","seki",
 "nimotsu","saifu","keitai","kaado","kurejittokaado","chizu","jikan","ima","kyou","ashita","kinou",
 "asa","hiru","yoru","migi","hidari","massugu","chikaku","tooi","takai","yasui","ookii","chiisai",
 "atsui","samui","oishii","daijoubu","abunai","erebeetaa","waifai","nuki","osusume","betsubetsu",
 "urikire","yoroshii","ikaga","kashikomarimashita","gozaimasu","miseru","narabu","azukeru",
 "aku","shimaru","mitsukaru","kakaru","ji","fun","nin","mai","bansen","han","gatsu","youbi",
 "gozen","gogo","ichiban","hou","onaji","nihon","tokoro","toki","basho"]

# the tags where every card is worth having before the flight
HOT={'travel','transport','emergency','health','restaurant','hotel','money','directions','language'}
def band(c):
    rom=c['romaji']
    tags=set(c.get('tags') or [])
    if rom in CORE_ROM or (tags & CORE_TAGS and c['pos'] in ('expr','interj','pron','num','particle')):
        return 0
    if rom in TRIP_ROM or (tags & HOT): return 1      # needed on landing day
    if tags & TRIP_TAGS: return 2                     # useful, second call
    return 3

# numbers before the words that count them, and 11..19 in order
NUMFIX={'juuichi':11,'juuni':12,'juusan':13,'juuyon':14,'juugo':15,'juuroku':16,'juushichi':17,
 'juunana':17,'juuhachi':18,'juukyuu':19,'nijuu':20,'sanjuu':30,'yonjuu':40,'gojuu':50,
 'rokujuu':60,'nanajuu':70,'hachijuu':80,'kyuujuu':90,'hyaku':100,'sen':1000,'man':10000}

# the first mention wins: a word named early in the list must not be demoted
# by a duplicate of itself further down
TRIP_ROM=TRIP_ROM+["juuichi","juuni","juusan","juuyon","juugo","juuroku",
 "juushichi","juunana","juuhachi","juukyuu","nijuu","sanjuu","yonjuu","gojuu",
 "rokujuu","nanajuu","hachijuu","kyuujuu"]
TRIP_RANK={}
for _i,_r in enumerate(CORE_ROM+TRIP_ROM):
    TRIP_RANK.setdefault(_r,_i)
def sortkey(c):
    i=IDX[c['id']]
    # a card named explicitly comes before one that merely carries the right tag,
    # and new cards appended to the array must not sort last for that reason alone
    named=TRIP_RANK.get(c['romaji'], 10**6)
    return (band(c), named, i)

IDX={x['id']:i for i,x in enumerate(deck)}
ordered=sorted(deck, key=sortkey)

# Spread the tags: five words entering on one day should not be five numbers.
def primary(c):
    t=(c.get('tags') or ['-'])
    return t[0]
def interleave(seq, window=5):
    out=[]; pool=list(seq)
    while pool:
        recent=[primary(x) for x in out[-window+1:]]
        pick=None
        for j,c in enumerate(pool[:60]):          # only look ahead inside the same band
            if primary(c) not in recent: pick=j; break
        if pick is None: pick=0
        out.append(pool.pop(pick))
    return out

final=[]
for b in (0,1,2,3):
    final += interleave([c for c in ordered if band(c)==b])
for i,c in enumerate(final): BY[c['id']]['ord']=i

json.dump(deck, open(P,'w',encoding='utf-8'), ensure_ascii=False, indent=1)

first=sorted(deck,key=lambda x:x['ord'])[:390]
tg=collections.Counter()
for x in first: tg.update(x.get('tags') or [])
allt=collections.Counter()
for x in deck: allt.update(x.get('tags') or [])
print("band sizes:", collections.Counter(band(c) for c in deck))
print("first 390 by tag:")
for t in ['travel','transport','money','health','restaurant','shopping','places','food','verbs','counters','phrases','greetings']:
    print("   %-12s %3d of %3d"%(t,tg.get(t,0),allt.get(t,0)))
print("pos:", collections.Counter(x['pos'] for x in first).most_common(8))
ids={x['id'] for x in first}
for w in ["itai","kusuri","byouin","tasukete","pasupooto","genkin","katamichi","oufuku","arerugii","norikaeru","otsuri","menyuu","harau","matsu","wakaru","dekiru","nuki","miseru"]:
    hit=[c for c in byrom.get(w,[])]
    print("   %-12s %s"%(w, "in" if hit and hit[0]['id'] in ids else "OUT"))
run=0; worst=0
seq=[primary(x) for x in sorted(deck,key=lambda x:x['ord'])]
for i in range(len(seq)-4):
    if len(set(seq[i:i+5]))==1: worst+=1
print("days where all five words share a primary tag:", worst)
first390={c['id'] for c in sorted(deck,key=lambda x:x['ord'])[:390]}
late=[]
for c in deck:
    t=set(c.get('tags') or [])
    if (t & {'numbers','counters','emergency'}) and c['id'] not in first390:
        late.append(c['romaji'])
print("number, counter or emergency cards NOT reached before the trip:", len(late))
print("   examples:", late[:12])
for r in ["desu","hyaku","sen","nanji","tasukete","kore","ji","hitotsu","hidari","go"]:
    hit=[c for c in deck if c['romaji']==r]
    if hit: print("   %-10s ord %d  %s"%(r, hit[0]['ord'], "in" if hit[0]['id'] in first390 else "OUT"))
