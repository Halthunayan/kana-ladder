# -*- coding: utf-8 -*-
"""Word links and cloze gaps, aligned rather than guessed.

Two earlier attempts failed the same way. Matching a card's kana as a bare
substring linked the particle de (で) to every sentence containing desu (です).
Matching the romaji by token fixed the links but left the gap position to a
substring search with a tolerance, which still cut holes inside words.

This version aligns the sentence's kana to its own romaji mora by mora, so a
romaji token index maps to an exact kana offset. A gap is written only when the
alignment is exact and the token run occurs exactly once. Anything else gets a
link and no gap, and the app declines to build a cloze without one.
"""
import json, os, re, sys
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT,'tools'))
import kana as K

DECK=json.load(open(os.path.join(ROOT,'deck','deck_full.json'),encoding='utf-8'))
SENT=json.load(open(os.path.join(ROOT,'sentences','sent_full.json'),encoding='utf-8'))
FORMS=json.load(open(os.path.join(ROOT,'conj','forms.json'),encoding='utf-8'))

PUNCT="、。？！,.!?'\"　 "
# the order words are taught in, so that when two cards match the same span the
# one the learner actually meets first is the one the sentence is held against
_deck_i={c['id']:i for i,c in enumerate(DECK)}
IDX_BY_ID={c['id']:c for c in DECK}
INTRO_RANK={c['id']:r for r,c in enumerate(sorted(
    DECK, key=lambda c: c['ord'] if isinstance(c.get('ord'),(int,float)) else _deck_i[c['id']]))}
PARTICLE_ALT={"wa":"ha","ha":"wa","e":"he","he":"e","o":"wo","wo":"o"}

def toks(r):
    r=r.lower()
    for ch in PUNCT: r=r.replace(ch," ")
    return [t for t in r.split(" ") if t]

# Inflected forms can collide: ikimasu is the polite present of both iku (to go)
# and ikiru (to live). Usually that is a real ambiguity and both cards are linked.
# These three are not: in a beginner travel deck the inflected form in question
# is always the other verb, and linking the rare one made 50 sentences wait for a
# word ranked past 1300 and glossed the wrong meaning under them. Matching the
# card by its own dictionary kana still works; only the inflected path is off.
NO_FORM_MATCH = {
 'c0964',   # ikiru, to live: ikimasu here is always iku, to go
 'c1094',   # oru, to fold: orimasu here is always oriru, to get off
 'c1332',   # katsu, to win: kaimasu here is always kau, to buy
}
# kiru (to wear) was on this list briefly and had to come off: its dictionary
# kana never appears in a sentence that uses it, so excluding the inflected path
# left the three sentences that actually teach it with no link at all. The two
# sentences that were reading kimasu as "wear" were rewritten instead.

def is_particle(c):
    return c['pos']=='particle'

def eq_tok(a,b,allow_alt):
    if a==b: return True
    return allow_alt and PARTICLE_ALT.get(a)==b

def morae(kana):
    """(kana index, kana length, romaji) for each mora, long marks folded in"""
    out=[]; i=0
    while i < len(kana):
        if kana[i] in PUNCT:          # punctuation carries no mora and no romaji
            i+=1; continue
        if not out and (kana[i]=='ー' or K.kata2hira(kana[i])=='っ'):
            i+=1; continue            # nothing yet for a long mark or a sokuon to act on
        two=kana[i:i+2]
        h2=K.kata2hira(two)
        if h2 in K.DIG: out.append((i,2,K.DIG[h2])); i+=2; continue
        ch=kana[i]; h=K.kata2hira(ch)
        if ch=='ー':                       # the katakana long mark
            out.append((i,1,out[-1][2][-1] if out else 'u')); i+=1; continue
        if h=='っ':                        # the small tsu doubles what follows
            out.append((i,1,'')); i+=1; continue
        if h in K.MONO: out.append((i,1,K.MONO[h])); i+=1; continue
        out.append((i,1,'')); i+=1
    return out

def align(kana, romaji):
    """map each character position of the space-free romaji to a kana index"""
    r=romaji.lower()
    for ch in PUNCT: r=r.replace(ch,"")
    pos=[]; ri=0
    for (ki,klen,rm) in morae(kana):
        if rm=="":                             # small tsu: the next consonant doubles
            if ri<len(r): pos.append(ki); ri+=1
            continue
        cand=[rm]
        alt=PARTICLE_ALT.get(rm)
        if alt: cand.append(alt)
        hit=None
        for c in cand:
            if r.startswith(c, ri): hit=c; break
        if hit is None:
            # sokuon already consumed the doubled consonant, or an unknown kana
            if ri<len(r) and r[ri]==rm[0]: hit=rm[0]
            else: return None
        for _ in hit: pos.append(ki)
        ri+=len(hit)
    if ri!=len(r): return None
    return pos

def token_spans(romaji):
    """(token, start char offset in the space-free romaji) for each token"""
    out=[]; off=0
    for t in toks(romaji):
        out.append((t, off)); off+=len(t)
    return out

def main():
    cards=sorted(DECK, key=lambda c:-len(c['romaji']))
    # two cards with the same kana cannot both be the answer to one gap, so
    # neither of them gets a cloze: ni (に) is both "two" and the particle
    seen={}
    for c in DECK: seen.setdefault(c['kana'],[]).append(c['id'])
    AMBIG={i for v in seen.values() if len(v)>1 for i in v}
    linked=0; gaps=0; gaps_kept=0; nogap=0; unaligned=0
    for x in SENT:
        st=[t for t,_ in token_spans(x['romaji'])]
        spans=token_spans(x['romaji'])
        pos=align(x['kana'], x['romaji'])
        if pos is None: unaligned+=1
        w=[]; g={}; keep=[]; cover={}
        for c in cards:
            if c.get('dup'): continue
            allow_alt=is_particle(c)
            cands=[toks(c['romaji'])]
            row=FORMS.get(c['id'])
            if row and c['id'] not in NO_FORM_MATCH:
                for k in range(2,len(row),3): cands.append(toks(row[k]))
            hits=[]; via_dict=False
            for ci,cand in enumerate(cands):
                if not cand: continue
                for i in range(len(st)-len(cand)+1):
                    if all(eq_tok(st[i+j],cand[j],allow_alt) for j in range(len(cand))):
                        hits.append((i,cand))
                if hits: via_dict=(ci==0); break
            if not hits: continue
            # a particle spelling variant only counts for an actual particle, so
            # ha (は, tooth) is no longer linked to every topic marker
            # a verb matched through its own polite form is a real link even
            # though the dictionary kana is not in the sentence 
            if not allow_alt and via_dict and c['kana'] not in x['kana']: continue
            cover[c['id']]=frozenset(j for (i,cand) in hits for j in range(i,i+len(cand)))
            keep.append(c)
            if pos is None or len(hits)!=1: 
                nogap+=1; continue              # ambiguous or unalignable: link, no gap
            i,cand=hits[0]
            start=spans[i][1]
            if start>=len(pos): nogap+=1; continue
            at=pos[start]
            if x['kana'][at:at+len(c['kana'])]!=c['kana']: nogap+=1; continue
            # and the gap must be the only place that word appears
            if x['kana'].count(c['kana'])!=1: nogap+=1; continue
            if c['id'] in AMBIG: nogap+=1; continue
            g[c['id']]=at; gaps+=1

        # Two clean-ups, both about cards that match the same run of romaji.
        #
        # A late-taught fragment of an early-taught phrase is not a second word:
        # onegai (rank 1449) sits inside onegai shimasu (rank 16), and linking it
        # made every request sentence wait for a word that is never reached
        # before the trip. Only the later of the two is dropped, so desu inside
        # ikura desu ka survives: it is taught first and is a word in its own right.
        #
        # There is no second rule for two cards that match the same span. That
        # was tried, resolving the tie by which word is taught first, and it is
        # unsound: it reads kimasu as kuru rather than kiru in a sentence about
        # putting on a sweater, and okimasu as oku rather than okiru in one about
        # getting up. Nothing in the romaji can tell those apart, so both cards
        # stay linked and neither gets a gap, which is at least never wrong.
        # Particles are exempt from the containment rule: they are function words
        # the app drills in position, and never the word that holds a sentence shut.
        rank=lambda cid: INTRO_RANK.get(cid, 1<<30)
        for c in keep:
            cid=c['id']; mine=cover[cid]
            if not mine: continue
            if not is_particle(c):
                swallowed=any(cover[o['id']] > mine and rank(o['id']) < rank(cid)
                              for o in keep if o['id']!=cid)
                if swallowed: continue
            w.append(cid)
        g={k:v for k,v in g.items() if k in w}       # a gap belongs to a linked word

        # Bound forms cannot be found by a token matcher: masen ka is never a
        # token of its own, it is the tail of ikimasen ka. A sentence may name
        # such a card explicitly in wx, and the claim is checked the only way it
        # can be: the card's kana must literally appear in the sentence. A bound
        # form never gets a cloze gap, because blanking a suffix asks nothing.
        for wid in x.get('wx', []):
            c=IDX_BY_ID.get(wid)
            assert c is not None, '%s names a missing word %s' % (x['id'], wid)
            assert not c.get('dup'), \
                '%s names %s, a duplicate card the app never introduces' % (x['id'], wid)
            assert c['kana'] in x['kana'], \
                '%s claims %s (%s) but it is not in the sentence' % (x['id'], wid, c['kana'])
            if wid not in w: w.append(wid)
            # A bound form swallows whatever is spelled inside it: te mo ii desu
            # ka contains ii desu, nakereba narimasen contains narimasen. Linking
            # those as separate words made the sentence wait for a card ranked
            # past the trip and glossed the wrong half of the pattern.
            inner=set()
            for o in DECK:
                if o['id']==wid or is_particle(o): continue
                faces=[o['kana']]
                orow=FORMS.get(o['id'])
                if orow:
                    for k in range(1,len(orow),3): faces.append(orow[k])
                if any(f and f in c['kana'] for f in faces): inner.add(o['id'])
            w=[i for i in w if i not in inner]
            g={k:v for k,v in g.items() if k in w}
        linked+=len(w); gaps_kept+=len(g)
        x['w']=w
        if g: x['g']=g
        elif 'g' in x: del x['g']
        if not x['w']:
            x['w']=[c['id'] for c in cards if c['romaji'] in st][:1]
    json.dump(SENT, open(os.path.join(ROOT,'sentences','sent_full.json'),'w',encoding='utf-8'),
              ensure_ascii=False, indent=1)
    print("links %d, gaps %d, links without a safe gap %d, sentences that would not align %d"
          %(linked,gaps_kept,nogap,unaligned))
    import collections
    wc=collections.Counter()
    for x in SENT: wc.update(x['w'])
    print("words carried by a sentence:", len(wc))
    print("sentences with no link:", sum(1 for x in SENT if not x['w']))

if __name__=='__main__': main()
