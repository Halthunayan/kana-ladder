#!/bin/sh
# Pull the pre-rendered voice library back down from whichever host serves the app.
# The sprite filenames are content hashes, so the manifest is the index of what to fetch.
BASE="${1:-https://kana-ladder-7k3q9v.netlify.app}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/pwa/audio/v1"
mkdir -p "$OUT"
echo "fetching the manifest from $BASE"
curl -fsS "$BASE/audio/v1/manifest.json" -o "$OUT/manifest.json" || { echo "manifest not reachable"; exit 1; }
python3 - "$OUT" "$BASE" <<'PY'
import json, os, sys, urllib.request
out, base = sys.argv[1], sys.argv[2]
man = json.load(open(os.path.join(out, 'manifest.json')))
files = man.get('files') or {}
n = 0
for sprite, stem in sorted(files.items()):
    for ext in ('.json', '.mp3'):
        dest = os.path.join(out, stem + ext)
        if os.path.exists(dest):
            continue
        url = base + '/audio/v1/' + stem + ext
        urllib.request.urlretrieve(url, dest)
        n += 1
        print('  ' + stem + ext)
print('%d files fetched, %d sprites in the manifest' % (n, len(files)))
PY
