# Kana Ladder: restoring the source

Archive built 15 September 2026. Contains everything needed to rebuild the app except the
pre-rendered audio library, which is 59 MB and is fetched separately (see below).

## Rebuild

    tar -xzf kana-ladder-source-20260915.tar.gz
    python3 build/build.py

Expected output:

    guards passed: 1812 words, 1442 sentences, 40 anchors, 2530 generated forms, all romaji verified

Then these must match:

    pwa/index.html   md5  88dcebdc5ef1ce46c58f61944b7bc9a9
    pwa/sw.js        md5  6f42229b4fa92958caa47349d7824a03   (cache version kana-ladder-v44)

Verified on 15 September by extracting this archive into an empty directory and rebuilding: the
output matched the shipping file byte for byte, with and without the audio blobs present.

The build only needs `pwa/audio/v1/manifest.json`, which is in the archive, to set its "audio
shipped" flag. So the rebuild is exact straight out of the tarball. The mp3 files are only
needed to actually hear anything:

    bash tools/fetch_audio.sh          # pulls the 59 MB of sprites back down

## The audio library

26 sprites, 59 MB of mp3, named after a hash of their contents. The archive carries the manifest
and every sprite's clip index, which are small; only the mp3 blobs are left out.
`tools/fetch_audio.sh [base-url]` downloads them from whichever host is serving the app, reading
`pwa/audio/v1/manifest.json` for the list. It defaults to the current live site.

To regenerate instead of downloading, `tools/voice.py` rebuilds every clip from scratch using
Piper with the ja_JA-hi_fi_captain-medium and en voices. That takes about 90 minutes and needs
the two .onnx voice files, which are not in this archive and are downloaded by Piper. The
filenames will differ, because they are content hashes and the voice has a random component.
`tools/audio_check.py` then measures every Japanese clip and fails under the quality floor.

## Tests

    cd app && npm install            # playwright
    python3 -m http.server 8099 &    # serving pwa/, in another shell on 8099 and 8100
    node regress.js                  # and the other 28 suites

`app/deploy_check.js` is a deployment rehearsal: set DEPLOY_BASE to a live URL and it checks
boot, the audio manifest, clip playback, the service worker, an offline reload and a drive.

## What is inside

    build/       app.core.js (the whole app), body.html, style.css, fonts.css, build.py
    deck/        1,812 vocabulary cards
    sentences/   1,442 example sentences
    conj/        40 conjugation anchors, 2,530 generated forms
    tools/       voice renderer, audio quality gate, linkers, validators, generators
    app/         29 test suites including the audit and the deployment rehearsal
    pwa/         the deployed bundle, service worker, manifest, icons (audio excluded)
    state/       backups exported from the phone, used as real-data test fixtures

Excluded: node_modules, screenshots, and pwa/audio.

## Hosting

Live at https://kana-ladder-7k3q9v.netlify.app on the Netlify Free plan, 300 credits a month,
15 credits per production deploy. As of 15 September there are about 13 credits left, which is
not enough for another deploy until the allowance turns over on 8 October.

A second free Netlify team is not possible: the create-team flow offers only paid plans.
GitHub Pages is the intended replacement, free and unlimited, and the bundle has been rehearsed
against a sub-path successfully. It needs a GitHub account linked to this session, which as of
15 September it is not.

**Always bump CACHE in pwa/sw.js before deploying.** The shell is served stale-while-revalidate
and the app's reload-on-new-worker only fires when sw.js itself changes, so a deploy with an
unchanged service worker is invisible until the phone's second launch.
