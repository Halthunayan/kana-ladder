# Council Review — Japanese Language Seat
**File:** `/home/claude/examples/review_1.tsv` — 183 example sentences
**Date:** 2026-09-15
**Reviewer remit:** Japanese language only (grammar, naturalness, target-word fit, EN accuracy, register, beginner-appropriateness)

## VERDICT: NOT APPROVED

47 rows carry a problem. 136 rows judged sound. The deck is broadly competent — most sentences are short, correctly particled, and polite-consistent — but it ships at least one outright mistranslation, one wrong collocation that contradicts another card in the same file, a systematic romaji defect that matters more than usual because this learner reads romaji only, and several near-duplicate cards.

---

## Problems

Severity: **H** = will teach something wrong; **M** = unnatural or misleading; **L** = improvable / note.

| id | Sentence as written | What is wrong | Corrected (kana) | Corrected (romaji) | Sev |
|---|---|---|---|---|---|
| c0024 | はじめまして、おなまえはなんですか。 | Textbook-correct but blunt; fired at a stranger it reads like an interrogation. Japanese softens it. | しつれいですが、おなまえはなんですか。 | shitsurei desu ga, onamae wa nan desu ka. | L |
| c0604 | しかし、きょうはとてもいそがしいです。 | しかし is a contrastive conjunction with nothing to contrast against. Every other conjunction card in this file (c1153, c1154, c1156, c1157) correctly supplies a first clause; this one does not. | にほんごはむずかしいです。しかし、まいにちべんきょうします。 | nihongo wa muzukashii desu. shikashi, mainichi benkyou shimasu. | M |
| c0635 | わたしはとてもはらがたちました。 | Two faults. (1) とても + verb is weak Japanese; with 腹が立つ you say すごく / ほんとうに. (2) The idiom is far more teachable with its 〜に cause. Also the card's `target_en` gloss "blood boils" is factually wrong — はら is belly/stomach, not blood. | かれのことばに、ほんとうにはらがたちました。 | kare no kotoba ni, hontou ni hara ga tachimashita. | M |
| c0647 | ううん、わたしはさかなをたべません。 | Register clash: ううん is casual, ません is polite. Also negation of a habit takes contrastive は, not を — 「さかなは食べません」. | ううん、さかなはたべない。 | uun, sakana wa tabenai. | M |
| c0650 | そのはなしはほんとうですか。 | Japanese is fine. English "Is that story really true?" double-counts — ほんとうですか already carries "really". | (kana unchanged) → EN: "Is that story true?" | (romaji unchanged) | L |
| c0652 | やった、テストにごうかくしました。 | (1) Register clash やった / ました. (2) 合格する collocates with しけん/試験, not テスト (テストに受かる is the pairing for テスト). | やった、しけんにごうかくした。 | yatta, shiken ni goukaku shita. | M |
| c0668 | すみません、どちらからきましたか。 | Japanese is grammatical but does **not** mean "where are you from" — it means "where did you come from (just now)". "Where are you from" is ごしゅっしんはどちらですか. Shipping this gloss will make him ask the wrong question. Also the polite form to a stranger is いらっしゃいましたか. | Keep the sentence, change `target_en` to "where did you come from?"; add a second card: ごしゅっしんはどちらですか。 | goshusshin wa dochira desu ka. | M |
| c0876 | すみません、おかんじょうおねがいします。 | Correct and used, but おかんじょう now reads slightly dated / izakaya-flavoured. In 2026 the phrase he will hear and should use is おかいけい. | すみません、おかいけいおねがいします。 | sumimasen, okaikei onegai shimasu. | L |
| c0933 | みせであたらしいはブラシをかいました。 | Kana-only rendering はブラシ is a trap: a kana reader will parse the leading は as the topic particle *wa*. The は here is the word for "tooth". Either render ハブラシ (as packaging does) or annotate the card. | みせであたらしいハブラシをかいました。 | mise de atarashii haburashi o kaimashita. | M |
| c0992 | あけましておめでとうございます、ことしもよろしくおねがいします。 | Two fixed set phrases comma-spliced. They are always two separate utterances. | あけましておめでとうございます。ことしもよろしくおねがいします。 | akemashite omedetou gozaimasu. kotoshi mo yoroshiku onegai shimasu. | L |
| c1012 | わたしのいけんはかれとはんたいです。 | Mismatched comparison — it compares *my opinion* to *him*, not to his opinion. | わたしのいけんは、かれのいけんとはんたいです。 | watashi no iken wa, kare no iken to hantai desu. | M |
| c1040 | みせでふたつのかばんをくらべました。 | Translationese. Japanese does not front-load counters as 「ふたつの N」 for a plain count; the counter follows the object. | みせでかばんをふたつくらべました。 | mise de kaban o futatsu kurabemashita. | M |
| c1051 | わたしはぜったいにうそをいいません。 | **Wrong collocation.** A lie is 嘘を*つく*, not 嘘を*言う*. This file's own c1218 uses うそをつきました — the deck contradicts itself. Separately, the card word is ぜったい but the sentence shows ぜったいに, and c1135 is already ぜったいに: two cards, one word. | わたしはぜったいにうそをつきません。 | watashi wa zettai ni uso o tsukimasen. | **H** |
| c1055 | ははがばんごはんをじゅんびしています。 | Out-of-the-blue statement about one's own mother takes は; が here answers an unasked "who?". じゅんびをする is also the more idiomatic frame. | はははばんごはんのじゅんびをしています。 | haha wa bangohan no junbi o shite imasu. | L |
| c1064 | ごみをふたつにわけてください。 | Nobody divides rubbish "into two" — in Japan you divide it by type. As written it is semantically odd and wastes a genuinely useful travel sentence. | このケーキをふたつにわけてください。 | kono keeki o futatsu ni wakete kudasai. | M |
| c1079 | せんせいはわたしのにほんごをほめました。 | Grammatical, but a native speaker reporting praise received almost always uses the benefactive ほめてくれました. The bare form sounds like a detached third-party report. | せんせいはわたしのにほんごをほめてくれました。 | sensei wa watashi no nihongo o homete kuremashita. | M |
| c1095 | ちちはまいにちネクタイをむすびます。 | ネクタイ collocates with しめる (or する). ネクタイを結ぶ is attested but off-register. It teaches the wrong pairing for a very common object. | わたしはくつのひもをむすびます。 | watashi wa kutsu no himo o musubimasu. | M |
| c1101 | ふゆにみずうみがこおります。 | General/habitual statements take は on the time word, not に. 「冬は〜」. | ふゆはみずうみがこおります。 | fuyu wa mizuumi ga koorimasu. | L |
| c1113 | きょうはすこしきもちわるいです。 | Gloss/example mismatch. The card glosses きもちわるい as "unpleasant, gross"; the sentence and its English use it as "I feel sick". Both readings exist, which is exactly why the example must pick one. For "I feel sick" Japanese prefers きぶんがわるい (which is c1199's word). | このむしはきもちわるいです。 | kono mushi wa kimochiwarui desu. | M |
| c1114 | ていねいにせつめいしてください。 | **Mistranslation.** ていねいに + verb means "carefully / thoroughly / in detail", **not** "politely". The English "Please explain it politely" is wrong and would have him telling Japanese staff to mind their manners. | (kana unchanged) → EN: "Please explain it carefully." | (romaji unchanged) | **H** |
| c1115 | あのひとのことばはしつれいでした。 | 「言葉が失礼」 is understandable but stiff; natives say 言い方 (the way it was said). | あのひとのいいかたはしつれいでした。 | ano hito no iikata wa shitsurei deshita. | L |
| c1121 | これはふつうのコーヒーです。 | Semantically near-empty — "this is ordinary coffee" is not a thing anyone says. Wastes a high-frequency word. | わたしはふつうのコーヒーがすきです。 | watashi wa futsuu no koohii ga suki desu. | L |
| c1124 | このパソコンはおかしいです。 | Passable, but the idiomatic frame is 調子がおかしい when a machine misbehaves. | このパソコンはちょうしがおかしいです。 | kono pasokon wa choushi ga okashii desu. | L |
| c1135 | `target_romaji` = "zettaini" | Inconsistent with c1051's sentence romaji "zettai ni". Pick one; 絶対に is stem + particle. | — | `zettai ni` | L |
| c1137 | `target_romaji` = "tashikani" | 確かに is 確か + に. Should be spaced to match the file's own treatment of adverbial に. | — | `tashika ni` | L |
| c1153 | `target_romaji` = "sonotame" | そのため is その + ため. | — | `sono tame` | L |
| c1154 | `target_romaji` = "sonoue" | そのうえ is その + うえ. | — | `sono ue` | L |
| c1164 | `target_romaji` = "kazeohiku" | **Systematic defect, worst instance.** The particle を is glued into the word. He reads romaji *only* — this actively hides that かぜをひく is noun + particle + verb, and "kazeohiku" is not a spacing any romanisation uses. The sentence column gets it right ("kaze o hiite"), so the two columns contradict each other. | — | `kaze o hiku` | **H** |
| c1180 | あにはしんちょうがたかいです。 | Attested but not what people say — 兄は背が高い is the everyday sentence. 身長 belongs with a measurement. | あにのしんちょうは180センチです。 | ani no shinchou wa hyakuhachijuu senchi desu. | M |
| c1192 | `target_romaji` = "hottosuru" | する-verb boundary glued. Sentence column correctly has "hotto shimashita". | — | `hotto suru` | M |
| c1195 | あなたのしごとがうらやましいです。 | **あなた.** Used to a real person's face this ranges from distant to presumptuous (it is also what wives call husbands). A beginner who learns あなた as "you" will use it in Japan and it will land badly. Japanese uses the person's name or drops the pronoun. | ともだちのしごとがうらやましいです。 | tomodachi no shigoto ga urayamashii desu. | **H** |
| c1201 | ながいじゅうたいで、いらいらしました。 | 渋滞 collocates with ひどい / すごい, not ながい. | ひどいじゅうたいで、いらいらしました。 | hidoi juutai de, iraira shimashita. | L |
| c1202 | ひとりのりょこうはすこしふあんです。 | 「ひとりの旅行」 is translationese — Japanese nominalises the action. | ひとりでりょこうするのは、すこしふあんです。 | hitori de ryokou suru no wa, sukoshi fuan desu. | M |
| c1223 | あさ、せんせいにあいさつをします。 | Near-identical twin of c1076 (あさ、となりのひとにあいさつします). Two cards, two all-but-identical sentences; the noun card teaches nothing the verb card did not. | にほんでは、あいさつがとてもたいせつです。 | nihon de wa, aisatsu ga totemo taisetsu desu. | M |
| c1224 | ともだちにかぞくのしょうかいをしました。 | Awkward (「家族の紹介をする」 is a stiff back-formation) **and** it is c1072 reversed — same participants, same event. | かいぎで、じこしょうかいをしました。 | kaigi de, jikoshoukai o shimashita. | M |
| c1225 | きづく (card) | **Exact duplicate word** with c1062 — same kana, same romaji, two cards, two glosses. He will see the same word twice and not know why. Merge into one card. | Merge with c1062; keep わたしはかれのきもちにきづきました。 | watashi wa kare no kimochi ni kizukimashita. | M |
| c1233 | にほんのすいどうのみずはあんぜんです。 | Stacked の…の…は is clunky; drop one layer. | にほんのすいどうはあんぜんです。 | nihon no suidou wa anzen desu. | L |
| c1266 | きょうはくもりですが、あめはふりません。 | Flat 降りません asserts a fact about the future. A forecast in Japanese is hedged. | きょうはくもりですが、あめはふらないでしょう。 | kyou wa kumori desu ga, ame wa furanai deshou. | M |
| c1271 | いなかのしぜんはとてもきれいです。 | Japanese is fine; the English "The nature in the countryside" is not idiomatic English. | (kana unchanged) → EN: "The countryside's natural scenery is very beautiful." | (romaji unchanged) | L |
| c1304 | あめのひに、わたしのくつがよごれました。 | わたしの is redundant (nobody else's shoes are in play), and 「雨の日に」 + a single past event is an awkward pairing — the cause particle で carries it. | あめで、くつがよごれました。 | ame de, kutsu ga yogoremashita. | L |
| c1307 | `sentence_romaji` = "…shuuri o onegaishimasu." | Spacing inconsistent with c0876 and c0992, which both write "onegai shimasu". | — | `jitensha no shuuri o onegai shimasu.` | L |
| c1310 | このへやにはたたみがあります。 | 「畳があります」 reads as "there are tatami mats lying around in this room". A tatami room *is* tatami; you do not inventory them. | このりょかんのへやは、たたみです。 | kono ryokan no heya wa, tatami desu. | M |
| c1318 | このがっこうのせいふくはとてもきれいです。 | Japanese means "pretty / clean". The English "very smart" is a different claim (which would be かっこいい). | (kana unchanged) → EN: "This school's uniform is very pretty." | (romaji unchanged) | L |
| c1325 | `target_romaji` = "renshuusuru" | する-verb boundary glued; sentence column has "renshuu shimasu". | — | `renshuu suru` | M |
| c1358 | `target_romaji` = "roguinsuru" | Same. Sentence column has "roguin shite kudasai". | — | `roguin suru` | M |
| c1359 | `target_romaji` = "kensakusuru" | Same. Sentence column has "kensaku shimashita". | — | `kensaku suru` | M |
| c1360 | `target_romaji` = "daunroodosuru" | Same. Sentence column has "daunroodo shite kudasai". | — | `daunroodo suru` | M |

---

## Patterns

**1. The `target_romaji` column contradicts the `sentence_romaji` column.**
Seven cards glue a particle or する onto the stem — `kazeohiku`, `hottosuru`, `renshuusuru`, `roguinsuru`, `kensakusuru`, `daunroodosuru`, `zettaini` — while the sentence romaji for the very same word spaces them correctly (`kaze o hiite`, `hotto shimashita`, `renshuu shimasu`). Three more (`tashikani`, `sonotame`, `sonoue`) are borderline. This is the single highest-leverage fix in the file: a learner who reads only romaji has no kana to fall back on, so the front of the card is the only place he learns where a word ends and a particle begins. `kazeohiku` in particular teaches him that を is part of the word. Fix the column with one pass, not row by row.

**2. Noun/verb card pairs duplicate their examples instead of differentiating.**
c1076 あいさつする / c1223 あいさつ, and c1072 しょうかいする / c1224 しょうかい, are the same sentence twice with the participants shuffled. c1062 / c1225 is worse — literally the same word (きづく) on two cards. c1051 ぜったい / c1135 ぜったいに is the same again. When a deck gives one word two cards, the second card has to earn it; here it does not, and the second example is usually the more awkward of the two (かぞくのしょうかいをしました). Rule going forward: the noun card must show the word doing something the verb card cannot — as a topic, in a compound, or with a different predicate.

**3. Casual interjection + polite predicate.**
c0647 (ううん / たべません) and c0652 (やった / ごうかくしました) both pair a casual opener with a です・ます tail. Native speakers do mix these, but a two-month beginner has no ear for when, so he will generalise the mix. Casual word → casual sentence; that is what makes the card teach the register.

**4. Example sentences carrying vocabulary harder than the target.**
ごうかく (c0652), しょるい (c1046), じんこう (c1068), みずうみ (c1101), めんせつ (c1190), じゅうたい (c1201), かんきょう (c1272). Each is fine in isolation but they accumulate: the back of a card should not be where he meets his third unknown word. c1272 (みんなでちきゅうのかんきょうをまもりましょう) is the clearest case — abstract, preachy, and useless in Japan.

**5. English translations drifting from the Japanese.**
c1114 is the serious one (ていねいに = carefully, not politely). c1318 ("smart" for きれい), c1271 ("the nature"), c0650 ("really true"), and the c0635 card gloss ("blood boils" for 腹が立つ) are the rest. The Japanese was checked; the English was not.

**6. What the file gets right, for the record.**
Transitive/intransitive pairs are handled genuinely well — つづける/つづく, あつめる/あつまる, わける/わかれる, ふやす/へる/へらす, うごく/うごかす, きまる, おちる are all correctly particled with を vs が, which is the thing decks most often botch. て-form causal chaining (c1164, c1191, c1192, c1193, c1198) is clean. Travel-relevant sentences (c1109 hotel delivery, c1157 ryokan, c1268 storm stopping trains, c1282 microwave, c1361 charger, c1370 shrine) are well chosen for a 30 November departure.

---

## Count

**136 of 183 rows judged sound.**
47 rows flagged: 4 high severity, 22 moderate, 21 low.
