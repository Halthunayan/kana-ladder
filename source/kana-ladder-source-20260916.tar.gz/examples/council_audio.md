# Council review — audio seat: Kana Ladder voice library v1

**Verdict: NOT APPROVED.**

Scope: `/home/claude/pwa/audio/v1` (26 sprites, 9,049 clips, 53.2 MB) against
`/home/claude/tools/voice.py`, `audio_check.py`, `audio_survey.py`.
Every number below is from my own decode of the shipped sprites, plus piper
ground-truth re-renders at the same `length_scale`. I did not trust
`/tmp/audio_gate.log` or `/tmp/audio_survey.json`; where I cite them it is to
show they are wrong.

Method, briefly: each clip was decoded from its byte range with ffmpeg to
22.05 kHz mono PCM and measured on 10 ms frames — level envelope, silence at
−45 dBFS and at peak−30 dB, energy-nucleus count, and a 1024-point spectral /
autocorrelation pass over the final 600 ms. Nasals were tested by a *paired*
spectral contrast, not by absolute low-frequency energy (see F5). Selection
bias was tested by re-drawing the same text with piper and comparing the
shipped clip against the draw distribution.

---

## Findings, most serious first

| # | Sev | Finding | Measurement |
|---|-----|---------|-------------|
| F1 | **Block** | The renderer maximises the exact statistic the gate scores, so the gate is structurally blind to the renderer's failure mode | `mp3()` keeps the longest of `WORD_TRIES=4` draws on `voiced()`, then the floor ladder keeps the max over up to 12 more; `audio_check.py` then passes on `voiced()/morae`. Across 30 random word clips the shipped clip beats the median of 3 fresh draws at the same rate in **87%** of cases (median ratio 1.12, mean 1.15). In the tail it is extreme: あく shipped 0.370 s voiced vs draw median 0.075 s (**4.9×**), か 0.340 vs 0.095 (**3.6×**), サッカー span 1.42 s vs 0.55 s (**2.6×**). Every way this voice fails — babbling, stuttering, holding a vowel — *raises* `voiced()`, so max-of-N prefers those draws and the gate rewards them. |
| F2 | **Block** | Clips shipped with wrong content: babble that the max rule selected | Energy-nucleus count vs mora count. `wj:c1767` あく — **9 nuclei for 2 morae** (10 fresh draws give 1–3). `wj:c0245` か — **6 nuclei for 1 mora**. `wj:c1098` わく — **7 for 2**. 18 of 4,342 word clips have more nuclei than morae, 4 exceed by ≥2. Sentence clips (not re-rendered): **0.0%**. These are not the word; they are the model stuttering. |
| F3 | **Block** | Four word clips are cut off mid-phonation, ending at full level | Level of the final 10 ms frame relative to the clip's own peak, with trailing room tone: `wj:c0245` か **−5.3 dB, 0 ms of tail** (last sample −242 → audible click); `wj:c1098` わく −17.1 dB; `wj:c1421` こ −18.4 dB; `wj:c0038` ご −18.6 dB. Library median is −67.8 dB. **This is not `trim()`'s doing** — `trim` only ever extends past the last frame above −45 dBFS, so it cannot shorten a clip that is still loud. The draws themselves end abruptly and nothing checks the end level or applies a fade. か, こ, ご are single-kana core items. |
| F4 | High | Katakana ン-final words get no nasal suffix at all | `text.endswith('ん')` misses `'ン'`. 23 deck words: パン, ラーメン, レストラン, ペン, パソコン, ワイン, スプーン, ズボン, ボールペン, レモン, マンション, キッチン, カーテン, ボタン, ナプキン, ノートパソコン, チェックイン, フライパン, アイロン, ファン, ヘッドホン, ベジタリアン, カメラマン. By the paired nasal test, suffixed ん words clear Δ ≥ 6 dB in **85.0%** of cases and hold a ≥60 ms murmur in 74.2%; the ン words manage **60.9% / 43.5%**. They measurably still carry the original defect. |
| F5 | High | The survey's nasal metric measures nothing, so "98% have an audible final nasal" is not evidence — and 15% of ん words still have no nasal | Reproducing `audio_survey.py`'s own detector (tilt ≥ 14 dB while audible), it fires on **96.0% of vowel-final words**, **97.7% of い-final words**, and **100% of sentences ending in ん that were never suffixed**. It detects "ends with a voiced low-tilt sound", which every Japanese word does. A proper test — collapse of the 800–2500 Hz band against the 150–600 Hz murmur, paired against the vowel 120 ms earlier — shows the effect is real but smaller: **Δ median +14.7 dB on ん words vs +1.8 dB baseline**, 85.0% clearing +6 dB against a 17.6% baseline. That leaves **68 of 454 ん-final clips (15%) with no nasal**: かいしゃいん (Δ −9.4), ちゃわん (−6.6), たいおん (−5.4), やちん (−4.1), おくさん (−4.0), すいみん (−3.3), てんいん (−3.2), へんきん (−3.0), たくはいびん (−2.8), ごりょうしん (−1.9), plus form clips つきません, みつけません. Several end 15–20 dB below peak — the original "inaudible nasal" defect, unfixed. |
| F6 | High | Trimming is absent from the sprite signature for sentence and English clips, so the shipped library is half-trimmed | `signature()` stamps a render marker only for ja `'word'` clips (`WORD_RENDER`) and `laddered()` clips (`RENDER`), but `trim()` runs on **every** clip. Leading room tone at −45 dBFS across all 1,442 sentence clips: **s-004 / s-005 / s-007 = 0.15 s** (they happened to re-render for a text change) vs **s-000–003 / s-006 / s-008 / s-009 = 0.28 s** (reused untrimmed). Two sentences in the same drill therefore start 130 ms apart, and the next build will scramble the split differently. Latent, silent, and self-perpetuating. |
| F7 | Medium | Over-slow clips, concentrated on the single-mora particles — and car mode then slows them again | Articulation span per mora: word median 0.182 s, but **43 clips > 0.30, 15 > 0.35, 4 > 0.40**. Worst: の **0.56 s held for one mora** (fresh-draw median 0.305 s), も 0.47 s, うそ 0.415 s/mora, へ 0.41, サッカー **1.91 s total for 4 morae**. `index.html` then replays every Japanese word at `playbackRate` **0.706** by default (`Math.max(0.4, rate−0.25)` with `speechRate` 0.85, over `rate/0.85`) — の becomes 0.79 s of one syllable, サッカー 2.7 s, and 77 clips (1.8%) exceed 0.40 s/mora. |
| F8 | Medium | Geminate closures stretched until they read as word boundaries | Longest silence below peak−30 dB *inside* the speech span. Word clips containing っ/ッ: median **0.16 s**, p90 0.23 s, **65.4% ≥ 0.15 s** — against 1.5% for non-sokuon words. けっこん carries **0.61 s**, サッカー 0.35, すっぱい 0.33, さっか 0.33, いっぽん 0.31, きっぷ 0.30. けっこん will be heard as two words, and the sokuon is itself a contrastive length this deck teaches. |
| F9 | Medium | The stated tempo target is not met, and neither the gate nor the survey notices | `voice.py` sets the goal at "roughly 0.20 to 0.25" voiced s/mora. Shipped: **median 0.138, mean 0.145, 4.6% inside the band, 88.2% under 0.18** — the same numbers the comment cites as the running-speech baseline it set out to escape (0.140, 96% under 0.18). The clips *are* genuinely 1.45× slower than sentences by articulation span (0.182 vs 0.118 s/mora; matched by mora count the ratio is 1.35–1.45), so the render worked and the target was simply unreachable at `WORD_LADDER[0] = 1.45`. Either the target or the release note is wrong; nobody reconciled them. |
| F10 | Low | The gate passes on an exact tie, not with margin | `bad` requires `r[0] < 0.090`. The worst non-exempt clip, つち, measures 0.18 s voiced over 2 morae = **exactly 0.090**, and `0.09 < 0.09` is False. The two clips actually below the floor — ひとつ 0.070, ふうふ 0.087 — are waived by the `MAX_SEC_PER_MORA` escape hatch, and ひとつ is itself an F1 outlier (shipped 1.071 s against a draw median of 0.708 s, longer than all 10 fresh draws). "0 clips under the floor" is one rounding step from "1". |
| F11 | Low | `trim` leaves up to 0.58 s of near-silent tail | `TRIM_DB` is −45 dBFS **absolute**, so a clip whose noise floor sits above it keeps it. Tail above −45 dBFS but more than 30 dB below peak: median 0.14 s, but なくす **0.58 s**, いつつ 0.54 s, くつろいで 0.45 s, けいさつ 0.43 s; 30 word clips exceed 0.30 s. The stated goal of removing "about a third of a second of room tone at each end" is only partly met on these. |

### The through-line

F1 is the one to fix first, because F2, F3, F7, F8 and F10 are all downstream
of it. Keeping the longest of N draws is extreme-value selection on a noisy
metric: it does not make the library better, it makes the library the 90th
percentile of itself, and the 90th percentile of this voice is where it
babbles, stutters and holds vowels. Scoring the shipped result with the same
`voiced()` the selector maximised cannot detect that — the gate and the
renderer are the same optimiser pointed at each other. A gate that would have
caught F2 and F3 has to measure something the renderer is *not* trying to
maximise: nuclei against morae, end level against peak, internal silence
against the sokuon inventory.

---

## What I verified as sound

- **Sprite integrity is clean.** All 9,049 planned keys are present in the
  indices; no orphan keys, no overlapping or gapped byte ranges, every index's
  extent equals its `.mp3` size exactly, and all 26 stored signatures recompute
  correctly from `plan()`. No sprite has holes.
- **No clip is silent, empty or truncated to nothing.** Every one of the 9,049
  decodes to audio; the shortest is `wj:c0236` を at 0.31 s, which is plausible
  for one mora.
- **No key serves another key's recording.** sha1 over the clip bytes gives
  9,049 distinct blobs for 9,049 clips — no duplication, no cross-wiring, and
  clip lengths track mora counts across the library.
- **The trailing `、` leaves no pause and no artefact.** ん-final word clips
  carry a median 0.110 s of trailing room tone against 0.120 s for other words,
  and their longest internal silence is *shorter* than the control population
  (3.3% ≥ 0.15 s vs 10.3%). `trim` removes the comma's pause exactly as
  intended, and there is no re-onset after it.
- **The nasal mechanism is the right mechanism where it fires.** Δ +14.7 dB
  median on ん-final words against +1.8 dB on the general word population and
  +2.0 dB on う-final, with a median 90 ms of periodic murmur at ~0.88
  autocorrelation. Sentences — which end in 。 and were never given a suffix —
  show the same effect (Δ +13.3 dB, 90.5% clearing +6 dB), which independently
  confirms that phrase-final punctuation is what produces the nasal. The idea
  is sound; F4 and F5 are about coverage, not about the idea.
- **Nothing starts abruptly.** Zero clips begin within 12 dB of their peak with
  under 40 ms of lead-in. Minimum leading room tone library-wide is 0.02 s,
  p1 0.05 s. Whatever trimming cost, it did not cost onsets.
- **The word/sentence tempo split is intentional and correctly implemented.**
  Matched by mora count, word clips run 1.35–1.45× slower than sentences —
  exactly `WORD_LADDER[0] / LADDER[0]`. Hearing a citation-tempo word and then
  a conversational sentence is a deliberate pedagogical choice and reads as
  one, not as a defect. The audible inconsistency between sentences is F6's
  leading silence, not tempo.
- **English is consistent.** Leading room tone is 0.08–0.09 s in `w-*`, `s-*`
  and `p-000` alike, so the half-trimmed state in F6 does not reach the English
  side and the spoken prompts match the word clips they sit next to.
