# Council review — Curriculum seat
**Kana Ladder, build of 2026-09-15. Reviewed against Ryan's trip on 2026-11-30 (76 days).**

## Verdict

**NOT APPROVED** — at his chosen budget the deck's introduction order stops 20 words short of "ticket", "right", "left", "straight ahead" and "to go", strands 27 of 40 conjugation anchors and 111 of 201 transactional sentences, and the fix costs nothing but a re-sort of the `ord` field.

---

## 1. What he will actually have seen by 30 November

76 calendar days. `newAllowance()` returns 0 inside `TAPER_DAYS = 10`, so there are only **66 new-word days**, not 76. Sentences and conjugation cards are *not* tapered (`sentLeft`/`conjLeft` check `S.daily.noNew` only), so they run all 76.

Simulated day by day with his settings (FSRS-6 good-path intervals 1/3/8/21/50/120, 10% lapse at 0.90 retention, `sentOpen` gate with one-word gap, `CONJ_GATE` of 3 days):

| Scenario | Words | Sentences | Conj anchors | Follow-ups served | Follow-up backlog at departure | Mean reviews/day | Peak | Days at 150 cap |
|---|---|---|---|---|---|---|---|---|
| Soft floor, 4/day | **264** / 1811 | **299** / 1442 | **13** / 40 | 608 | **215** | 64 | 86 | 0 |
| 5 / 5 / 2 / 8 | **330** | **374** | **27** / 40 | 608 | **416** | 72 | 104 | 0 |
| With easy days, ≈6/day | **396** | **379** | **35** / 40 | 608 | **548** | 76 | 107 | 0 |

Three things fall out of this table.

**The 150 review cap is never touched.** Peak load is 86–107. He is running at 57–71% of his own stated ceiling for the entire 76 days. There is room for roughly 40 more reviews a day, which is about 3 more new words a day, and nothing in the curriculum is claiming it.

**Sentences are budget-bound, not gate-bound.** The unlock curve is far ahead of the intake:

| Words known | Sentences open | Sentences he can consume |
|---|---|---|
| 264 | 502 | 299 |
| 330 | 693 | 374 |
| 396 | 847 | 379 |
| 1811 | 1442 | ~380 max |

So ~1,060 of 1,442 sentences are dead weight for this trip regardless of anything else. The order they are served in (`SENT_RANK`, the rank of the second-latest word) is therefore the whole ballgame, and it is currently a *difficulty* order, not a *usefulness* order.

**The follow-up budget of 8/day is structurally below the generation rate.** At 5 words + 5 sentences a day the app generates 5 produce-it cards + ~5 listening cards + 5 sentence-listening cards = **15/day** against an allowance of 8. `consAllowance()` in `auto` would compute `max(2, ceil(5 × 2)) = 10`/day with a backlog drain up to 20/day. His manual **8 is below the app's own floor**. Result: 416 follow-up cards never served — roughly 40% of the words he meets exist only as recognition, never as production and never as listening, on a trip where listening is the task.

### Missing from the reachable set

At the 4/day soft floor the frontier lands at rank 264, and the transport/direction block begins at rank 266. Everything below is *inside the deck* and *outside his reach*:

| Rank | Word | Meaning |
|---|---|---|
| 267 | chikatetsu | subway |
| 269 | nimotsu | luggage |
| 272 | shinkansen | bullet train |
| 273 | saifu | wallet |
| 276 | chizu | map |
| **277** | **kippu** | **ticket** |
| 278 | kurejittokaado | credit card |
| 282 | seki | seat |
| **283 / 288 / 293** | **migi / hidari / massugu** | **right / left / straight ahead** |
| **310** | **iku** | **to go** |
| 318 | bansen | platform-number counter |
| 335 / 340 / 345 / 355 / 360 | iu / yomu / kaku / suru / aru | say / read / write / do / exist |
| 341–366 | ue, shita, naka, soto, tonari, michi | above, below, inside, outside, next to, road |
| 358 | hikouki | airplane |
| 359 | okaikei onegaishimasu | the check, please |
| 497 | kaisatsu | ticket gate |

He can say "Happy New Year" (rank 206) and "welcome home" (rank 182) but cannot say "one ticket" or "turn left". There is also **exactly one word tagged `emergency` in the whole 1,812**: `mitsukaru`, "to be found", at rank 400 — outside his reach, and not an emergency word.

### Waste inside the reachable set

70 of the first 330 cards (21%, ≈16 days of intake at 4.5/day) earn little or nothing on a two-week trip:

| Group | Cards | Ranks |
|---|---|---|
| Day-of-month irregular readings (tsuitachi…hatsuka) | 12 | 103–158 |
| Seasonal/ceremonial greetings (Happy New Year ×3, Merry Christmas, happy birthday, congratulations ×2, long time no see, welcome) | 9 | 186–210 |
| Redundant casual goodbyes (jaa ne, mata ne, mata ashita, baibai, mata raishuu, doumo, oyasumi ×2) | 8 | 157–191 |
| Specific o'clock / minute instances (yoji, shichiji, kuji, ippun, sanpun, juppun, shichi) | 7 | 51–112 |
| Days of the week | 7 | 68–98 |
| Compound-number instances (sanbyaku, roppyaku, happyaku, sanzen, hassen, ichiman) | 6 | 86–111 |
| Household rituals (tadaima, okaerinasai, ittekimasu, itterasshai, ojama shimasu) | 5 | 177–204 |
| Classroom meta-phrases | 5 | 173–200 |
| Workplace phrases (osaki ni shitsurei shimasu, otsukaresama, ganbatte, ganbarimasu) | 4 | 170–199 |
| Mis-tiered oddities: `e` "picture" (tier 6, **rank 20**), `ima` "living room" (tier 4), `jitsu wa`, `kazeohiku` | 4 | 20–281 |

The twelve day-of-month readings are the single worst line item: tiers 3–4, the most failure-prone readings in beginner Japanese, occupying ranks 103–158 for a man whose phone will show him the date in digits. 12 words × 3 directions = 36 scheduled cards.

Conservatively **42 of these are clear waste** and 20 more are marginal. 42 cards is 9–10 days of his entire intake.

### Data defects inside the reachable set

Five romaji collide inside the first 330, and `soundIsAmbiguous()` strips the listening card from **both** halves of each pair:

| Pair | Ranks | Cost |
|---|---|---|
| `ni` (two) / `ni` (particle) | 15, 49 | unavoidable |
| `e` (picture, tier 6) / `e` (direction particle) | 20, 74 | the particle loses listening **because of a tier-6 word placed 21st** |
| `ima` (living room) / `ima` (now) | 281, 284 | "now" loses listening because of a tier-4 word |
| `atsui` (weather) / `atsui` (touch) | 296, 297 | unavoidable |
| `kaeru` (return) / `kaeru` (change) | 300, 305 | avoidable by separating them |

Deleting two low-value cards (`e` picture, `ima` living room) restores listening cards to two high-value ones. Also: `kazeohiku` (rank 171) should be `kaze o hiku`; `okaikei onegaishimasu` (359) is spaced inconsistently with `okanjou onegai shimasu` (205) and duplicates its meaning.

---

## 2. Is the `ord` order sensible for a traveller?

**Directionally yes, then it breaks at exactly the wrong moment.** 204 of the first 264 words carry a trip-relevant tag; only 3 are clearly off-topic. The frame (particles, counters, demonstratives, desu/arimasu patterns) is well chosen and front-loaded, and the emergency-adjacent words are early (`tasukete` 139, `keisatsu` 63, `kyuukyuusha` 95).

The failure is the **block at ranks 165–211**: a 47-card run of social phrases of which roughly 30 are ceremonial, household, workplace or classroom — Happy New Year, Merry Christmas, welcome home, I'm off, have a good day, thanks for your hard work, excuse me for leaving first, excuse me for intruding, congratulations, happy birthday, it's been a long time — introduced **before a single transport word**. (The genuinely transactional members of that run — *toire wa doko desu ka* 189, *ikura desu ka* 190, *irasshaimase* 193, *shoushou omachi kudasai* 208, *okanjou onegai shimasu* 205 — are exactly the ones that should have kept the slots.) `pasupooto` is rank 214. `eki` is 239. `kippu` is 277.

**Too late:** kippu (277), migi (283), hidari (288), massugu (293), iku (310), bansen (318), hanasu (330), iu (335), suru (355), aru (360), michi (363), hikouki (358), okaikei (381), kaisatsu (497), `ii desu` "that's fine" (930), `totemo` "very" (859), `namae` "name" (797 — while "what is your name" is at 151), `kekkou desu` "no thank you" (1204).

**Too early:** `e` picture (20, tier 6), `shichi` (51), the four named o'clock cards (65–75), the six compound-number cards (86–111), the twelve day-of-month readings (103–158), the whole 176–211 ceremonial block, `jitsu wa` (211, tier 6).

---

## 3. Does the example-per-word feature change what he learns?

**Partly decoration, partly actively wrong, and the wrongness is in code rather than in the data.**

Integrity is clean at the data layer: 1,812 examples for 1,812 words, 1,446 references all resolving, 366 inline triples, no orphans either way.

**Defect — inline examples render the wrong fields.** `deck/examples.json` stores inline examples as `[kana, romaji, english]`. `exampleFor()` in `app/index.html` (~line 3500) reads:

```js
return (e[0] && e[1]) ? {romaji: e[0], en: e[1]} : null;
```

`e[0]` is **kana** and `e[1]` is **romaji**. So every one of the 366 inline examples prints Japanese script in the romaji slot and romaji in the English slot, and the English (`e[2]`) is never shown at all. Ryan cannot read kana. Twelve of these are inside his reachable set, including the cards for `okanjou onegai shimasu` ("the check, please", rank 205) and `kore wa nan desu ka` (rank 150) — two of the most useful cards in the deck, each showing him a line he cannot read and a gloss that is not English. The fix is `{romaji: e[1], en: e[2]}`.

**For the 252 reference examples inside the 4/day reachable set:**

| Measure | Count | Share |
|---|---|---|
| Points at a sentence he *will* study before the trip | 140 | 56% |
| Points at a sentence he will **never** study | **112** | **44%** |
| Points at a sentence containing ≥1 word he never learns | 159 | 63% |
| Sentence is not readable at the moment the word arrives (SENT_RANK > word rank) | 114 | 45% |
| Sentence is 100+ ranks ahead of the word | 82 | 33% |
| Sentence is 500+ ranks ahead of the word | 35 | 14% |
| Referenced sentence does not contain the word at all | 3 | 1% |

Mean lead is **+140 ranks**. The worst cases are on the earliest cards, where it matters most:

| Word | Its rank | Example sentence | Sentence rank |
|---|---|---|---|
| `kono` "this ~" | **3** | *kono isu wa totemo karui desu* | 859 |
| `ano` "that ~ over there" | 13 | *ano otoko no ko wa juuyon sai desu* | 945 |
| `mo` "also" | 14 | *inu mo suki desu* | 849 |
| `are` "that one" | 28 | *are wa atarashii biru desu* | 853 |
| `ga imasu` | 37 | *niwa ni inu ga imasu* | 849 |
| `soshite` | 104 | *yoku kiite kudasai. soshite, kore o yonde kudasai.* | 1109 |
| `dekiru` | 255 | *kantanni dekiru node, tameshite mite kudasai.* | 1404 |

On day one, the fourth word he meets is illustrated with a sentence built from three words he will never be taught. Since `exampleFor()` applies no `sentOpen()` filter — unlike `sentenceWith()`, which explicitly refuses a cloze whose other words are unknown, with a comment explaining exactly this failure — the example box reintroduces the bug that the cloze picker was fixed for.

**Verdict on the feature:** where the reference lands near the word it is genuinely useful; in 45% of cases it is a translated romaji string with unknown vocabulary in it, which is comprehensible but not reinforcing. It is not currently changing what he learns. Constraining the reference to `SENT_RANK ≤ word rank` would make it do so, and the deck has the supply to satisfy that constraint.

---

## 4. The conjugation track is the quietest failure

| Measure | Value |
|---|---|
| Anchor cards in existence | **40** |
| Budget slots over 76 days at 2/day | 152 (3.8× oversupplied) |
| Anchors whose base verb is beyond rank 264 | **27 of 40** |
| Anchors reachable at 4/day | **13 of 40** |
| Anchors reachable at 5/day | 27 of 40 |
| Form variants in `forms.json` | 2,530 across 438 words |
| Form variants drillable inside a 297-word vocabulary | **164 (6.5%)** |

The base verbs cluster at exactly the wrong ranks: `kaeru` 300, `iku` **310**, `kuru` 315, `miru` 320, `kiku` 325, `hanasu` 330, `yomu` 340, `kaku` 345, `suru` **355**. Add `CONJ_GATE = 3` days of held interval and a verb learned at rank 310 does not unlock its anchor until roughly day 82 — after the flight. **At his soft floor he never learns `ikimasu`.** He will learn `nonde` and `tabete` and `oyoide` ("swimming", base rank 1201, which never unlocks anyway) and not "I go".

The form mix is also wrong for the task: 12 of 40 anchors are te-form, while `masu` (8), `mashita` (5), `masen` (5) and `tai` (2) — the forms in a counter transaction — total 20. There is no anchor on the polite past negative at all, despite 17 sentences tagged `polite-past-negative`.

---

## 5. What he can actually say

201 sentences carry `say: true` — the transactional lines the app asks English-to-Japanese, described in the source as "the target task".

| Words known (current order) | Transactional sentences open |
|---|---|
| 264 (his floor) | **116 / 201** |
| 330 | 143 / 201 |
| 400 | 169 / 201 |

**At his floor, 111 of 201 transactional sentences are never read.** A sample of what he never reaches:

- *kono densha wa kuukou e ikimasu ka* — "Does this train go to the airport?"
- *kuukou made ichimai onegai shimasu* — "One ticket to the airport, please."
- *kuukou ni iku hoomu wa doko desu ka* — "Which platform goes to the airport?"
- *kurejittokaado de haraemasu ka* — "Can I pay by credit card?"
- *zenbu de ikura ni narimasu ka* — "How much altogether?"
- *konbini wa kono chikaku ni arimasu ka* — "Is there a convenience store near here?"
- *chotto mite iru dake desu* — "I'm just looking, thank you."

The words blocking them are not exotic. 281 distinct words feed all 201 sentences; 118 are inside his reach and 92 sit beyond rank 500. The highest-leverage blockers:

| Blocks | Rank | Word |
|---|---|---|
| 19 sentences | **930** | `ii desu` — "that's fine" |
| 12 | 1148 | `sumu` — to live |
| 11 | 360 | `aru` — to exist |
| 8 | 355 | `suru` — to do |
| 5 | 365 | `iru` — to be (animate) |
| 4 | 892 | `shashin` — photograph |
| 3 | 1204 | `kekkou desu` — "no thank you" |
| 2 | 859 | `totemo` — very |
| 2 | 797 | `namae` — name |

---

## Recommendations, ranked

### 1. Re-sort `ord` so the words behind the 201 transactional sentences come first. *(the single highest-value change still not done)*
A greedy re-order, holding the daily budget exactly as it is, gives:

| Extra words pulled forward | Transactional sentences open |
|---|---|
| 0 (today) | 116 / 201 |
| 10 | 154 / 201 |
| 20 | 171 / 201 |
| 30 | 181 / 201 |
| 40 | 191 / 201 |
| **50** | **199 / 201** |

The first ten alone are `ii desu`, `suru`, `aru`, `iku`, `yonde kudasai`, `seki`, `karai`, `nimotsu`, `shashin`, `kyou`. Cutting the 42 clearly-wasted cards identified above **pays for the first 42 of these at zero change to his daily rate, zero change to review load, and zero new content.** Nothing else on this list comes close: it takes him from being able to say 58% of the target sentences to 99%, by editing an integer field.

### 2. Delete or demote the 42 waste cards, starting with the twelve day-of-month readings.
They are the hardest-to-retain items in the reachable set and they buy nothing a phone screen does not already show. Deleting `e` (picture) and `ima` (living room) additionally restores listening cards to the direction particle `e` and to `ima` ("now") by breaking two homophone collisions.

### 3. Move the conjugation base verbs — `iku`, `suru`, `aru`, `iru`, `miru`, `kiku`, `hanasu` — inside rank 200, and rebalance the anchors toward `masu`/`mashita`/`masen`/`tai`.
Otherwise the 2-a-day conjugation budget spends 76 days serving 13 of 40 cards while "I go", "I do" and "there is" go untaught. Also lower `CONJ_GATE` for the last three weeks, or the gate alone pushes late-unlocking anchors past the flight.

### 4. Fix `exampleFor()`: `{romaji: e[1], en: e[2]}`.
One-line fix. Today 366 cards show kana where romaji belongs and romaji where English belongs, and 12 of them are cards he will actually see.

### 5. Constrain the example reference to a sentence he can read when the word arrives.
Require `SENT_RANK[ref] <= ord-rank of the word`, falling back to the inline triple. 45% of in-reach examples currently violate this, including `kono` at rank 3. `sentenceWith()` already enforces the equivalent rule for clozes; the example box should inherit it.

### 6. Set follow-ups to `auto`, or to at least 12.
8/day is below the app's own computed floor of 10 and roughly half the generation rate of 15/day. It leaves 416 produce-it and listening cards unserved at departure — on a trip where speaking and listening, not recognition, are the whole point. The review cap has 40+ reviews/day of headroom to absorb this.

### 7. Raise the word rate to 7–8/day, or cut the taper from 10 days to 5.
Peak review load is 107 against a 150 cap. The taper alone costs 10 days × his rate = 40–50 words, and it fires precisely over the window that would otherwise deliver the transport block. A 5-day taper plus 7/day yields ~497 words — enough, under the current order, to reach `kaisatsu` and the whole directions set without any re-sort. This is the brute-force alternative to recommendation 1 and is strictly worse than it, but it is available if the ordering is frozen.

### 8. Add an emergency micro-set.
The deck contains one `emergency`-tagged word and it means "to be found". `tasukete` (139) and `kyuukyuusha` (95) are early and good, but there is no *kaji* (fire), *dorobou* (thief), *abunai* (dangerous), *ugokanaide* (don't move), no "I have an allergy to ~" frame beyond the bare noun `arerugii` (227), and no "please call an ambulance" transactional line inside his reach. Six cards would close this.
