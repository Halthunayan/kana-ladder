# Council seat: RELEASE RISK — Kana Ladder, audio re-render + worked examples build

**VERDICT: NOT APPROVED as it stands.** The code paths are sound and nothing threatens his review history, but the sprite set is only ~2/15 re-rendered, the manifest still names the old files, and nothing in CI can see a half-published audio library — ship only after the conditions in §7 and the ordered procedure in §8.

---

## 1. Answers to the five questions

### Q1 — New manifest, old files in `kana-audio-v1`. What happens?

**He re-downloads 15 sprites, not 26 and not nothing. Roughly 28–30 MB, and the old 37.7 MB is deleted *before* a single new byte arrives.**

The mechanism is `audPrune`, `/home/claude/build/app.core.js:2294-2306`. It runs on every successful manifest fetch (`audManifest` → `.then(function(m){ AUD.man=m; audPrune(m); return m; })`, line 2285). It builds a `live` set of `<contenthash>.mp3` / `.json` basenames from `m.files`, walks every key in `kana-audio-v1`, and deletes anything under `audio/v1/` whose basename is not in that set.

`audManifest()` is called unconditionally at boot (`app.core.js:4007`, `if(audOn()) audManifest().catch(...)`). So this happens on the **first launch after deploy, before he touches anything**.

Sequence on his phone:

1. Boot. `fetch("audio/v1/manifest.json", {cache:"no-store"})`. `sw.js` has a dedicated network-first branch for exactly this file, so it goes to the network.
2. New manifest lands. `audPrune` deletes **10 `w-*` + 5 `f-*`, both `.mp3` and `.json`** — every old word and conjugation sprite.
3. The 10 `s-*` sentence sprites and `p-000` keep their content-addressed names, so they are in `live` and **survive untouched**.
4. Nothing re-downloads eagerly. Re-acquisition is lazy: `audPreload` at car-mode start is capped at `AUD_PRELOAD_MB = 8` (line 2434), or he taps Download in settings (`audDownload`, line 3698) which fetches all of `audAllSprites()`.

Bytes, from `/home/claude/pwa/audio/v1/manifest.json`:

| | sprites | bytes | |
|---|---|---|---|
| `w-000..w-009` | 10 | 19,593,470 | **deleted, must re-download** |
| `f-000..f-004` | 5 | 18,086,728 | **deleted, must re-download** |
| `s-000..s-009` | 10 | 23,658,177 | kept |
| `p-000` | 1 | 73,847 | kept |
| total | 26 | 61,412,222 (58.6 MiB) | |

Deleted: **37,680,198 B = 35.9 MiB ≈ 37.7 MB.**

The two new renders that exist in this container give the size ratio: `f-000` 2,205,436 → 1,696,791 (0.769), `f-001` 2,933,270 → 2,321,073 (0.791). Silence-trimming outweighs the slower speech. Extrapolated, the 15 new sprites are **≈ 29 MB (range 28–30, worst case 37.7 MB if the `w-*` renders do not shrink)** over his mobile connection, as **30 HTTP requests** (`.mp3` + `.json` per sprite, `audLoad`, line 2311).

**Design note in the build's favour:** prune-deletes-first is deliberate and correct. `audPrune`'s own comment names the failure it prevents — on iOS, overflowing the origin quota evicts *everything*, the app shell included. Holding 37.7 MB of dead sprites while pulling 29 MB of new ones would push the bucket to ~90 MB. Prune-first caps the peak. Do not "fix" this.

**The real hazard this creates.** Between step 2 and the re-download he has **no word and no conjugation audio at all** — device TTS only, which per the code comments does not reach CarPlay. The manifest is 3 KB; the sprites are 29 MB. A link good enough for the first is not good enough for the second. If the new manifest lands at the start of a drive on a marginal signal, the prune fires, the library is gone, and the drive falls back to device voices while fetching at the roadside. Offline is safe — `audManifest` falls back to the cached old manifest and prune keeps the old files — but *weakly online* is the bad state, and that is his normal state in a car.

**Second-order:** the settings line (`renderAudNote`, line 3684) will read "**22.6 MB downloaded of ~52 MB available**" immediately after the first launch. That is alarming and correct. Tell him it is expected.

**Third-order:** `audDownload` does `Promise.all(list.map(audLoad))` over all 26 sprites and keeps every `ArrayBuffer` in `AUD.loaded`. That is ~52 MB of JS heap held simultaneously on an iPhone. Pre-existing, but this build *guarantees* he exercises it.

---

### Q2 — Partial audio upload, manifest live, some sprites missing

**Traced precisely, and the answer has a surprise in it that makes the whole thing safer than it looks — plus one hole CI cannot see.**

**The surprise: pushing audio to the repo does not publish anything.** `.github/workflows/build.yml` fires on `push` with `paths:` restricted to `src/**`, `sw.js`, `manifest.webmanifest`, `icons/**`, `.github/workflows/build.yml`. **`audio/**` is not in that list.** GitHub Pages here is published by `actions/deploy-pages@v4` from a `_site` tree assembled at deploy time (`cp -r audio icons _site/`). So uploading sprite files — or even the new `manifest.json` — changes the live site **not at all** until some *other* thing triggers a deploy. Batch uploads are inert by construction.

**What happens if a deploy does fire mid-upload** (a `workflow_dispatch`, or the `src/**` push that carries the page change):

1. `assemble the site` copies whatever is in `audio/` at that SHA. The only audio assertion is `test -f _site/audio/v1/manifest.json` — **existence of the manifest, nothing about the files it names.**
2. Phone boots, fetches the new manifest, `audPrune` deletes **all 15** old `w-*`/`f-*` — not just the ones that were replaced, because *none* of them is named in the new manifest.
3. `audLoad("w-007")` → `audFile` returns the new hash → `audFetch("audio/v1/w-007.<newhash>.mp3")`. `sw.js` audio branch: cache miss → `fetch` → **404**. `res.ok` is false so it is *not* cached (good), the 404 Response is returned, `audLoad` hits `if(!r||!r.ok) throw 0` → `.catch` → `null`.
4. `audLoad` then does `delete AUD.want[sprite]` — a miss is not remembered, so every subsequent card retries. Correct behaviour, but it means a **404 per card, per attempt, for the whole drive**, each one paying the 8-second `AUD_WAIT` race before the device voice takes over. `audPlay` returns `false`, `carSay` falls through to `carSpeak`. **No crash, no data loss — just silent degradation to device TTS with an 8-second stall in front of every affected word.**
5. **Nothing self-heals until the missing file is uploaded.** The old file it replaced is already gone from the phone and from nowhere recoverable except the repo.

**The hole:** `.github/workflows/build.yml` verify job runs `src/tests/live_check.js` (`/home/claude/app/live_check.js`). Its audio check fetches the manifest and then probes **`man.files['w-000']` only** — one sprite. A publish where `w-000` uploaded and `w-007` did not **passes verify**. There is no manifest↔files existence check anywhere in the pipeline.

**Is there a safe upload order that makes this impossible? Yes, and it is free.** Because the manifest is the only file that maps names to content, a sprite file that nothing names is harmless. So:

> **Upload every new sprite file first. Update `audio/v1/manifest.json` last, and never in the same push as anything that triggers a deploy.**

Until the manifest names them, the new files are dead weight in the repo — copied to `_site` and never requested. The moment the manifest names them they are all already there. Interruption at any point before the manifest edit leaves the site fully consistent and old. Interruption after it is impossible, because the manifest edit is one atomic file write.

The one remaining window is *manifest committed → deploy not yet run*: a latent commit that some unrelated future deploy would publish. §8 closes it by making the manifest the second-to-last step with the deploy immediately after, and by publishing the page first.

---

### Q3 — Do the rewritten glosses disturb scheduling or history?

**Not the data. Possibly the outcomes, and there is one audio coupling nobody has checked.**

**Data: clean.** Every persisted structure is keyed by card id, never by gloss text:

- `LS_KEY = "kanaladder.v1"` (line 50), `SCHEMA = 6` (line 231) — unchanged by this build.
- `packAll` / `applyBlob` (lines 232-256): `S.items` keys are `id|j`, `id|a`, `id|e`; `applyBlob` re-admits a key only if `IDX[k.split("|")[0]]` exists. Card ids do not change, so every item survives.
- `S.hist` keyed by day, `S.notes`/`S.susp`/`S.pfail`/`S.crep`/`S.carSeen` keyed by id or `id|suffix`, `shardOf` (line 500) hashes `IDX[id]._i`. No gloss anywhere.
- `loadLocal` does not gate on schema at all; only the *file importer* checks it (`validateBlob`, line 258). Schema is not moving, so neither path matters.

**Build gates: strong.** `/home/claude/build/build.py` asserts gloss uniqueness three ways before a page is ever produced — exact normalised match (line 48), word/sentence pooled match (line 61), and word-set match ignoring order and articles (line 77). A rewrite that collides with another gloss **fails the build and never deploys**. The `set -eu` step means the job dies. This is the single best-protected part of the change.

**Runtime: one soft edge.** `distractors()` (line 946) dedupes on `sense(x)` = text before the first `/ , (`, lowercased, leading article stripped. `makeQuestion` returns `null` if fewer than 3 distractors survive (`if(d3.length<3) return null`). A rewritten gloss whose *first sense* now matches a neighbour's could starve a card of options. `focusQueue` handles `null` gracefully (line 1098 tries the next type; line 1119 falls back to `flipJ`), so the card degrades to a flip rather than breaking — but the build's three asserts normalise more aggressively than `sense()` does, so a collision that passes the build and still trips `sense()` is possible. Low impact, worth knowing.

**Learning outcome: real, and unavoidable.** `mcEJ` and the typed `produce` block prompt with `c.en` (lines 1014-1015, 3122). 22 cards will show him a prompt he has not seen before. Some will be answered wrong, and a wrong answer is a genuine lapse that demotes the interval. **He should expect a small cluster of failures on those 22 cards in the days after this ships, and that is the schedule working correctly, not a bug.** Do not let him "fix" it by resetting anything.

**The coupling nobody has checked — flag this hardest.** `tools/voice.py:223` renders the English clip from the deck: `add(sp, 'we:'+c['id'], 'en', c['en'], 'en')`. Those `we:` clips live in the **`w-*` sprites** (`audSpriteFor`, line 2239: `if(kind==="wj"||kind==="we") return "w-"+...`). Car mode calls `carSay(c.en, "en", 1.0, "we:"+it.id)` (lines 2686, 2690, 2703) and `carSay` **prefers the sprite clip over the text** (line 2635-2639).

So: **if the `w-*` sprites were re-rendered from a `deck_full.json` that predates the 22 gloss rewrites, car mode will speak the old gloss for those 22 words while every screen shows the new one.** The clip index keys are unchanged, the sprite loads, `audPlay` returns `true`, and nothing anywhere detects it. The only symptom is him hearing the wrong English in the car.

Locally the ordering looks right — `deck/deck_full.json` is 19:45, `f-000.9dd8d1c0` is 19:53 — but **the `w-*` renders must be confirmed to postdate the gloss edit.** This is a hard precondition, not a nice-to-have.

---

### Q4 — Is there a migration step, and what breaks without it?

**No migration exists and none is needed. Three things he should do anyway; one of them is close to mandatory.**

- **No schema change.** `SCHEMA = 6` on both sides, `LS_KEY` unchanged, `applyBlob` tolerates unknown fields (`// extra trailing fields are ignored, never fatal`, line 254) and short arrays. Nothing to migrate.
- **No user action to get the new build.** `sw.js` calls `skipWaiting()` on install and `clients.claim()` on activate; `app.core.js:4033-4039` listens for `controllerchange` and, when a controller already existed, calls `saveLocal()` and then `location.reload()`. He gets the new page automatically, with his state flushed to `localStorage` first. If it fires mid-review he sees one reload; he loses nothing.
- **Audio re-download is effectively mandatory** (§Q1). Not a migration, but if he skips it his first drive after this ships has no pre-rendered word or conjugation audio. **Tell him: open the app on wifi, go to settings, tap Download, wait for "Voice downloaded", confirm the line reads ~52 MB of ~52 MB. Then drive.**
- **Take a backup first.** Not because this build endangers it — it does not — but because the deploy forces a service-worker turnover and a reload, and a backup is one tap. `packAll` → Download in settings.

**One latent fragility worth naming:** `app.core.js:12` is `var EXAMPLE = JSON.parse(document.getElementById("example-data").textContent);` at top level, unguarded. If that `<script type="application/json" id="example-data">` were ever missing, the *entire app* throws at boot — white screen. CI's `guard against a build that lost the audio or the deck` greps for `id="deck-data"` and `id="sent-data"` but **not `id="example-data"`.** `build.py` always emits it, so probability is low, but this build is the one that introduces the dependency and the guard was not extended. One-line fix; recommend it.

Also: the build guard `test "$(stat -c%s src/pwa/index.html)" -gt 1000000` is a **floor only**. The brief says the page goes "from about 1.28 MB to about 1.20 MB" — a *shrink* of ~80 KB while *adding* one worked example per word. That is internally inconsistent (the built `pwa/index.html` here is 1,293,391 B). Either the figure is wrong or ~80 KB of content was silently dropped, and the size guard cannot tell the difference. **Reconcile the number before shipping.**

---

### Q5 — Rollback: how fast, and what does he lose?

**Fastest path: GitHub → Actions → the last known-good run → "Re-run all jobs".** `actions/checkout@v4` on a re-run checks out that run's original SHA, so the build, the `audio/` tree and `sw.js` all revert together and consistently. No source editing, no revert commit, no risk of a half-reverted `src/`. This matters because `index.html` is *generated* — reverting it by hand through the web UI is not possible; he would have to revert `src/deck/deck_full.json`, `src/deck/examples.json`, `src/build/app.core.js`, `src/build/body.html` and `src/build/style.css` individually and hope he got them all.

**Wall clock: ~8–14 minutes.** build ≈ 1 min, test job installs Playwright + Chromium (~2–4 min) then runs two suites, deploy ≈ 1–2 min, verify installs Playwright *again* (~2–4 min) and sleeps 15 s. `concurrency: group: pages, cancel-in-progress: false` means it queues behind any in-flight deploy rather than racing it. Then **one app launch on his phone** for the service worker to turn over.

**What reverts cleanly:**
- The page. `sha1(index.html)` returns to the old value, `sw.js` gets `CACHE = "kana-ladder-<oldhash>"`, install caches the old shell fresh, activate claims, `controllerchange` reloads. Cost: one ~1.2 MB page download.
- All scheduling, history, notes, streaks, lifetime stats. `SCHEMA` does not move and `loadLocal` has no version gate, so an older build reads the same `localStorage` blob unchanged. **He loses nothing.** (Confirm the good build is also `SCHEMA = 6` before rolling back — it is today, but check.)

**What rollback costs him — this is the expensive part.** The old manifest returns, `audPrune` runs again, and now the *new* 15 sprites are the ones not named. They are deleted and the **old 37.7 MB is re-downloaded**. A ship-then-rollback cycle is therefore **~29 MB down, then ~38 MB down again — roughly 67 MB of mobile data** and two windows with no word audio.

**This is only true if the old sprite files are still in the repo.** `assemble the site` copies `audio/` wholesale and the phone's cache is content-addressed, so keeping the 15 superseded files costs one extra ~38 MB in `_site` (Pages limit is 1 GB) and buys an instant, complete audio rollback. **Do not delete the old sprites in the same change. Leave them for at least a week.**

**What has no rollback:** nothing. There is no destructive migration, no irreversible state change, and no write to his history that this build performs.

---

## 2. Findings, most severe first

| # | Sev | Finding | Where | Consequence | What to do |
|---|---|---|---|---|---|
| 1 | **Blocker** | The re-render is not finished. Only `f-000.9dd8d1c0` and `f-001.8542815c` exist as new renders; `f-002/003/004` are still the Sep 14 originals with no new sibling, and the manifest still names all 15 old files. | `/home/claude/pwa/audio/v1/`, `/home/claude/pwa/audio/v1/manifest.json` | 2 of 15 changed sprites are ready. Shipping now publishes a manifest that names files that do not exist. | Finish all 15 renders with `tools/voice.py`, then re-run `tools/audio_check.py`. |
| 2 | **Blocker** | Nothing in the pipeline checks that every file named in the manifest actually exists. `assemble the site` only does `test -f _site/audio/v1/manifest.json`; `live_check.js` probes `man.files['w-000']` and nothing else. | `.github/workflows/build.yml`; `/home/claude/app/live_check.js` | A partial publish passes CI and verify. Phone prunes all 15 old sprites, then 404s on the missing new ones, with an 8 s stall per affected card, for the whole drive. | Before the manifest push, list `audio/v1/` in the GitHub UI and confirm all 26 `.mp3`+`.json` pairs named in the new manifest are present. Extend `live_check.js` to loop `Object.values(man.files)` — a HEAD per file, 26 requests. |
| 3 | **High** | `we:` English clips are rendered from `deck_full.json` (`voice.py:223`) and live in the `w-*` sprites. `carSay` prefers the clip over the text. If the `w-*` render predates the 22 gloss rewrites, car mode speaks the old gloss forever and nothing detects it. | `tools/voice.py:223`; `app.core.js:2239, 2635-2639, 2686-2703` | Audio and screen disagree on 22 words. Silent, permanent until the next re-render. | Confirm every `w-*.mp3` mtime postdates the `deck_full.json` gloss edit. If not, re-render the `w-*` sprites after the gloss change, not before. |
| 4 | **High** | `audPrune` deletes 37.7 MB of word and conjugation audio the instant the 3 KB manifest lands, before any replacement arrives. A link good enough for the manifest is not good enough for 29 MB. | `app.core.js:2294-2306`, called from line 2285; boot call at line 4007 | If the first post-deploy launch happens on a weak signal or at the start of a drive, he has no pre-rendered word or conjugation audio and no CarPlay-capable voice for that whole drive. | Deploy at a time he will next open the app on wifi. Tell him explicitly: open on wifi → settings → Download → wait for ~52 MB of ~52 MB → then drive. Offline is safe (cached manifest, no prune); *weakly online* is the bad state. |
| 5 | **Medium** | Rollback costs a second full audio re-download (~38 MB) on top of the first (~29 MB), and is only possible at all if the superseded sprite files are still in the repo. | `assemble the site`; `audPrune` | ~67 MB of mobile data across a ship-and-revert, and two audio-less windows. | Do not delete the 15 old sprite files in this change. Roll back by re-running the last good Actions run, not by hand-reverting `src/`. |
| 6 | **Medium** | `app.core.js:12` parses `example-data` at top level, unguarded — a missing blob is a white screen — and the CI content guard was not extended to cover it. | `app.core.js:12`; `.github/workflows/build.yml` guard step | Total app failure from a missing `<script>` tag, with no gate to catch it. | Add `grep -q 'id="example-data"' src/pwa/index.html` to the guard step. One line. |
| 7 | **Medium** | The page-size claim is internally inconsistent: "grows from ~1.28 MB to ~1.20 MB" while adding one example per word. The built file here is 1,293,391 B. The CI size check is a 1,000,000-byte floor and cannot see an 80 KB loss. | `.github/workflows/build.yml`; `build/build.py` | If ~80 KB really went missing, nothing catches it. | Reconcile the number against the actual built artifact before shipping. |
| 8 | **Medium** | The 22 rewritten glosses change the prompt on `mcEJ` and the typed `produce` block. Some will be answered wrong and genuinely demoted. | `app.core.js:1014-1015, 3122` | A small cluster of lapses on 22 cards over the following days. **Not a data problem.** | Tell him to expect it and to grade honestly. Do not reset anything. |
| 9 | **Low** | `audDownload` holds every sprite's `ArrayBuffer` in `AUD.loaded` simultaneously — ~52 MB of JS heap on an iPhone. | `app.core.js:3698-3713` | Possible tab reload under memory pressure mid-download. Pre-existing, but this build guarantees he runs it. | Watch for it. If it bites, chunk the `Promise.all`. |
| 10 | **Low** | `audDownload` reports "Voice downloaded" after `AUD_WAIT` (8 s) even if fetches are still in flight, because `audLoad` races every load against a timer. | `app.core.js:2311-2327, 3705-3710` | False confidence. He may drive off with a partial library. | Trust the "X MB of Y MB" line in settings, not the toast. |
| 11 | **Low** | A gloss rewrite could create a `sense()` collision that `build.py`'s three asserts do not catch, starving a card of distractors. | `app.core.js:942-950` vs `build.py:48, 61, 77` | Card silently degrades from multiple-choice to a flip. Handled gracefully at lines 1098/1119. | Accept. Note only. |
| 12 | **Info** | `pwa/_headers` is a Netlify file. The Pages deploy copies `audio icons manifest.webmanifest robots.txt index.html sw.js` and never `_headers`. It has no effect on the live site. | `.github/workflows/build.yml`; `/home/claude/pwa/_headers` | Any caching assumption based on it is wrong. | Delete it or ignore it. |

**What is genuinely well built, and should not be "improved":** content-addressed sprite names, the separate `kana-audio-v1` bucket that deploys never clear, the network-first manifest branch in `sw.js`, prune-before-download (it caps peak quota use, which on iOS is the difference between a re-download and losing the app shell), `audLoad` forgetting its misses so one dead spot does not kill a whole drive, the CI-derived cache name, and `build.py`'s three gloss-uniqueness asserts. His review history is not at risk from any part of this change.

---

## 3. Safe upload and deploy procedure

Ordered so that **every stopping point leaves a complete, working site**, and no interruption can produce a manifest that names a file the site does not serve.

The key fact the order exploits: **`audio/**` is not in the workflow's `paths:` filter.** Pushing sprite files, or even the manifest, publishes nothing. Only a `src/**` / `sw.js` / `icons/**` / workflow push, or a manual `workflow_dispatch`, deploys. Sprites are inert until the manifest names them; the manifest is inert until a deploy runs.

**Before you start:** on his phone, settings → Download a backup. One tap. Not because this build endangers the schedule — it does not — but it is free.

1. **Finish the renders.** All 10 `w-*` and all 5 `f-*` with `tools/voice.py`, from a `deck/deck_full.json` that **already contains the 22 rewritten glosses** (Finding 3 — the `we:` clips are rendered from that file). Then run `tools/audio_check.py` and require a clean exit.
2. **Keep `voice.py`'s own `manifest.json`.** Do not hand-edit or hand-merge a manifest. `sprites[].bytes`, `sprites[].clips`, `files` and `sigs` are four parallel maps regenerated together; updating `files` alone breaks the `AUD_PRELOAD_MB` budget and the "X MB of Y MB" readout. Set it aside — it is uploaded at step 7, not now.
3. **Verify no deploy can fire while you work.** Actions → confirm nothing is queued or running. Do not touch `src/`, `sw.js`, `icons/` or the workflow file until step 6.
4. **Upload the 15 new sprites — 30 files — in batches, `.mp3` and `.json` together per sprite.** Into `audio/v1/` via *Add file → Upload files*. **Do not upload the new `manifest.json` in any of these batches.** **Do not delete a single old file.** Interruption here is harmless: nothing names these files, nothing requests them, the live site is unchanged. Resume whenever.
5. **Verify the upload by reading the repo back, not by trusting the UI.** Open `audio/v1/` in the GitHub file browser and check off every `.mp3` and `.json` named in the new manifest's `files` map. This is the step that caught eight silently-failed batches before. **Do not proceed on fewer than all 30.**
6. **Push the page change** — `src/deck/deck_full.json` (new glosses), `src/deck/examples.json`, and the `src/build/` changes. This triggers deploy #1. Its `audio/` is the *old* manifest plus 30 unreferenced files, so the phone sees the new page with the old audio: **fully self-consistent, nothing pruned, nothing 404s.** Only cost is that the 22 rewritten glosses are spoken with their old English in car mode until step 8. Wait for build, test, deploy and verify to all go green.
7. **Now commit the new `audio/v1/manifest.json`** from step 2, on its own. **This publishes nothing** — `audio/**` is not in `paths:`. The site is still serving the old manifest. This is the only moment the repo is "ahead" of the site, and the next step closes it immediately.
8. **Actions → build, test and deploy → Run workflow** (`workflow_dispatch`). Deploy #2 publishes the new manifest alongside the sprites that have been sitting there since step 5. Wait for verify to go green. **Do not leave step 7 committed without step 8** — an unrelated deploy weeks later would otherwise publish it unattended.
9. **Check the live site before the phone does:** `https://halthunayan.github.io/kana-ladder/audio/v1/manifest.json`, then request two or three of the new `.mp3` URLs it names directly in a browser. `live_check.js` only probes `w-000`; do the others yourself.
10. **Then his phone, on wifi.** Launch the app — the service worker turns over and reloads once by itself. Settings will read **~22.6 MB of ~52 MB**: that is `audPrune` having done its job, not a fault. Tap **Download**, wait for the settings line to reach ~52 MB of ~52 MB (trust the line, not the toast — Finding 10). Only then is he ready to drive.
11. **Leave the 15 superseded sprite files in the repo for at least a week.** They are what makes rollback a single click.

**If it goes wrong:** Actions → the last known-good run → **Re-run all jobs**. That re-checks-out the old SHA, so page, `sw.js` and `audio/` revert together. ~8–14 minutes plus one app launch. He loses no scheduling and no history — `SCHEMA` is 6 on both sides and `loadLocal` has no version gate — but he pays another ~38 MB to re-download the old sprites.
