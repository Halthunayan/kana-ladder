# Council seat: the learner's experience of the card

**Verdict: NOT APPROVED.**

Two blocking defects. The gloss rewrite hands the learner the answer on the front of the
English→Japanese card — the exact failure the change was written to prevent. And the example
box teaches the wrong word on every romaji homograph in the deck, which is the one place a
romaji-only reader has no way to catch it.

Everything was checked against the built artifact `/home/claude/app/index.html` (the inlined
`example-data`, `deck-data`, `sent-data` blocks), not only the source files, so the counts below
are what ships.

---

## Findings

| # | Sev | Finding | Evidence |
|---|-----|---------|----------|
| 1 | Blocker | **13 of the 22 rewritten glosses print the answer in romaji on the front of the EJ card.** The card is no longer a test. | `nC003` front reads *"I am a doctor (wa, saying what my job is)"* → answer `watashi wa isha desu.` Also `nC004` (ga), `nC015` (ni), `nC016` (de), `nC017` (ni), `nC018` (to), `nC042` (wa), `nA115` (dake), `nE058` (shika), `s072` (kochira), `nB038` (douzo), `c0319` (douzo), `c0603` (*"the koto ga dekimasu pattern"* — the entire answer, verbatim). A deck-wide scan finds exactly 12 such leaks by automated match plus `nC018`; **all 13 were introduced by this change.** These cards will grade Easy every night, ride the SRS out to long intervals, and he will land in Japan believing he knows them. |
| 2 | Blocker | **The example box shows a sentence about a different word on every romaji homograph, and on ~25 more cards.** He reads romaji only, so nothing on the card can tell him. | 8 homograph pairs share one identical example, so one of each pair is flatly wrong: `c0084` *nose* → "hana o haha ni agemashita. / I gave **flowers** to my mother."; `c0807` *bridge* → "I eat with **chopsticks**."; `c0923` *living room* → "It is nine o'clock **now**."; `c0503` *paper* → "She has long **hair**."; `c0899` *tongue* → "The bag is **under** the chair."; `c0538/c0729` wind/cold; `c0035` *two* → the `ni` particle; `c0167/c0478` atsui. Plus substring-matcher garbage: `c1332` *to win* → "May I use the toilet?"; `c0964` *ikiru, to live* → "I'll **go** by taxi" (that is `iku`); `c1531` *rough* → "Where is the restroom?" (`otearai`); `c1182` *lower back* → "sukoshi"; `c1277` *lid* → "futatsu"; `c1341` *tune* → "yuubinkyoku"; `c1441` *business card* → "setsumei"; `c1474` *to commute* → "Tuesday"; `c1725` *rashii* → "atarashii"; `c1384` *tara* → "atarashii"; `c1392` *shiyasui* → "yasui, cheap"; `c1724` *youdesu* → "hitsuyou desu"; `c1730` *passive* → "kureru"; `c1104`, `c1122`, `c1315`, `c1507`, `c1513`, `c1553`, `c1561`, `c0866`. Note the cruelty of the overlap with finding 1: the glosses were rewritten *to disambiguate* `hana`/`hana`, and the example box then puts the identical sentence under both. |
| 3 | High | **The box does not exist.** `.ex-box` declares `border:1px solid var(--line)` but **`--line` is never defined** (the token is `--rule`); the whole shorthand is invalid and dropped. `background:var(--paper-2)` is byte-identical to the `.fold` answer panel it sits in. | Measured off the screenshots: the putative top edge is a single uniform colour in light (`#EFEAE0` across 330px) and 1.01:1 in dark. The bug is copy-pasted from `.gap-box` (style.css:411), which has it too. The reviewed design — a tinted, bordered block — has never rendered in either theme. What ships is three loose lines. |
| 4 | High | **"EXAMPLE" is pixel-identical to the tag chips and reads as a third tag**, and fails contrast in light mode. | `.ex-lab` and `.tags span` both render `#847C70` / `#8A8276`, both ~10.5px, both uppercase, both letterspaced ~.06–.09em. Sampled glyph colour is the *same triple* in both themes. Light-mode contrast **3.44:1** at 10.9px — below WCAG AA 4.5:1. In the light screenshot "EXAMPLE", "INTERJECTION" and "RESPONSES" are one visual rank. |
| 5 | High | **The example is the only Japanese on the card with no way to hear it — on the card that asks him to speak.** | `wireSpeak` binds `.card [data-speak]`; `exHtml` emits none. `jpBlockHtml` gives the headword a play button; the 32-character example sentence, the string he is least able to pronounce, gets nothing. On an EJ card ("Say it in Japanese") he has just produced one word and is then shown a sentence he can only guess at. **Answering the brief's question directly: romaji is the right script — it is the only one he reads — but romaji alone is the wrong artifact. It needs a play button, or it is teaching him a pronunciation he invented.** |
| 6 | High | **The target word is not marked inside the example.** | Median example is 32 characters; 539 of 1812 run past one line. He must hunt for the word he was just tested on in an undifferentiated romaji string — and on the finding-2 cards he will hunt for a word that is not in there. Bold or colour the target token. |
| 7 | Medium | **The block shrink-wraps and centres, so its left edge jumps between cards.** | `.face` is `align-items:center`; `.ex-box` has no width, so its width is the longer of the two lines. A 1-line example centres narrow, a 2-line example fills the gutter — the "EXAMPLE" label moves ~130px left and right card to card. Over 40 cards that is visible jitter with nothing to anchor it (see finding 3: there is no box edge to anchor to). Also the measure is inconsistent: `.english` is capped at `22ch`, the example runs to ~37ch. |
| 8 | Medium | **`.card{overflow:hidden}` with no scroll; long examples can be silently clipped.** | 154 examples produce 4+ wrapped lines at 375px (`c0033/c0037/c0039/c0040/c0041/c0042` all get the same 78-char phone-number sentence). Add a user note or the 8-lapse leech row and the back of a short phone will cut the English translation off with no indication. |
| 9 | Medium | **`overflow-wrap:anywhere` on `.ex-r` can break romaji mid-syllable** ("gozaima / su"), which is actively harmful for someone learning to read romaji. Romaji is space-delimited; `normal` or `break-word` is correct. | style.css:423 |
| 10 | Medium | **Vertical grouping is backwards.** `.ex-box{margin-top:14px}` but `.tags{margin-top:2px}`, so the example sits nearly touching the tags and far from the answer. It reads as card metadata, not as part of the answer. Swap the emphasis. | style.css:420, 142 |
| 11 | Low | **The feature is missing where it would help most.** `exampleFor` returns null for `isConj`, and `renderFocusCard` never calls `exHtml`. A conjugation card ("Say the past form") is exactly where a worked example earns its keep, and the same card shown in Focus/Practice silently loses its example. | app.core.js:1569, 1605 |
| 12 | Low | **Two different example presentations now ship** with near-identical class names: `.ex-r/.ex-e` on the card and `.ex-rm/.ex-en/.ex-st` in the word sheet. The same sentence looks like two different things depending on where he meets it. | style.css:309–311 vs 423–424 |
| 13 | Low | **Reuse is visible.** 1812 cards draw on 986 distinct sentences; `s343` serves six cards, `s184` and `nE103` five. Six consecutive digit cards all show the same phone number. | — |

### Does the example help, or is it clutter?
On a correct card, it helps — one sentence, under the answer, is the cheapest possible
context and it does not compete with the grade buttons (those are outside `.card` and never move).
But it is not paying its way as shipped: it is invisible as a component (3), mislabelled (4),
silent (5), unmarked (6), wrong on the hardest cards in the deck (2), and it is the thing standing
between his answer and the grade buttons on every single card. Fix 2, 3, 4, 5 and 6 and it earns
its place. Ship it as is and a tired man at 11pm learns that *hana* means flower twice.

---

## Replacement wording

### Sentence glosses — all ten leak. Rewrite so the English *carries* the difference instead of naming the particle.

| id | Ships now (leaks) | Replace with |
|----|-------------------|--------------|
| `nC003` | I am a doctor (wa, saying what my job is) | **I'm a doctor.** |
| `nC004` | I am the doctor (ga, saying I am the one) | **I'm the one who's the doctor.** |
| `nC015` | I will ask the reception desk (ni, the desk is who I ask) | **I'll ask the receptionist.** |
| `nC016` | I will ask at the reception desk (de, the desk is where I ask) | **I'll ask over at the reception desk.** |
| `nC017` | I will speak to the child (ni, one direction) | **I'll tell the child.** |
| `nC018` | I will speak with the child (to, both of us talking) | **I'll have a talk with the child.** |
| `nC042` | Meat, I do not eat it (wa, marking meat as the contrast) | **Meat is the one thing I don't eat.** — *this is the old gloss, and it was better: idiomatic English that already carries the contrastive force. The rewrite replaced working English with a comma splice plus a footnote plus the answer. Revert it.* |
| `nA115` | I can speak only a little Japanese (dake, with a positive verb) | **I can speak just a little Japanese.** |
| `nE058` | I can only speak a little Japanese (shika, with a negative verb) | **I can't speak more than a little Japanese.** — *the negative in the English is what forces `shika ...masen`, and he never has to be told the rule.* |
| `s072` | This way, please (kochira first) | **This way, please.** |
| `nB038` | Please, this way (douzo first) | **Please — do come this way.** — *honestly, `kochira e douzo` and `douzo kochira e` are the same sentence reordered. Word order is not a thing an English prompt can fairly cue. Cut `nB038` rather than invent a gloss for it.* |

### Word glosses — three regressions and one leak.

| id | Ships now | Replace with |
|----|-----------|--------------|
| `c0603` | can ~, is able to ~ (the koto ga dekimasu pattern) | **can ~, is able to ~ (the long pattern built on a plain verb)** — *never print the answer.* |
| `c0011` | please treat me well (the full polite form) | **nice to meet you — the long, formal one you say on first meeting** |
| `c0319` | please treat me well (with douzo, a little more polite) | **nice to meet you — the two-word one, a step down from the long formal version** — *the shipped parenthetical says `douzo yoroshiku` is "a little more polite" than the "full polite form" `yoroshiku onegai shimasu`. That is backwards, and there is no way for him to work out the ranking from the three cards.* |
| `c0320` | please treat me well (the short form on its own) | **nice to meet you — the one-word casual version** |
| `c0102` | tea (the everyday word, usually green tea) | **tea (the ordinary polite word you use in a restaurant)** |
| `c0748` | green tea (the specific word) | **green tea (naming the type, as opposed to other kinds of tea)** — *"the specific word" tells him nothing; at 11pm both cards read "tea-ish, green-ish" and he flips a coin.* |
| `c0605` | although, but (the full form) | **although, but — the long formal one** |
| `c1397` | but, although (the short everyday form) | **but — the short one you tack on the end when speaking** |
| `c0581` | to be able to, can do (the verb itself) | **to be able to, can do (one word)** |
| `c0860` | to answer, to reply (verb) | **to answer someone** |
| `c1018` | a reply, an answer (noun) | **a reply** — *"to answer someone" vs "a reply" is already unambiguous; the `(verb)`/`(noun)` tags are a grammar footnote doing work the article already does.* |
| `c0012` | how do you do (opening an introduction) | keep — this one is a genuine improvement |

Three of these — `c0011`, `c0319`, `c0320` — replaced idiomatic English ("pleased to meet you")
with the calque "please treat me well", which no English speaker writes, and then disambiguated
three identical calques with self-referential parentheticals. The learner has to reverse-engineer
a taxonomy he was never taught. That is strictly worse than what it replaced.

### Wrong examples — remove or re-source before ship
At minimum, the homograph half of each of these must lose its borrowed example:
`c0084` (nose), `c0807` (bridge), `c0923` (living room), `c0503` (paper), `c0899` (tongue),
`c0538`/`c0729` (wind/cold), `c0035` (two), `c0167`/`c0478` (atsui), plus
`c0964`, `c1332`, `c1531`, `c1182`, `c1277`, `c1341`, `c1441`, `c1474`, `c1725`, `c1384`,
`c1392`, `c1724`, `c1730`, `c1104`, `c1122`, `c1315`, `c1507`, `c1513`, `c1553`, `c1561`, `c0866`.
No example is better than a wrong one. The linker that produced these is matching romaji
substrings with no sense check — `hana` in "flowers", `katsu` in "tsukatte", `yasu` in "yasui" —
so the whole 1812-entry map needs a pass, not just the 25 the `w`-list check happened to surface.

---

## What would annoy a tired man doing 40 cards at night
- The label moves left and right every card and there is no box edge to hold it still (3, 7).
- "EXAMPLE" is the same grey, size and letterspacing as the tags right beneath it, so the
  eye reads four tags, not a section and two tags (4).
- Everything else Japanese on the card can be tapped to hear; the longest string cannot (5).
- On a short phone the English translation can be cut off with no scroll and no sign (8).
- Ten sentence cards and three word cards have the answer printed on the front, which feels
  great at 11pm and is a lie the SRS will happily compound until 30 November (1).
