# Council seat: code and gates — examples build

**VERDICT: NOT APPROVED**

The card-side JavaScript is genuinely defensive and I could not make `exampleFor`
or `exHtml` throw on anything. The blockers are elsewhere: the audio library on
disk does not contain any of the voice work under review, the audio quality gate
crashes on the first line, the only test covering the new code runs on a port
nothing serves and is not in CI, and the new gloss guard rejects the single most
common grammar contrast in the deck.

---

## Findings, most serious first

| # | Sev | File : line | Finding |
|---|-----|-------------|---------|
| 1 | **Blocker** | `tools/voice.py` : 324-335 (write), `pwa/audio/v1/manifest.json` | The voice rebuild never finished. `manifest.json` still points at the Sep 14 sprite files; only `f-000` and `f-001` were re-rendered (Sep 15 19:53 / 20:00) and are orphaned. **Zero** `w-*` sprites were rebuilt. None of WORD_LADDER, WORD_TRIES, the nasal suffix or trim is in the shipped library. |
| 2 | **Blocker** | `tools/audio_check.py` : 40 | The audio quality gate raises `ValueError: too many values to unpack (expected 3)` and exits before measuring anything. `plan()` now yields 4-tuples; the gate still unpacks 3. Verified by running it. |
| 3 | **High** | `build.py` : 70-78 | The `_wordset` guard cannot tell a statement from its yes/no question, because it strips `?` and ignores word order. |
| 4 | **High** | `app/examples_check.js` : 8; `pipeline_doc.md` "What the pipeline does" | The only suite covering the new code defaults to `PORT=8101`. Nothing serves 8101 (README: app/ on 8099, pwa/ on 8100). It is in neither the README's 16-suite list nor `src/tests/`, so CI runs `car.js`, `tts_recovery.js`, `live_check.js` and never this. |
| 5 | **High** | `build.py` : 109-134 vs `app.core.js` : 2597-2605 | The example guard never checks that the example sentence contains the word. 138 of 1,446 by-ref examples point at a sentence whose kana does not contain the card's kana; 118 of 366 inline examples likewise. `carSentence()` already enforces exactly this rule. |
| 6 | **High** | `app.core.js` : 1745 / 1758 / 1763 + `style.css` : 420-424 | The 132px example box pushes the grade buttons below the fold. Measured, box present vs removed, 259 sampled word cards. |
| 7 | **Med-High** | `deck/examples.json` (design) | 1,397 of 1,446 by-ref examples point at a sentence that lists the word in its own `w[]` — the sentence the app gates behind that word and will later schedule as a card. 986 of 1,442 sentences (68%) now have their full romaji **and** English printed on a word card's back, repeatedly, before their own card is ever introduced. |
| 8 | **Medium** | `tools/voice.py` : 85-86, 119-139 | `TRIM_DB = -45.0` sits on this voice's own noise floor (measured floor -44 to -47 dBFS), so trimming is a coin flip per clip rather than a decision. |
| 9 | **Medium** | `tools/voice.py` : 119-139, 240-253; `app.core.js` : 2691-2732 | Trimming shortens every car-mode pause by roughly 0.3-0.5 s, and only word/form sprites rebuild, so sentence and phrase clips keep their padding. |
| 10 | **Medium** | `tools/voice.py` : 65-72; `app.core.js` : 1522, 2637, 2699-2701 | WORD_LADDER moves the word clips' base tempo to length_scale 1.45, but nothing in the app's rate model moved with it. |
| 11 | **Medium** | `tools/audio_check.py` : 29 (`MAX_SEC_PER_MORA = 0.50`) | The gate exempts any clip over 0.50 s of clip per mora as "already drawn out". At length_scale 1.45 a large share of short words now clears that, so the floor check silently stops applying to the clips the new renderer is aimed at. |
| 12 | **Low-Med** | `tools/voice.py` : 149-193 | A word clip is now drawn 4 times at `WORD_LADDER[0]`, then the floor loop restarts `for ls in ladder` at that same rung and burns another 3 draws there before moving up: up to 16 syntheses per clip where the old path used 1-13, for ~3,400 word and form clips on a `Pool(2)`. |
| 13 | **Low-Med** | `tools/voice.py` : 166-193 | If numpy is missing, `voiced()` returns `None` and line 189 (`got > best`) / 191 (`best >= want`) raise `TypeError`. `job()` swallows it, every clip returns `b''`, and the run dies at line 304 with "refusing to ship a sprite with holes in it" — a message that points at synthesis, not at numpy. |
| 14 | **Low** | `app.core.js` : 12 | `document.getElementById("example-data").textContent` is unguarded top-level code inside the IIFE. |
| 15 | **Low** | `app.core.js` : 1605-1716 (`renderFocusCard`) | Focus cards never call `exHtml`, so the same word shows a worked example in review and none in Focus. Not a crash; not tested. |
| 16 | **Low** | `app/examples_check.js` : 44-49 | Section 3 is titled "a sentence card **and a conjugation card** get no example" and only ever tests a sentence card. A `practiceOnly` card is never tested either. |
| 17 | **Low** | `build.py` : 139-144 | `</script>` is still not escaped when the JSON blobs are inlined. `example-data` adds 55 KB of new free English text to that surface. Currently clean (checked). |
| 18 | **Info** | `README.md` : 3-4 | README says 1,759 words / 1,210 sentences. The built page carries 1,812 and 1,442. |

---

## Failure scenarios

**1 — the audio work is not in the library.**
`pwa/audio/v1/manifest.json` lists `f-000.dfc4c57a` while `f-000.9dd8d1c0.mp3`
sits beside it unreferenced. `main()` writes the manifest and prunes stale files
only after every sprite completes, so an interrupted run leaves the old manifest
and the new files. He deploys, the phone reads the manifest, downloads the Sep 14
sprites, and every word still sounds exactly as it did — the swallowed `yon`, the
missing final `ん`, the room tone. Meanwhile `pwa/` ships 3.9 MB of orphan audio
nobody can reach. Nothing in the pipeline compares the manifest to the directory,
and `live_check.js` only asks whether *a* clip downloads.

**2 — the gate that exists to catch swallowed words cannot start.**
`python3 tools/audio_check.py` after `tools/voice.py`:
`ValueError: too many values to unpack (expected 3)` at line 40. `plan()` now
appends `kind` to every tuple; the gate's dict comprehension still expects
`(key, lang, text)`. This is the only thing on the project that listens to what
is *inside* a clip, it is the gate written specifically for the `yon` defect, and
this build's whole purpose is a new renderer. It is also not in CI, so the failure
surfaces only when somebody runs it by hand.

**3 — the gloss guard rejects か.**
`_wordset` lowercases, replaces every non-alphanumeric with a space, drops
`a/an/the`, and takes a `frozenset`. Verified against the real content:

```
COLLIDE  'This is my book.'            | 'Is this my book?'
COLLIDE  'Tanaka is a teacher.'        | 'Is Tanaka a teacher?'
COLLIDE  'The station is over there.'  | 'Is the station over there?'
COLLIDE  'I drink coffee every morning.' | 'Every morning I drink coffee.'
COLLIDE  'left and right'              | 'right and left'
COLLIDE  'a lot'                       | 'lot'
```

277 of the 1,442 sentences already in the deck are questions. Add
`これはわたしのほんですか。` to sit beside the existing statement — the exact
statement/question pair that teaches か — and `build.py` aborts with
*"two items ask the same English question once word order and articles are
ignored, so the prompt has no single answer"*, which is false: the learner can
tell those two prompts apart perfectly well. Per `pipeline_doc.md` the deploy stops
there, and the documented workflow is editing content on github.com from a phone,
so he gets a red X and an `AssertionError` traceback four minutes later with no
way to override. The margin is already gone: I found **170 pairs in the current
content that sit exactly one token apart**, including
`'Please get well soon.'` / `'get well soon'` and
`'May I take a photo here?'` / `'May I take a photo?'`.

**4 — the new test does not run.**
`node examples_check.js` with the documented harness up (8099 + 8100) gets
`net::ERR_CONNECTION_REFUSED` on `localhost:8101` and dies as an unhandled
rejection before the first assertion. It is absent from the README's suite list
and from `src/tests/`, so the pipeline's test job never invokes it. With a server
on 8101 pointed at `pwa/` it passes cleanly (I ran it: 9/9), which is exactly the
danger — the suite works, and the deploy that ships a broken `exHtml` will be green.
This is also the answer to "which file would fail if `exHtml` moved to the front":
**`/home/claude/app/examples_check.js`**, section 4, which asserts
`front === false && back === true` for `j`, `e` and `a`. It is the only file in
`/home/claude/app/` that mentions `exHtml`, `ex-box`, `EXAMPLE` or `exampleFor`;
no other suite would notice, including the two that CI actually runs.

**5 — the example does not contain the word.**
`c0115 のむ` points at `s162 ミルクがのみたいです。`; `c0177 ある` points at
`nB098 それはありません。`; `c0181 かえる` points at `s109 ゆうがたにうちへかえります。`
The build guard only asks whether the id resolves. 138 by-ref and 118 inline
examples are like this. He meets `のむ` for the first time, reads
"miruku ga nomitai desu", and has to work out unaided that `nomitai` is the card
he is looking at — on a deck whose whole premise is that conjugation is gated
behind `CONJ_GATE` days of interval precisely so this does not happen. The app
already knows the rule: `carSentence()` at line 2601 skips any sentence where
`sx.kana.indexOf(c.kana) < 0`. Car mode and the card back now disagree about what
a valid example is.

**6 — the grade buttons go below the fold.**
Measured in headless Chromium, `.grades` bounding top vs `innerHeight`, with the
`.ex-box` present and then removed from the same DOM, over 259 sampled word cards
in all three directions:

| viewport | J→E | E→J | listening |
|---|---|---|---|
| 393 × 852 | 0 → 0 | 0 → 0 | 0 → **1** |
| 390 × 664 | 0 → **2** | 0 → **65** | 195 → **259** |

At 393 × 852, the project's only tested viewport, one card in 259 regresses
(`c1557`, a two-clause example: box 132 px, grades top 866 px on an 852 px
viewport, document scroll 1005 px). At 390 × 664 — an SE-class phone, or any
taller phone in Safari with the address bar showing rather than installed to the
home screen — **every** listening card and a quarter of the English→Japanese cards
now need a scroll between reading the answer and pressing Again/Hard/Good/Easy,
where none did before. `pipeline_doc.md` states it outright: *"Layout is still
asserted at 393 px only."* `layout_trim.js` measures the Study home page height
and never opens a card back. `examples_check.js` asserts that `.ex-box` exists and
never asks where it is.

**7 — the example pre-answers the sentence card.**
Word `c0115 のむ` is introduced; its back prints `s162` in romaji and English.
`sentOpen`/`sentMissing` hold `s162` back until its words are known, so by the
time `s162` is first served as a card he has been shown its complete translation
on every one of `のむ`'s reviews. 986 distinct sentences, 68% of the sentence deck,
are exposed this way. This is not a crash and it may even be the intent — but it
is a decision about what 1,442 sentence cards are worth, it was made by a data
file, and there is no gate on it.

**8 — the trim threshold sits on the noise floor.**
Decoded `f-000` old vs new. The tail of every new clip floors at −44 to −47 dBFS
per 10 ms frame; `TRIM_DB` is −45.0. So `np.where(db > TRIM_DB)` includes room-tone
frames on some clips and excludes them on others, on a coin flip within the
encoder's own noise. Good news first: I went looking for the failure where trim
eats the phrase-final `ん` that `NASAL_SUFFIX` was added to produce, and on the
clips I could measure (`たべません`, `のみません`, `ありません`, `いません`) **it does not** —
the nasal decays through −13 → −28 → −44 and trim stops inside that decay.
But it stops there by about 1 dB. A clip encoded a hair quieter loses the nasal
and reintroduces exactly the defect, and the gate that would catch it is finding
2 above. A threshold relative to each clip's own peak would not have this property.

**9 — the pauses he tuned get shorter, unevenly.**
Measured: old clips carry ≥0.20 s of silence before speech (0 of the first 20
frames above −45 dB); new clips carry ~0.10 s. Total shortening is roughly 0.3 s
per clip head and tail. Nothing in the app *assumes* a duration —
`audPlayBytes` waits on `el.onended` with a 30 s watchdog, `carHold` is an
independent timer, `CAR_GAPS` is drive time — so there is no breakage. But the
think-gap he hears between question and answer was `carGapMs()` **plus** the old
padding; at the default `carGap: 4` it drops from about 4.65 s to about 4.2 s,
and the 350 ms pause before the slow repeat at line 2695 roughly halves. Because
`signature()` only re-hashes `kind == 'word' and lang == 'ja'`, the `s-*` and
`p-*` sprites are reused untouched: after a word the next line starts at once,
after an example sentence there is still half a second of dead air. The drive's
rhythm becomes uneven in a way no measurement will report.

**10 — the clips are slower but the app's rate model did not move.**
`carSay` (line 2637) sets `playbackRate = clamp(rate / 0.85, 0.5, 1.6)` and
`speakCard` (line 1522) does the same, both anchored to the old library's tempo.
Word clips now render at `length_scale 1.45`; measured on `たべません`, voiced speech
rose from 0.65 s to 0.73 s. At the default `speechRate 0.85` that is played at
playbackRate 1.0, so every word is ~12-45% slower than before with no compensation
— and `carSlow` re-says at `rate − 0.25` → playbackRate 0.71, so the slow repeat
now lands near half the original library's speed. That may be exactly what a
citation form wants. It is not a decision anyone made in the app.

---

## What I could not break

Worth recording, because these were the questions and the answers are clean.

- **`exampleFor` / `exHtml` cannot throw.** Driven in-browser against the built
  page with `null`, `{}`, an id not in `EXAMPLE`, `__proto__`, `constructor`,
  `toString`, a `practiceOnly` card, a `CONJ` anchor, a dangling sentence
  reference, `["",""]` and `42`. Every one returned `null` and `exHtml` returned
  `""`. The prototype keys are safe by accident, not by design — `EXAMPLE["constructor"]`
  yields the `Object` constructor, survives `if(!e)` and `typeof e === "string"`,
  and is only stopped by `e[0]` being `undefined` on a function — but they are safe,
  and no deck id looks like one.
- **A restored old save cannot produce a card without an example.** `applyBlob`
  (line 250) drops any item whose id is not in `IDX`, `IDX` is built from the
  page's own `DECK`, and `build.py` line 120 asserts every deck word has an
  example. A pre-build save can only lose cards, never introduce unknown ones.
- **Practice-only conjugation cards** (`app.core.js` : 754) carry `practiceOnly: true`
  and are caught by the first clause of `exampleFor`.
- **`example-data` never renders on a front face.** All three call sites (1745,
  1758, 1763) assign to `back.innerHTML`; `renderFocusCard` does not call it at all.
- **Page size is a non-issue.** `example-data` is 55,133 bytes of a 1,293,391-byte
  page — 4.3%, on top of 330 KB of deck and 435 KB of sentences already there,
  and it compresses like the rest. `SIDX` is one pass over 1,442 sentences at boot.
  `exHtml` runs once per card. No phone will notice.
- **CSS does not collide.** `.ex-box .ex-lab .ex-r .ex-e` (style.css 420-424) sit
  beside the pre-existing `.ex-rm .ex-en .ex-st` (309-311) used by the browse
  sheet. Class selectors are exact; `.ex-r` does not match `class="ex-rm"`.

## Smallest set of changes that would make this approvable

1. Re-run `tools/voice.py` to completion and confirm `manifest.json` references
   the new files and the orphans are gone.
2. Fix `audio_check.py:40` to unpack 4 and re-examine `MAX_SEC_PER_MORA` against
   the new tempo; run it.
3. Make `_wordset` order-preserving, or at minimum keep `?` as a token, so a
   question is not the same prompt as its statement.
4. Point `examples_check.js` at 8100, add it to the README suite list and to
   `src/tests/`, and add the two assertions it is missing: a conjugation card, and
   `.grades` on screen at 390 × 664.
5. Add `sentence kana contains the word kana` to the example guard, matching the
   rule `carSentence()` already applies.
