# Council Review — Japanese Language Seat
## File: `/home/claude/examples/review_2.tsv` (183 example sentences)

**VERDICT: NOT APPROVED** — 24 rows need edits before shipping; 159 rows are sound.

No row is outright ungrammatical. Every problem below is a collocation, register, or
translation problem — the kind that passes a textbook check but makes a native speaker
wince, or that quietly teaches the learner a habit he will have to unlearn.

---

## Problems found

Severity key: **E** = error (wrong, or teaches a bad habit) · **U** = unnatural (a Japanese
person would not phrase it this way) · **T** = translation/English problem only.

| id | Sev | Sentence as written | What is wrong | Corrected kana | Corrected romaji |
|---|---|---|---|---|---|
| c1673 | **E** | おかあさんがスカートをぬいました。 | Register error, and the worst one in the set. The English is "**My** mother", but 「おかあさん」 is how you refer to *someone else's* mother, or how a small child addresses his own. Speaking about your own mother to another person, it must be 「はは」. Row c1497 in this same file gets it right (「ははがいもうとをしかりました」), so the set contradicts itself. If he says 「おかあさんが…」 about his own mother in Japan, he will sound like a five-year-old. | ははがスカートをぬいました。 | haha ga sukaato o nuimashita. |
| c1517 | **E** | もういちどくりかえしてください。 | 「くりかえす」 already means "do again", so 「もういちど…くりかえして」 is a tautology, and 「くりかえしてください」 with no object is not how a Japanese person asks for a repeat. The real phrase is 「もういちどいってください」. This is a sentence he is likely to actually try to use in Japan, and it will land oddly. Teach くりかえす with an object instead. | せんせいはおなじことばをなんどもくりかえしました。 | sensei wa onaji kotoba o nandomo kurikaeshimashita. |
| c1393 | **E** | このしごとはしにくいです。 | 「しごと」 does not take 「しにくい」. Because the collocation is 「しごとをする」, the ~にくい form a native uses here is 「やりにくい」 — 「このしごとはやりにくいです」. As written it sounds like a non-native calque. Demonstrate しにくい on a する-noun, where it is correct and natural. | このみせはよやくしにくいです。 | kono mise wa yoyaku shinikui desu. |
| c1511 | **E** | コートをクローゼットにつるしてください。 | Wrong verb for the situation. A coat goes on a hanger and is 「かける」 — 「クローゼットにかけてください」. 「つるす」 means to suspend/dangle something (a wind chime, laundry on a line) and is not used for putting a coat away. Keep つるす but give it an object it actually takes. | ハンガーにコートをつるしてください。 | hangaa ni kooto o tsurushite kudasai. |
| c1556 | **E** | パンをかいました。くわえて、ぎゅうにゅうもかいました。 | Severe register clash. 「くわえて」 is written/formal connective — reports, proposals, news copy. No one uses it about buying bread and milk; they say 「それに」 or 「そのうえ」. As written it is the Japanese equivalent of "I procured bread. Furthermore, I procured milk." Pair the word with content that fits its register. | かれはえいごがはなせます。くわえて、ちゅうごくごもはなせます。 | kare wa eigo ga hanasemasu. kuwaete, chuugokugo mo hanasemasu. |
| c1482 | **E** | かぞくでりょこうのひをけっていしました。 | Register clash. 「けっていする」 is institutional — a company, a committee, a government decides. A family choosing a travel date 「きめました」. Using けっていする here sounds like the family held a board meeting. | がっこうはあたらしいきそくをけっていしました。 | gakkou wa atarashii kisoku o kettei shimashita. |
| c1499 | **E** | クラスでそのもんだいをぎろんしました。 | 「ぎろんする」 normally takes 「〜について」, not a bare 〜を. 「もんだいについてぎろんする」 is the standard frame; 「もんだいをぎろんする」 is heard but reads as clipped/journalistic and is not what a learner should internalise. | クラスでそのもんだいについてぎろんしました。 | kurasu de sono mondai ni tsuite giron shimashita. |
| c1534 | **U** | このはさみはにぶいです。 | Questionable collocation. For a blade that will not cut, Japanese says 「きれない」 or 「きれあじがわるい」; 「にぶる」 (verb) is used of a blade going dull, but adjectival 「はさみがにぶい」 is not idiomatic. 「にぶい」 in everyday use describes movement, reaction, or a dull ache. | かれはうごきがにぶいです。 | kare wa ugoki ga nibui desu. |
| c1541 | **U** | しゅくだいはかんぜんにおわりました。 | 「かんぜんに」 does not sit well with しゅくだい — homework is 「ぜんぶおわりました」. 「かんぜんに」 goes with things that can be partially done: recovery, construction, destruction, a repair. | かぜがかんぜんになおりました。 | kaze ga kanzen ni naorimashita. |
| c1596 | **U** | このちいきはじゅうたくがたかいです。 | 「じゅうたく」 is the dwelling, not its price, so 「じゅうたくがたかい」 is loose. Natives say 「やちんがたかい」 (rent) or 「じゅうたくのねだんがたかい」. | このちいきはじゅうたくのねだんがたかいです。 | kono chiiki wa juutaku no nedan ga takai desu. |
| c1712 | **U** | せいふはあたらしいルールをつくりました。 | A government makes 「ほうりつ」 or 「きそく」, not 「ルール」 — the loanword is for games, clubs, offices. Both better words are already taught in this same file (c1469 ほうりつ, c1454 きそく), so the fix costs nothing. | せいふはあたらしいほうりつをつくりました。 | seifu wa atarashii houritsu o tsukurimashita. |
| c1707 | **U** | しゃしんをインターネットにとうこうしました。 | 「インターネットにとうこうする」 is clunky — you post *to a place*: SNS, a blog, a board. "Posted it to the internet" is a translation of English, not Japanese. | ブログにしゃしんをとうこうしました。 | burogu ni shashin o toukou shimashita. |
| c1699 | **U/T** | けっこんしきのカメラマンをよびました。 | 「よぶ」 = summon/call over, so this reads as though the photographer was shouted at. Hiring one is 「たのむ」 or 「おねがいする」. The English "We called a photographer" is also ambiguous (telephoned? summoned?). | けっこんしきのカメラマンをたのみました。 | kekkonshiki no kameraman o tanomimashita. |
| c1690 | **U** | きのうのしあいのとくてんをおしえてください。 | 「とくてん」 is points scored by a side or player, not "the score(line)" as a whole — for that Japanese uses 「けっか」 or 「スコア」. Asking for 「しあいのとくてん」 is understandable but off. | わたしたちのチームのとくてんはさんてんでした。 | watashitachi no chiimu no tokuten wa santen deshita. |
| c1400 | **U** | ばんごはんのまえに、しゅくだいをしおわりました。 | Same collocation trap as c1393: because it is 「しゅくだいをする」, the natural compound is 「やりおわりました」. 「しおわる」 is fine but wants a する-noun object. | かいぎのじゅんびをしおわりました。 | kaigi no junbi o shiowarimashita. |
| c1456 | **U** | このへやはたばこがきんしです。 | Marking the room with は while たばこ takes が leaves the location relation unstated; the action happens *in* the room, so 「このへやでは」. (Real signage says 「きんえん」, worth knowing for the trip.) | このへやではたばこがきんしです。 | kono heya de wa tabako ga kinshi desu. |
| c1543 | **U** | じかんをせいかくにおしえてください。 | Borderline. For this meaning a native says 「せいかくなじかんをおしえてください」 (adjective), not the adverb. 「せいかくに」 as an adverb works best with かく／こたえる／はかる. | じゅうしょをせいかくにかいてください。 | juusho o seikaku ni kaite kudasai. |
| c1666 | **U** | かびんにはなをいれました。 | 「いれる」 is not wrong but is flat — flowers go in a vase with 「いける」 or, casually, 「かざる」. Flagging rather than failing. | かびんにはなをかざりました。 | kabin ni hana o kazarimashita. |
| c1477 | **U** | インターネットでりょこうをもうしこみました。 | 「りょこうをもうしこむ」 only works if it is a packaged tour. Booking travel generally is 「よやくする」. Use ツアー to make the collocation sound. | インターネットでツアーをもうしこみました。 | intaanetto de tsuaa o moushikomimashita. |
| c1522 | **U** | きょうはこううんなひでした。 | Flagging as uncertain. 「こううんなひ」 is grammatical but bookish; everyday Japanese is 「きょうはうんがよかったです」. 「こううん」 sits more naturally on a person or an outcome. | かれはこううんなひとです。 | kare wa kouun na hito desu. |
| c1523 | **U** | きのうはふうんなひでした。 | Same as c1522, and 「ふうん」 is the rarer of the pair — it is most idiomatic as 「ふうんなことに」 or 「ふうんが つづく」. Everyday: 「うんがわるかったです」. | ふうんなことに、でんしゃがおくれました。 | fuun na koto ni, densha ga okuremashita. |
| c1498 | **T** | かれはいつももんくをいいます。 | Japanese is fine, but the English "He is **always complaining**" (habitual-with-irritation) maps to 「いっています」. As written the Japanese is a neutral habitual and the English adds a complaint the Japanese does not carry. | かれはいつももんくをいっています。 | kare wa itsumo monku o itte imasu. |
| c1506 | **T** | こどもはおかあさんのてをにぎりました。 | English only: "The child held **its** mother's hand" — "its" is wrong for a person in English. Japanese is fine (おかあさん is a third party's mother here, which is correct). | *(kana unchanged)* こどもはおかあさんのてをにぎりました。 | kodomo wa okaasan no te o nigirimashita. — EN: "The child held his mother's hand." |
| c1487 | **T** | このアプリをもっとかいぜんしてください。 | English only: 「もっと」 is "more", not "a bit more" (that would be 「もうすこし」). The translation understates the request. | *(kana unchanged)* このアプリをもっとかいぜんしてください。 | kono apuri o motto kaizen shite kudasai. — EN: "Please improve this app more." |

---

## Patterns seen repeatedly

**1. The する-verb compound trap (c1393, c1400, and to a lesser extent c1401).**
The set demonstrates しにくい／しおわる／しつづける on objects that already collocate with する
as a light verb (しごと, しゅくだい). Japanese resolves that clash by switching to やる —
やりにくい, やりおわる. Whenever a ~しV compound is taught, the object must be a する-noun
(よやく, じゅんび, せつめい, れんしゅう), never a plain noun that takes を+する.

**2. Formal-register vocabulary dropped into domestic sentences (c1482, c1556, and near-misses
at c1501, c1541, c1596).** Words like けっていする, くわえて, かんぜんに, したがって belong to
written and institutional Japanese. Attaching them to bread, homework and family holidays
creates sentences that are technically legal and socially wrong. A formal word needs a formal
frame, or the learner will deploy it in a konbini.

**3. English-shaped verb choice (c1511, c1699, c1707, c1666).** "Hang the coat" → つるす,
"call a photographer" → よぶ, "post to the internet" → インターネットにとうこう, "put flowers in
a vase" → いれる. In each case the English verb was translated rather than the Japanese
collocation selected. This is the single most common failure mode in the file.

**4. In-file inconsistency on humble reference to family (c1673 vs c1497).** One row uses はは
correctly, another uses おかあさん for the same relationship. Whatever the set decides, it must
decide once — a learner meeting both will infer they are interchangeable, which they are not.

**5. Romaji word-splitting in the `target_romaji` column is inconsistent with `sentence_romaji`.**
Not a language error, but it will mislead. `kanzenni` / `seikakuni` / `akirakani` / `shinkenni` /
`saishuutekini` / `sonokekka` / `dasoudesu` / `rokugasuru` / `tourokusuru` / `foroosuru` /
`toukousuru` / `touhyousuru` are written closed in the target column and open (`kanzen ni`,
`sono kekka`, `da sou desu`, `rokuga shimashita`) in the sentence column. Since he reads romaji
only, the closed spellings teach him these are single lexical units. Recommend the open spelling
everywhere.

**6. Scope note (outside my remit, but worth saying).** A large block of this set — かちょう, ぶか,
りれきしょ, さいよう, しゅっせき, ろんぶん, せんきょ, とうひょうする, しゅしょう, りこん, ほうりつ —
is office, academic and civic vocabulary. None of it is wrong, but with ten weeks to departure
none of it will be used on the trip either, while genuinely high-yield rows in this same file
(c1481 かのう, c1489 へんこうする, c1674 すそ, c1603 はんこ, c1718 いのる, c1734 しかない) are
outnumbered by it. Flagging for the curriculum seat.

---

## Count

**159 of 183 rows judged sound.** 24 rows flagged: 7 errors, 15 unnatural/uncertain,
2 English-only. No row contained a grammatical error in particles, verb conjugation,
adjective inflection, counters or transitivity.
