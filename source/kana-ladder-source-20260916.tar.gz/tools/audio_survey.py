# -*- coding: utf-8 -*-
"""What the library actually sounds like, measured over every clip.

Not a gate: a report. It answers the two questions this round was about, how
fast an isolated word is spoken and whether a word ending in n keeps its nasal,
across the whole library rather than on the handful anyone happened to notice."""
import json, os, subprocess, sys
import numpy as np
from multiprocessing import Pool
sys.path.insert(0, '/home/claude/tools')
V = '/home/claude/pwa/audio/v1'
SMALL = 'ゃゅょぁぃぅぇぉャュョァィゥェォ'
def morae(t): return sum(1 for ch in t if ch not in SMALL and ch not in '、。？！ ')

def load(path):
    man = json.load(open(os.path.join(path, 'manifest.json'), encoding='utf-8'))
    idx = {}
    for sp, base in man['files'].items():
        for k, (off, ln) in json.load(open(os.path.join(path, base + '.json'), encoding='utf-8')).items():
            idx[k] = (os.path.join(path, base + '.mp3'), off, ln)
    return idx

def measure(job):
    key, text, fn, off, ln = job
    with open(fn, 'rb') as f:
        f.seek(off); data = f.read(ln)
    p = subprocess.run(['ffmpeg', '-v', 'error', '-i', 'pipe:0', '-f', 's16le',
                        '-ac', '1', '-ar', '22050', 'pipe:1'],
                       input=data, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    a = np.frombuffer(p.stdout, dtype='<i2').astype('float64')
    n = 220; f = len(a) // n
    if f < 3: return None
    seg = a[:f*n].reshape(f, n)
    rms = np.sqrt((seg * seg).mean(axis=1))
    db = 20 * np.log10(np.maximum(rms, 1e-6) / 32768.0)
    voiced = float((db > -25).sum()) * 0.01
    m = morae(text) or 1
    # the moraic n: a low, sustained, audible segment at the very end
    win = np.hanning(n)
    sp = np.abs(np.fft.rfft(seg * win, axis=1)) ** 2
    fr = np.fft.rfftfreq(n, 1 / 22050.0)
    lo = sp[:, (fr >= 150) & (fr < 600)].sum(axis=1)
    hi = sp[:, fr >= 1500].sum(axis=1)
    tilt = 10 * np.log10(np.maximum(lo, 1e-9) / np.maximum(hi, 1e-9))
    aud = db > max(db.max() - 20, -32)
    nasal = 0.0
    idxs = np.where(aud)[0]
    if len(idxs):
        i = idxs[-1]
        while i >= 0 and aud[i] and tilt[i] >= 14:
            nasal += 0.01; i -= 1
    return (key, text, m, round(voiced, 3), round(voiced / m, 3), round(nasal, 3),
            round(len(a) / 22050.0, 3))

def main():
    import voice as Vv
    groups = Vv.plan()
    idx = load(V)
    jobs = []
    for items in groups.values():
        for key, lang, text, kind in items:
            if lang != 'ja' or kind != 'word' or key not in idx: continue
            fn, off, ln = idx[key]
            jobs.append((key, text, fn, off, ln))
    with Pool(2) as p:
        rows = [r for r in p.map(measure, jobs, chunksize=40) if r]
    per = np.array([r[4] for r in rows])
    print('isolated word and conjugation clips measured: %d' % len(rows))
    print('voiced seconds per mora:')
    for q in (5, 25, 50, 75, 95):
        print('   p%-3d %.3f' % (q, np.percentile(per, q)))
    print('   mean %.3f' % per.mean())
    for t in (0.10, 0.13, 0.18, 0.20):
        print('   under %.2f: %4d  (%.1f%%)' % (t, (per < t).sum(), 100 * (per < t).mean()))
    nfin = [r for r in rows if r[1].endswith('ん')]
    if nfin:
        nas = np.array([r[5] for r in nfin])
        print()
        print('clips whose word ends in ん: %d' % len(nfin))
        print('   with an audible final nasal of 60 ms or more: %d (%.1f%%)'
              % ((nas >= 0.06).sum(), 100 * (nas >= 0.06).mean()))
        print('   median final nasal %.3f s' % np.median(nas))
    worst = sorted(rows, key=lambda r: r[4])[:10]
    print()
    print('the ten most swallowed clips that remain:')
    for r in worst:
        print('   %-16s %-14s %d morae  %.2f s voiced  %.3f per mora' % (r[0], r[1], r[2], r[3], r[4]))
    json.dump(rows, open('/tmp/audio_survey.json', 'w'), ensure_ascii=False)

if __name__ == '__main__':
    main()
