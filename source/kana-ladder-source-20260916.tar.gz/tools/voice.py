"""Pre-rendered car audio.

iOS never routes Web Speech to CarPlay, but an <audio> element routes normally.
So every line car mode needs is synthesised here, ahead of time, with a neural
voice, packed into sprites, and played from a real audio element in the app.
Nothing about this depends on which voices the phone happens to have.
"""
import hashlib, io, json, os, subprocess, sys, wave
from multiprocessing import Pool

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def R(*p): return os.path.join(ROOT, *p)
OUT = R('pwa', 'audio', 'v1')
VOICES = '/tmp/claude-0/voices'
BITRATE = '32k'
W_PER, S_PER, F_PER = 200, 150, 400

PHRASES = {
    "warn":  "One minute left.",
    "test":  "Car mode. If you can hear this through the car, you are ready.",
    "f-polite present":  "Now the polite present of",
    "f-polite past":     "Now the polite past of",
    "f-polite negative": "Now the polite negative of",
    "f-te-form":         "Now the te-form of",
    "f-past":            "Now the past of",
    "f-negative":        "Now the negative of",
    "f-polite past negative": "Now the polite past negative of",
    "f-can do it form":  "Now the can do it form of",
    "f-want to do it form": "Now the want to do it form of",
    "f-polite past":     "Now the polite past of",
}

_V = {}
def voice(lang):
    if lang not in _V:
        from piper import PiperVoice
        _V[lang] = PiperVoice.load(os.path.join(VOICES, lang + '.onnx'))
    return _V[lang]

# A neural voice predicts its own durations, and this one predicts them with a
# large random component: the same short word rendered twice can differ
# threefold, and some tokens land short every time. Measured over 12 draws
# each, yon (four) gave 0.08-0.24 s of audible speech for two morae while
# hachi (eight) gave 0.18-0.32 s, so yon sounded swallowed. Nothing about the
# clip is truncated; the model simply under-generates duration for it.
#
# So a short Japanese clip is measured against what its mora count deserves,
# and a clip that falls short is redrawn at a slower speaking rate, keeping
# the best attempt. Clips that already clear the bar are drawn once at normal
# speed and left alone, so the fix changes only what was broken.
RENDER = 4           # bump to force every affected sprite to re-render
MIN_SEC_PER_MORA = 0.13
VOICED_DB = -25.0    # what counts as audible rather than room tone
SLOW_MAX_MORAE = 6   # a sentence has its own rhythm and is never redrawn
LADDER = (1.0, 1.4, 1.9, 2.4)
TRIES = 3            # attempts at each rung before moving to the next

# ---- isolated words are not conversation ----
# The first library was drawn at one speaking rate for everything, and measured
# across all 1,812 word clips it came out at 0.140 voiced seconds per mora, with
# 96% under 0.18. That is the tempo of running speech. A word alone on a card is
# a citation form and wants roughly 0.20 to 0.25, which is what a teacher would
# give you. Sentences keep the conversational rate, because a sentence read at
# dictation speed teaches the wrong rhythm.
WORD_RENDER = 1      # bump to redraw every word and form sprite
WORD_LADDER = (1.45, 1.75, 2.10, 2.40)
# The ladder is a floor, not a tempo control: it accepts the first draw that
# clears the bar, so a lucky-low draw ships. Measured on are, one draw gave
# 0.39 s of speech and the best of six gave 0.50. The duration this voice
# predicts is that noisy. So a word is drawn WORD_TRIES times at citation
# tempo and the longest is kept, and only then does the old floor apply.
WORD_TRIES = 4

# A moraic n at the end of an isolated word is simply not produced by this
# voice. Measured on yon (four): one unbroken vowel, then the energy falls 33 dB,
# then the nasal appears 40 dB down, inaudible. It is not a speed problem, and
# redrawing at 1.0, 1.3, 1.6, 1.9 and 2.4 does not fix it. Giving the model a
# trailing comma makes it treat the word as phrase-final and it produces the
# nasal. 169 deck words end in n, including sumimasen, san, en, jikan and gohan.
NASAL_SUFFIX = '、'

# Every clip used to carry about a third of a second of room tone at each end.
# Trimming it makes the library smaller and the card snappier, and it costs
# nothing: the app inserts its own gaps and car mode times its own pauses.
TRIM_DB = -45.0
TRIM_PAD = 0.10
SMALL_KANA = 'ゃゅょぁぃぅぇぉャュョァィゥェォ'
PUNCT = '、。？！ '

def morae(text):
    return sum(1 for ch in text if ch not in SMALL_KANA and ch not in PUNCT)

def laddered(lang, text):
    """Is this a clip the redraw ladder applies to?"""
    if lang != 'ja':
        return False
    if any(ch in text for ch in '、。'):
        return False
    return 1 <= morae(text) <= SLOW_MAX_MORAE

def voiced(pcm, sr):
    """Seconds of audible speech, in 10 ms frames above VOICED_DB.

    Total audible time, not first-to-last span: yon is one short burst where
    hachi is two, and a span measurement cannot tell those apart."""
    try:
        import numpy as np
    except ImportError:
        return None
    a = np.frombuffer(pcm, dtype='<i2').astype('float64')
    n = int(sr * 0.01)
    if n <= 0 or len(a) < n:
        return 0.0
    f = len(a) // n
    rms = np.sqrt(np.mean(a[:f*n].reshape(f, n) ** 2, axis=1))
    db = 20 * np.log10(np.maximum(rms, 1e-6) / 32768.0)
    return float((db > VOICED_DB).sum()) * 0.01

def trim(pcm, sr):
    """Drop leading and trailing room tone, keeping a short pad either side."""
    try:
        import numpy as np
    except ImportError:
        return pcm
    a = np.frombuffer(pcm, dtype='<i2')
    n = int(sr * 0.01)
    f = len(a) // n
    if f < 3:
        return pcm
    x = a[:f*n].reshape(f, n).astype('float64')
    rms = np.sqrt((x * x).mean(axis=1))
    db = 20 * np.log10(np.maximum(rms, 1e-6) / 32768.0)
    loud = np.where(db > TRIM_DB)[0]
    if not len(loud):
        return pcm
    pad = int(TRIM_PAD / 0.01)
    s0 = max(0, loud[0] - pad)
    e0 = min(f, loud[-1] + 1 + pad)
    return a[s0*n:e0*n].tobytes()

def nuclei(pcm, sr):
    """How many separate bursts of sound a clip contains.

    The selector keeps the draw with the most audible speech, and this voice
    sometimes stutters: an clip of two morae came back with nine bursts in it,
    which scores well and is not the word. A draw with more bursts than morae
    is the model babbling, so it is never preferred over one that is not."""
    try:
        import numpy as np
    except ImportError:
        return 0
    a = np.frombuffer(pcm, dtype='<i2').astype('float64')
    n = int(sr * 0.01)
    f = len(a) // n
    if f < 3:
        return 0
    rms = np.sqrt((a[:f*n].reshape(f, n) ** 2).mean(axis=1))
    db = 20 * np.log10(np.maximum(rms, 1e-6) / 32768.0)
    on = db > max(db.max() - 22, -40)
    count, run = 0, 0
    for v in on:
        if v:
            run += 1
        else:
            if run >= 3:
                count += 1
            run = 0
    if run >= 3:
        count += 1
    return count

def ends_loud(pcm, sr):
    """Does the clip stop while still sounding? That is an audible click."""
    try:
        import numpy as np
    except ImportError:
        return False
    a = np.frombuffer(pcm, dtype='<i2').astype('float64')
    n = int(sr * 0.01)
    f = len(a) // n
    if f < 3:
        return False
    rms = np.sqrt((a[:f*n].reshape(f, n) ** 2).mean(axis=1))
    db = 20 * np.log10(np.maximum(rms, 1e-6) / 32768.0)
    return bool(db[-1] > db.max() - 25)

def draw(lang, text, ls):
    from piper import SynthesisConfig
    chunks = list(voice(lang).synthesize(text, syn_config=SynthesisConfig(length_scale=ls)))
    if not chunks:
        return None, None
    pcm = b''.join(c.audio_int16_bytes for c in chunks)
    return chunks[0], pcm

def mp3(lang, text, kind='word'):
    """kind is 'word' for an isolated word or conjugated form, 'sent' for a
    sentence, 'en' for English. Only 'word' gets citation tempo and the nasal
    suffix; a sentence keeps the rhythm it was written with."""
    word = (kind == 'word' and lang == 'ja')
    ladder = WORD_LADDER if word else LADDER
    src = text
    if word and (text.endswith('ん') or text.endswith('ン')):
        # katakana too: pan, raamen, resutoran, pen, pasokon and eighteen more
        # were missed by a hiragana-only test and kept the original defect
        src = text + NASAL_SUFFIX
    a, pcm = draw(lang, src, ladder[0])
    if a is None:
        return b''
    if word:
        m = morae(text) or 1
        def sound(p, sr):
            # a draw is only a candidate if it is the word and not a stutter,
            # and if it does not stop while still sounding
            return nuclei(p, sr) <= m + 1 and not ends_loud(p, sr)
        best = voiced(pcm, a.sample_rate)
        clean = sound(pcm, a.sample_rate)
        for _ in range(WORD_TRIES - 1):
            a2, pcm2 = draw(lang, src, ladder[0])
            if a2 is None:
                break
            got = voiced(pcm2, a2.sample_rate)
            c2 = sound(pcm2, a2.sample_rate)
            if got is None or best is None:
                continue
            # a clean draw always beats a dirty one, whatever it scores
            if (c2 and not clean) or (c2 == clean and got > best):
                a, pcm, best, clean = a2, pcm2, got, c2
    if (word and 1 <= morae(text) <= SLOW_MAX_MORAE) or (not word and laddered(lang, text)):
        # Each draw is a fresh sample from a noisy distribution, so one attempt
        # per rung is a lottery: the first build of this fix redrew yon four
        # times and still shipped a 0.12 s clip, because all four draws came
        # from the low tail. Measured over 1,654 real clips, 92% clear the bar
        # on the rung they start on and only 0.7% land under 0.09 s per mora,
        # so retrying each rung costs very little and is what closes that tail.
        want = MIN_SEC_PER_MORA * morae(text)
        best = voiced(pcm, a.sample_rate)
        done = best is not None and best >= want
        for ls in ladder:
            if done:
                break
            for _ in range(TRIES):
                a2, pcm2 = draw(lang, src, ls)
                if a2 is None:
                    done = True
                    break
                got = voiced(pcm2, a2.sample_rate)
                c2 = (not word) or (nuclei(pcm2, a2.sample_rate) <= (morae(text) or 1) + 1
                                    and not ends_loud(pcm2, a2.sample_rate))
                if got is not None and got > best and c2:
                    a, pcm, best = a2, pcm2, got
                if best >= want:
                    done = True
                    break
    pcm = trim(pcm, a.sample_rate)
    buf = io.BytesIO()
    with wave.open(buf, 'wb') as w:
        w.setnchannels(a.sample_channels); w.setsampwidth(a.sample_width)
        w.setframerate(a.sample_rate)
        w.writeframes(pcm)
    p = subprocess.run(
        ['ffmpeg','-loglevel','error','-y','-i','pipe:0','-c:a','libmp3lame',
         '-b:a',BITRATE,'-ac','1','-ar','22050','-f','mp3','pipe:1'],
        input=buf.getvalue(), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p.stdout

def job(t):
    key, lang, text, kind = t
    try: return key, mp3(lang, text, kind)
    except Exception as e:
        sys.stderr.write('FAILED %s: %s\n' % (key, e)); return key, b''

def plan():
    deck = json.load(open(R('deck','deck_full.json'), encoding='utf-8'))
    sent = json.load(open(R('sentences','sent_full.json'), encoding='utf-8'))
    forms = json.load(open(R('conj','forms.json'), encoding='utf-8'))
    idx = {c['id']: i for i, c in enumerate(deck)}
    groups = {}
    def add(sprite, key, lang, text, kind):
        groups.setdefault(sprite, []).append((key, lang, text, kind))
    for i, c in enumerate(deck):
        sp = 'w-%03d' % (i // W_PER)
        add(sp, 'wj:'+c['id'], 'ja', c['kana'], 'word')
        add(sp, 'we:'+c['id'], 'en', c['en'], 'en')
    for i, x in enumerate(sent):
        sp = 's-%03d' % (i // S_PER)
        add(sp, 'sj:'+x['id'], 'ja', x['kana'], 'sent')
        add(sp, 'se:'+x['id'], 'en', x['en'], 'en')
    # every form, not the first four: car mode can drill any of them, and a
    # form with no clip falls back to the device voice, which never reaches
    # CarPlay. That silent hole is the thing the pre-rendered voice exists to close.
    for wid, row in forms.items():
        if wid not in idx: continue
        sp = 'f-%03d' % (idx[wid] // F_PER)
        for k in range(len(row) // 3):
            add(sp, 'fj:%s:%d' % (wid, k), 'ja', row[k*3+1], 'word')
    for k, v in PHRASES.items():
        add('p-000', 'p:'+k, 'en', v, 'en')
    return groups

def signature(items):
    """What a sprite is made of: every key, its language and its exact text.
    Matching keys are not enough. A sentence can be rewritten without its id
    changing, and an earlier version of this tool would then have shipped the
    old audio under the new text."""
    h = hashlib.sha1()
    for key, lang, text, kind in items:
        h.update(('%s\x00%s\x00%s\x00' % (key, lang, text)).encode('utf-8'))
        if kind == 'word' and lang == 'ja':
            # citation tempo, the nasal suffix and trimming all live behind this
            h.update(('w%d\x00' % WORD_RENDER).encode('utf-8'))
        elif laddered(lang, text):
            h.update(('r%d\x00' % RENDER).encode('utf-8'))
    return h.hexdigest()

def reusable(base, sig, old_sigs, sprite, same_encoder):
    # the encoder is part of what a sprite is, but it is compared rather than
    # hashed, so changing it does not have to rewrite every signature at once
    if not same_encoder:
        return False
    if old_sigs.get(sprite) != sig:
        return False
    return (os.path.exists(os.path.join(OUT, base + '.json'))
            and os.path.exists(os.path.join(OUT, base + '.mp3')))

def main():
    os.makedirs(OUT, exist_ok=True)
    groups = plan()
    total = sum(len(v) for v in groups.values())
    print('%d clips across %d sprites' % (total, len(groups)), flush=True)

    # What the last build produced, so a sprite whose clips have not changed is
    # neither re-synthesised here nor re-downloaded on the phone.
    old = {}
    try:
        old = json.load(open(os.path.join(OUT, 'manifest.json'), encoding='utf-8'))
    except Exception:
        pass
    old_files = old.get('files') or {k: k for k in (old.get('sprites') or {})}
    old_sigs = old.get('sigs') or {}
    same_encoder = (old.get('bitrate') == BITRATE)

    manifest = {'version': 2, 'bitrate': BITRATE, 'wPer': W_PER, 'sPer': S_PER,
                'fPer': F_PER, 'sprites': {}, 'files': {}, 'sigs': {}}
    done = 0
    with Pool(2) as pool:
        for sprite in sorted(groups):
            items = groups[sprite]
            sig = signature(items)
            base = old_files.get(sprite)
            if base and reusable(base, sig, old_sigs, sprite, same_encoder):
                idx_old = json.load(open(os.path.join(OUT, base + '.json'), encoding='utf-8'))
                size = os.path.getsize(os.path.join(OUT, base + '.mp3'))
                manifest['sprites'][sprite] = {'bytes': size, 'clips': len(idx_old)}
                manifest['files'][sprite] = base
                manifest['sigs'][sprite] = sig
                done += len(items)
                print('  %s  reused as %s  (%d/%d)' % (sprite, base, done, total), flush=True)
                continue
            index, blob, off = {}, bytearray(), 0
            for key, data in pool.imap(job, items, chunksize=8):
                if not data: continue
                index[key] = [off, len(data)]
                blob += data; off += len(data)
            if len(index) != len(items):
                raise SystemExit('%s: %d of %d clips failed to synthesise; '
                                 'refusing to ship a sprite with holes in it'
                                 % (sprite, len(items) - len(index), len(items)))
            body = bytes(blob)
            idx_txt = json.dumps(index, separators=(',', ':'))
            # the file is named after what is in it, so an unchanged sprite keeps
            # its URL and stays in the phone's cache while a changed one cannot
            # be served stale
            h = hashlib.sha1(body + idx_txt.encode('utf-8')).hexdigest()[:8]
            base = '%s.%s' % (sprite, h)
            open(os.path.join(OUT, base + '.mp3'), 'wb').write(body)
            open(os.path.join(OUT, base + '.json'), 'w').write(idx_txt)
            manifest['sprites'][sprite] = {'bytes': off, 'clips': len(index)}
            manifest['files'][sprite] = base
            manifest['sigs'][sprite] = sig
            done += len(items)
            print('  %s  %d clips  %.1f MB  as %s  (%d/%d)' %
                  (sprite, len(index), off/1048576, base, done, total), flush=True)

    json.dump(manifest, open(os.path.join(OUT, 'manifest.json'), 'w'),
              separators=(',', ':'))
    keep = {'manifest.json'}
    for b in manifest['files'].values():
        keep.add(b + '.mp3'); keep.add(b + '.json')
    dropped = 0
    for f in os.listdir(OUT):
        if f not in keep:
            os.remove(os.path.join(OUT, f)); dropped += 1
    mb = sum(v['bytes'] for v in manifest['sprites'].values())/1048576
    print('total %.1f MB in %d sprites, %d stale files removed'
          % (mb, len(manifest['sprites']), dropped))

if __name__ == '__main__':
    main()
