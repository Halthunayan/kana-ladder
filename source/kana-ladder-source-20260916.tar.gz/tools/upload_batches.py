# -*- coding: utf-8 -*-
"""Stage the audio library into upload sized batches.

The GitHub web upload is the only route this container has into the repository,
and the file_upload tool carries at most 10 MB per call. This sorts whatever has
changed since a given manifest into batches that fit, and writes them where the
browser can reach them. The manifest itself is held back into its own last batch:
a phone that reads a new manifest before the sprites it names have landed will
delete the audio it has and fail to replace it."""
import json, os, shutil, sys
SRC = '/home/claude/pwa/audio/v1'
OUT = '/mnt/user-data/outputs/audio_upload'
LIMIT = 9 * 1024 * 1024

def main():
    old = json.load(open(sys.argv[1], encoding='utf-8')) if len(sys.argv) > 1 else {'files': {}}
    new = json.load(open(os.path.join(SRC, 'manifest.json'), encoding='utf-8'))
    changed = [sp for sp, base in new['files'].items() if old.get('files', {}).get(sp) != base]
    files = []
    for sp in sorted(changed):
        b = new['files'][sp]
        for ext in ('.mp3', '.json'):
            p = os.path.join(SRC, b + ext)
            files.append((b + ext, os.path.getsize(p), p))
    shutil.rmtree(OUT, ignore_errors=True)
    os.makedirs(OUT)
    batch, size, n = [], 0, 0
    def flush():
        nonlocal batch, size, n
        if not batch: return
        n += 1
        d = os.path.join(OUT, 'batch%02d' % n)
        os.makedirs(d)
        for name, _, p in batch: shutil.copy2(p, os.path.join(d, name))
        print('batch%02d  %2d files  %.1f MB' % (n, len(batch), size / 1048576))
        batch, size = [], 0
    for name, sz, p in files:
        if size + sz > LIMIT: flush()
        batch.append((name, sz, p)); size += sz
    flush()
    # the manifest goes last, on its own, and only once every file above is up
    d = os.path.join(OUT, 'zz_manifest_last')
    os.makedirs(d)
    shutil.copy2(os.path.join(SRC, 'manifest.json'), os.path.join(d, 'manifest.json'))
    print('sprites changed: %d of %d, %d files, %.1f MB total'
          % (len(changed), len(new['files']), len(files), sum(f[1] for f in files) / 1048576))
    print('manifest held back in zz_manifest_last, upload it only after every batch has landed')

if __name__ == '__main__':
    main()
